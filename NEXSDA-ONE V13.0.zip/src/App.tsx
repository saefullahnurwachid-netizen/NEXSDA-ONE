/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  FileText,
  LayoutGrid,
  RefreshCw,
  Wifi,
  WifiOff,
  X,
} from 'lucide-react';
import SuratTugasModule from './modules/surat-tugas/SuratTugasModule';

const IFRAME_PATH =
  '/assets/aistudio/versi_12.0_web_NEXSDAONE_FINAL_BUMPER__1__70881c81.html';

type ActiveModule = 'nexsda' | 'surat-tugas';

export default function App() {
  const [activeModule, setActiveModule] = useState<ActiveModule>('nexsda');
  const [isLoading, setIsLoading] = useState(true);
  const [isOffline, setIsOffline] = useState(
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );
  const [showOfflineModal, setShowOfflineModal] = useState(
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );
  const [isChecking, setIsChecking] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSoftSyncing, setIsSoftSyncing] = useState(false);
  const [showRestoredNotice, setShowRestoredNotice] = useState(false);
  const [activeFormLabel, setActiveFormLabel] = useState<string | null>(null);

  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const wasOfflineRef = useRef(
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );
  const startedOfflineRef = useRef(
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );
  const checkingRef = useRef(false);
  const reloadFallbackTimerRef = useRef<number | null>(null);
  const softSyncFallbackTimerRef = useRef<number | null>(null);

  const handleSoftRefreshApp = useCallback(() => {
    setIsSoftSyncing(true);
    try {
      iframeRef.current?.contentWindow?.postMessage(
        { type: 'NEXSDA_SOFT_REFRESH' },
        window.location.origin
      );
    } catch {
      setIsSoftSyncing(false);
      setShowRestoredNotice(false);
      return;
    }

    if (softSyncFallbackTimerRef.current) {
      window.clearTimeout(softSyncFallbackTimerRef.current);
    }
    softSyncFallbackTimerRef.current = window.setTimeout(() => {
      setIsSoftSyncing(false);
      setShowRestoredNotice(false);
      softSyncFallbackTimerRef.current = null;
    }, 3500);
  }, []);

  const handleRefreshApp = useCallback(() => {
    setIsRefreshing(true);
    setShowRestoredNotice(false);
    try {
      iframeRef.current?.contentWindow?.postMessage(
        { type: 'NEXSDA_PREPARE_RELOAD' },
        window.location.origin
      );
    } catch {
      window.location.reload();
      return;
    }

    if (reloadFallbackTimerRef.current) {
      window.clearTimeout(reloadFallbackTimerRef.current);
    }
    reloadFallbackTimerRef.current = window.setTimeout(() => {
      reloadFallbackTimerRef.current = null;
      window.location.reload();
    }, 300);
  }, []);

  const applyConnectivityState = useCallback((online: boolean) => {
    if (!online) {
      if (!wasOfflineRef.current) {
        setShowOfflineModal(true);
      }
      wasOfflineRef.current = true;
      setIsOffline(true);
      setShowRestoredNotice(false);
      try {
        iframeRef.current?.contentWindow?.postMessage(
          { type: 'NEXSDA_OFFLINE_DETECTED' },
          window.location.origin
        );
      } catch {
        // Abaikan jika iframe belum siap
      }
      return;
    }

    const recoveringFromOffline = wasOfflineRef.current;
    wasOfflineRef.current = false;
    setIsOffline(false);
    setShowOfflineModal(false);

    if (recoveringFromOffline) {
      setShowRestoredNotice(true);
      if (startedOfflineRef.current) {
        startedOfflineRef.current = false;
      }
      try {
        iframeRef.current?.contentWindow?.postMessage(
          { type: 'NEXSDA_ONLINE_RESTORED' },
          window.location.origin
        );
      } catch {
        // Abaikan jika iframe belum siap
      }
    }
  }, []);

  const checkConnectivity = useCallback(
    async (manual = false) => {
      if (checkingRef.current) return;
      checkingRef.current = true;
      if (manual) setIsChecking(true);

      const isCapacitorNative =
        typeof window !== 'undefined' &&
        Boolean((window as unknown as { Capacitor?: unknown }).Capacitor);

      try {
        if (typeof navigator !== 'undefined' && !navigator.onLine) {
          applyConnectivityState(false);
          return;
        }

        const controller = new AbortController();
        const timer = window.setTimeout(() => controller.abort(), 4000);
        try {
          const res = await fetch('/api/connectivity', {
            cache: 'no-store',
            signal: controller.signal,
          });
          if (res.status === 404 && isCapacitorNative) {
            applyConnectivityState(
              typeof navigator !== 'undefined' ? navigator.onLine : true
            );
            return;
          }
          if (!res.ok) {
            applyConnectivityState(false);
            return;
          }
          const data = (await res.json()) as { online?: boolean };
          applyConnectivityState(Boolean(data?.online));
        } finally {
          window.clearTimeout(timer);
        }
      } catch {
        if (isCapacitorNative && typeof navigator !== 'undefined') {
          applyConnectivityState(navigator.onLine);
        } else {
          applyConnectivityState(false);
        }
      } finally {
        checkingRef.current = false;
        if (manual) setIsChecking(false);
      }
    },
    [applyConnectivityState]
  );

  useEffect(() => {
    void checkConnectivity(false);

    const handleOfflineEvent = () => {
      applyConnectivityState(false);
    };
    const handleOnlineEvent = () => {
      void checkConnectivity(false);
    };
    const handleFocus = () => {
      if (document.visibilityState !== 'hidden') {
        void checkConnectivity(false);
      }
    };
    const handleIframeMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin || !event.data) return;
      if (event.data.type === 'NEXSDA_DRAFT_STATE') {
        setActiveFormLabel(
          event.data.hasOpenForm && typeof event.data.formLabel === 'string'
            ? event.data.formLabel
            : null
        );
      } else if (event.data.type === 'NEXSDA_DRAFT_SAVED') {
        if (reloadFallbackTimerRef.current) {
          window.clearTimeout(reloadFallbackTimerRef.current);
          reloadFallbackTimerRef.current = null;
        }
        window.location.reload();
      } else if (event.data.type === 'NEXSDA_SOFT_REFRESH_DONE') {
        if (softSyncFallbackTimerRef.current) {
          window.clearTimeout(softSyncFallbackTimerRef.current);
          softSyncFallbackTimerRef.current = null;
        }
        setIsSoftSyncing(false);
        setShowRestoredNotice(false);
      } else if (event.data.type === 'NEXSDA_OPEN_SURAT_TUGAS') {
        setActiveModule('surat-tugas');
      }
    };

    const handleDownloadAnchorClick = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      const anchor = target?.closest?.('a[download]') as HTMLAnchorElement | null;
      if (anchor) {
        const dlName = anchor.getAttribute('download');
        if (dlName) {
          (
            window as unknown as { __nexsdaLastDownloadName?: string }
          ).__nexsdaLastDownloadName = dlName;
        }
      }
    };

    window.addEventListener('offline', handleOfflineEvent);
    window.addEventListener('online', handleOnlineEvent);
    window.addEventListener('focus', handleFocus);
    window.addEventListener('message', handleIframeMessage);
    document.addEventListener('visibilitychange', handleFocus);
    document.addEventListener('click', handleDownloadAnchorClick, true);

    return () => {
      window.removeEventListener('offline', handleOfflineEvent);
      window.removeEventListener('online', handleOnlineEvent);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('message', handleIframeMessage);
      document.removeEventListener('visibilitychange', handleFocus);
      document.removeEventListener('click', handleDownloadAnchorClick, true);
      if (reloadFallbackTimerRef.current) {
        window.clearTimeout(reloadFallbackTimerRef.current);
      }
      if (softSyncFallbackTimerRef.current) {
        window.clearTimeout(softSyncFallbackTimerRef.current);
      }
    };
  }, [applyConnectivityState, checkConnectivity]);

  useEffect(() => {
    const intervalMs = isOffline ? 8000 : 25000;
    const timer = window.setInterval(() => {
      if (document.visibilityState !== 'hidden') {
        void checkConnectivity(false);
      }
    }, intervalMs);
    return () => window.clearInterval(timer);
  }, [isOffline, checkConnectivity]);

  return (
    <div className="relative flex flex-col w-screen h-screen overflow-hidden bg-[#03070A] print:h-auto print:overflow-visible print:bg-white">
      {/* Bilah Navigasi Modul Utama NEXSDA-ONE */}
      <header
        className="relative z-40 h-11 px-2.5 sm:px-5 bg-[#052e16] border-b border-emerald-900/90 text-white flex items-center justify-between gap-2 sm:gap-6 shrink-0 print:hidden"
        style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}
      >
        <span className="text-xs sm:text-sm font-bold tracking-tight text-white whitespace-nowrap shrink-0">
          NEXSDA ONE
        </span>

        <nav
          aria-label="Navigasi Modul Utama"
          className="flex items-center gap-1 p-1 bg-black/25 rounded-lg border border-white/10"
        >
          <button
            type="button"
            onClick={() => setActiveModule('nexsda')}
            className={`inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-md text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer ${
              activeModule === 'nexsda'
                ? 'bg-[#15803d] text-white shadow-xs'
                : 'text-emerald-100/80 hover:text-white hover:bg-white/10'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5 shrink-0" />
            <span>
              <span className="hidden sm:inline">Platform </span>NEXSDA-ONE
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveModule('surat-tugas')}
            className={`inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-md text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer ${
              activeModule === 'surat-tugas'
                ? 'bg-[#15803d] text-white shadow-xs'
                : 'text-emerald-100/80 hover:text-white hover:bg-white/10'
            }`}
          >
            <FileText className="w-3.5 h-3.5 shrink-0" />
            <span>Surat Tugas</span>
          </button>
        </nav>

        <span className="hidden md:inline text-xs font-medium text-emerald-200/80 whitespace-nowrap shrink-0">
          BKSDA Jakarta · Seksi KSDA Wilayah I
        </span>
      </header>

      {isOffline && (
        <div
          role="alert"
          className="relative z-50 flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-amber-600 text-white border-b border-amber-500/80 shadow-md shrink-0 print:hidden"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-black/20 shrink-0">
              <WifiOff className="w-4 h-4" />
            </span>
            <div className="text-xs leading-snug">
              <span className="font-bold uppercase tracking-wide mr-1.5">
                Tidak Ada Koneksi Internet:
              </span>
              <span className="text-amber-50">
                {activeFormLabel
                  ? `Isian pada ${activeFormLabel} tetap aman dan otomatis tersimpan sebagai draf — lanjutkan mengetik tanpa perlu mengulang.`
                  : 'Anda tetap dapat melanjutkan input data — seluruh draf otomatis tersimpan di perangkat dan akan tersinkron saat internet kembali.'}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void checkConnectivity(true)}
            disabled={isChecking}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white text-amber-800 hover:bg-amber-50 disabled:opacity-70 text-xs font-bold shadow-xs transition shrink-0 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
            {isChecking ? 'Memeriksa...' : 'Cek Koneksi'}
          </button>
        </div>
      )}

      {showRestoredNotice && !isOffline && (
        <div
          role="status"
          className="relative z-50 flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-emerald-700 text-white border-b border-emerald-600 shadow-md shrink-0 print:hidden"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-black/20 shrink-0">
              <Wifi className="w-4 h-4" />
            </span>
            <div className="text-xs leading-snug">
              <span className="font-bold uppercase tracking-wide mr-1.5">
                Internet Tersambung Kembali:
              </span>
              <span className="text-emerald-50">
                {activeFormLabel
                  ? `Klik Sinkronkan untuk menyegarkan peta & Google Drive tanpa menghapus input di ${activeFormLabel}.`
                  : 'Koneksi aktif. Klik Sinkronkan agar peta & Google Drive segar kembali tanpa kehilangan input yang sedang diisi.'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleSoftRefreshApp}
              disabled={isSoftSyncing || isRefreshing}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-white text-emerald-800 hover:bg-emerald-50 disabled:opacity-70 text-xs font-bold shadow-xs transition cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSoftSyncing ? 'animate-spin' : ''}`} />
              {isSoftSyncing ? 'Menyinkronkan...' : 'Sinkronkan'}
            </button>
            <button
              type="button"
              onClick={handleRefreshApp}
              disabled={isRefreshing || isSoftSyncing}
              title="Muat ulang penuh sambil menyimpan & memulihkan draf input otomatis"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-800/80 hover:bg-emerald-900 text-white border border-emerald-500/60 disabled:opacity-70 text-xs font-semibold transition cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? 'Memuat Ulang...' : 'Refresh Halaman'}
            </button>
            <button
              type="button"
              onClick={() => setShowRestoredNotice(false)}
              aria-label="Tutup pemberitahuan"
              className="p-1.5 rounded-lg text-emerald-100 hover:text-white hover:bg-black/20 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div className="relative flex-1 min-h-0 print:min-h-0">
        {/* Platform Utama NEXSDA-ONE tetap terpasang agar status peta & draf tidak hilang */}
        <div
          className={`w-full h-full ${activeModule === 'nexsda' ? 'block' : 'hidden'} print:hidden`}
        >
          {isLoading && (
            <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-[#03070A] text-white">
              <div className="w-12 h-12 rounded-full border-4 border-emerald-500/20 border-t-emerald-400 animate-spin mb-4" />
              <p className="text-xs font-mono tracking-widest text-emerald-400 uppercase">
                Memuat NEXSDA ONE...
              </p>
            </div>
          )}

          <iframe
            ref={iframeRef}
            src={IFRAME_PATH}
            title="NEXSDA ONE - Platform Terpadu Seksi KSDA Wilayah I BKSDA Jakarta"
            className="w-full h-full border-0 block"
            allow="geolocation; camera"
            onLoad={() => setIsLoading(false)}
          />
        </div>

        {/* Modul Sistem Surat Tugas */}
        {activeModule === 'surat-tugas' && (
          <div className="w-full h-full print:h-auto">
            <SuratTugasModule />
          </div>
        )}
      </div>

      {isOffline && showOfflineModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="nexsda-offline-title"
          className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs print:hidden"
        >
          <div className="w-full max-w-md rounded-2xl bg-white text-slate-800 shadow-2xl border border-amber-200 overflow-hidden">
            <div className="flex items-start justify-between gap-3 px-5 py-4 bg-amber-50 border-b border-amber-200/80">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h2
                    id="nexsda-offline-title"
                    className="text-sm font-bold text-slate-900"
                  >
                    Peringatan: Tidak Ada Koneksi Internet
                  </h2>
                  <p className="text-[11px] text-amber-800 font-medium">
                    Perangkat sedang offline
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowOfflineModal(false)}
                aria-label="Tutup peringatan"
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-amber-100/80 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="px-5 py-4 space-y-2.5 text-xs text-slate-600 leading-relaxed">
              <p>
                Laptop atau perangkat Anda saat ini tidak terhubung ke internet.
                Beberapa fitur utama memerlukan koneksi internet aktif:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-slate-700">
                <li>
                  Memuat dan menyimpan otomatis database ke Google Drive{' '}
                  <span className="font-semibold text-slate-900">
                    nexsdaone@gmail.com
                  </span>
                </li>
                <li>Menampilkan peta interaktif GIS dan pustaka impor dokumen</li>
              </ul>
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-[11px] leading-relaxed">
                <p className="font-bold text-emerald-950 mb-0.5">
                  Input Data Tetap Aman (Auto-Save Draf):
                </p>
                <p>
                  {activeFormLabel
                    ? `Seluruh isian yang sedang Anda ketik di ${activeFormLabel} otomatis tersimpan sebagai draf di perangkat. Anda dapat langsung melanjutkan mengetik tanpa perlu mengulang meskipun halaman di-refresh.`
                    : 'Anda tetap dapat melanjutkan pengisian data. Seluruh input otomatis tersimpan sebagai draf di perangkat sehingga tidak perlu mengulang ketika internet kembali tersambung.'}
                </p>
              </div>
              <p className="text-[11px] text-slate-500 pt-0.5">
                Periksa sambungan Wi-Fi atau kabel LAN Anda. Peringatan ini akan
                hilang otomatis begitu koneksi internet kembali aktif.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 px-5 py-3.5 bg-slate-50 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setShowOfflineModal(false)}
                className="px-3.5 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold transition cursor-pointer"
              >
                Lanjut Mode Offline
              </button>
              <button
                type="button"
                onClick={() => void checkConnectivity(true)}
                disabled={isChecking}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-70 text-white text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
                {isChecking ? 'Memeriksa...' : 'Coba Cek Lagi'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
