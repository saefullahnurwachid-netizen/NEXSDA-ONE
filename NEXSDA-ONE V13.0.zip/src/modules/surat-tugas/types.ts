export interface Employee {
  id: string;
  nama: string;
  nip: string;
  pangkatGolongan: string;
  jabatan: string;
  unit: string;
  source?: 'sk01_2026' | 'manual';
}

export interface Signatory {
  id: string;
  nama: string;
  nip: string;
  pangkatGolongan: string;
  jabatan: string;
  jabatanHeader: string;
  isDefault?: boolean;
}

export interface DipaAccount {
  id: string;
  kodeAkun: string;
  uraian: string;
  nomorDipa: string;
  tahunAnggaran: string;
  tanggalDipa?: string;
  isDefault?: boolean;
}

export interface LogoSettings {
  ministryLine1: string;
  directorateLine2: string;
  agencyLine3: string;
  addressLine1: string;
  addressLine2: string;
  logoBase64: string;
  stampSignatureBase64: string;
  showStampSignature: boolean;
  paperSize: 'F4' | 'A4';
}

export interface MasterOptionItem {
  id: string;
  label: string;
  value: string;
}

export interface MasterOptions {
  dasarSurat: MasterOptionItem[];
  maksudTugas: MasterOptionItem[];
  tempatTujuan: MasterOptionItem[];
  tindakLanjut?: MasterOptionItem[];
  kodeKlasifikasi?: MasterOptionItem[];
  tembusan?: MasterOptionItem[];
}

export type MasterCategoryKey = keyof MasterOptions;

export interface SuratTugasRecord {
  id: string;
  nomorSurat: string;
  nomorSt?: string;
  bulanNomor?: number;
  tahunNomor?: string;
  kodeKlasifikasi: string;
  jenisDasarKegiatan?: string;
  lokasiWilayahKerja?: string;
  tindakLanjut?: string;
  menimbangCustom?: string;
  dasarHukum: string[];
  pegawaiIds: string[];
  pegawaiSnapshot: Employee[];
  formatKepada?: 'otomatis' | 'langsung' | 'lampiran' | 'daftar' | 'tabel';
  maksudTugas: string;
  lokasiTugas: string;
  tanggalMulai: string;
  tanggalSelesai: string;
  hariKegiatanText?: string;
  tanggalKegiatanText?: string;
  lamaHari: number;
  tanggalSurat: string;
  tempatDitetapkan: string;
  penandatanganId: string;
  penandatanganSnapshot: Signatory;
  dipaId: string;
  dipaSnapshot: DipaAccount | null;
  pakaiDipa: boolean;
  tembusan: string[];
  catatanTambahan: string;
  createdAt: string;
  updatedAt: string;
}

export type SuratTugasTab =
  | 'create'
  | 'history'
  | 'employees'
  | 'signatories'
  | 'logo'
  | 'master';

export interface ToastNotice {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

export interface ConfirmDialogConfig {
  title: string;
  description: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
}
