import { Check, Edit3, Plus, Star, Trash2, X } from 'lucide-react';
import { useState } from 'react';
import type {
  ConfirmDialogConfig,
  DipaAccount,
  Employee,
  Signatory,
} from '../types';
import { formatNipSpaced } from '../utils/dateUtils';

interface DipaSignatoryViewProps {
  signatories: Signatory[];
  dipaAccounts: DipaAccount[];
  employees: Employee[];
  onSaveSignatories: (list: Signatory[]) => void;
  onSaveDipaAccounts: (list: DipaAccount[]) => void;
  onConfirm: (config: ConfirmDialogConfig) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

const EMPTY_SIG = {
  id: '',
  nama: '',
  nip: '',
  pangkatGolongan: '',
  jabatan: '',
  jabatanHeader: '',
  isDefault: false,
};

const EMPTY_DIPA = {
  id: '',
  kodeAkun: '',
  uraian: '',
  nomorDipa: 'SP DIPA-029.05.2.427051/2026',
  tahunAnggaran: '2026',
  tanggalDipa: '2 Desember 2025',
  isDefault: false,
};

export default function DipaSignatoryView({
  signatories,
  dipaAccounts,
  employees,
  onSaveSignatories,
  onSaveDipaAccounts,
  onConfirm,
  onNotify,
}: DipaSignatoryViewProps) {
  const [sigModalOpen, setSigModalOpen] = useState(false);
  const [sigEditMode, setSigEditMode] = useState(false);
  const [sigForm, setSigForm] = useState(EMPTY_SIG);

  const [dipaModalOpen, setDipaModalOpen] = useState(false);
  const [dipaEditMode, setDipaEditMode] = useState(false);
  const [dipaForm, setDipaForm] = useState(EMPTY_DIPA);

  const openAddSig = () => {
    setSigForm(EMPTY_SIG);
    setSigEditMode(false);
    setSigModalOpen(true);
  };

  const openEditSig = (sig: Signatory) => {
    setSigForm({
      id: sig.id,
      nama: sig.nama,
      nip: sig.nip,
      pangkatGolongan: sig.pangkatGolongan,
      jabatan: sig.jabatan,
      jabatanHeader: sig.jabatanHeader,
      isDefault: Boolean(sig.isDefault),
    });
    setSigEditMode(true);
    setSigModalOpen(true);
  };

  const handleSubmitSig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sigForm.nama.trim() || !sigForm.jabatan.trim()) {
      onNotify('error', 'Nama dan Jabatan Pejabat Penandatangan wajib diisi.');
      return;
    }
    const item: Signatory = {
      id: sigEditMode ? sigForm.id : `sig-${Date.now()}`,
      nama: sigForm.nama.trim(),
      nip: sigForm.nip.replace(/\s+/g, '') || '-',
      pangkatGolongan: sigForm.pangkatGolongan.trim() || '-',
      jabatan: sigForm.jabatan.trim(),
      jabatanHeader: sigForm.jabatanHeader.trim() || `${sigForm.jabatan.trim()},`,
      isDefault: sigForm.isDefault,
    };

    let updated = sigEditMode
      ? signatories.map((s) => (s.id === item.id ? item : s))
      : [...signatories, item];
    if (item.isDefault) {
      updated = updated.map((s) => ({ ...s, isDefault: s.id === item.id }));
    }
    onSaveSignatories(updated);
    setSigModalOpen(false);
    onNotify(
      'success',
      sigEditMode
        ? 'Data pejabat penandatangan berhasil diperbarui.'
        : 'Pejabat penandatangan baru berhasil ditambahkan.'
    );
  };

  const handleSetDefaultSig = (id: string) => {
    onSaveSignatories(
      signatories.map((s) => ({ ...s, isDefault: s.id === id }))
    );
    onNotify('info', 'Pejabat penandatangan utama telah diperbarui.');
  };

  const handleDeleteSig = (id: string) => {
    if (signatories.length <= 1) {
      onNotify('error', 'Minimal harus terdapat satu pejabat penandatangan.');
      return;
    }
    const next = signatories.filter((s) => s.id !== id);
    if (!next.some((s) => s.isDefault) && next.length > 0) {
      next[0] = { ...next[0], isDefault: true };
    }
    onSaveSignatories(next);
    onNotify('success', 'Pejabat penandatangan berhasil dihapus.');
  };

  const openAddDipa = () => {
    setDipaForm(EMPTY_DIPA);
    setDipaEditMode(false);
    setDipaModalOpen(true);
  };

  const openEditDipa = (acc: DipaAccount) => {
    setDipaForm({
      id: acc.id,
      kodeAkun: acc.kodeAkun,
      uraian: acc.uraian,
      nomorDipa: acc.nomorDipa,
      tahunAnggaran: acc.tahunAnggaran,
      tanggalDipa: acc.tanggalDipa || '2 Desember 2025',
      isDefault: Boolean(acc.isDefault),
    });
    setDipaEditMode(true);
    setDipaModalOpen(true);
  };

  const handleSubmitDipa = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dipaForm.kodeAkun.trim() || !dipaForm.uraian.trim()) {
      onNotify('error', 'Kode Akun dan Uraian Mata Anggaran wajib diisi.');
      return;
    }
    const item: DipaAccount = {
      id: dipaEditMode ? dipaForm.id : `dipa-${Date.now()}`,
      kodeAkun: dipaForm.kodeAkun.trim(),
      uraian: dipaForm.uraian.trim(),
      nomorDipa: dipaForm.nomorDipa.trim() || 'SP DIPA Balai KSDA Jakarta',
      tahunAnggaran: dipaForm.tahunAnggaran.trim() || '2026',
      tanggalDipa: dipaForm.tanggalDipa.trim() || '2 Desember 2025',
      isDefault: dipaForm.isDefault,
    };
    let updated = dipaEditMode
      ? dipaAccounts.map((d) => (d.id === item.id ? item : d))
      : [...dipaAccounts, item];
    if (item.isDefault) {
      updated = updated.map((d) => ({ ...d, isDefault: d.id === item.id }));
    }
    onSaveDipaAccounts(updated);
    setDipaModalOpen(false);
    onNotify(
      'success',
      dipaEditMode
        ? 'Kode akun DIPA berhasil diperbarui.'
        : 'Kode akun DIPA baru berhasil ditambahkan.'
    );
  };

  const handleSetDefaultDipa = (id: string) => {
    onSaveDipaAccounts(
      dipaAccounts.map((d) => ({ ...d, isDefault: d.id === id }))
    );
    onNotify('info', 'Mata anggaran DIPA utama telah diperbarui.');
  };

  const handleDeleteDipa = (id: string) => {
    if (dipaAccounts.length <= 1) {
      onNotify('error', 'Minimal harus terdapat satu kode akun DIPA.');
      return;
    }
    const next = dipaAccounts.filter((d) => d.id !== id);
    if (!next.some((d) => d.isDefault) && next.length > 0) {
      next[0] = { ...next[0], isDefault: true };
    }
    onSaveDipaAccounts(next);
    onNotify('success', 'Kode akun DIPA berhasil dihapus.');
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 items-start">
      {/* Bagian Pejabat Penandatangan */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              Pejabat Penandatangan
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Daftar Kepala Balai, Plh., Kepala Seksi, atau pejabat berwenang penandatangan Surat Tugas.
            </p>
          </div>
          <button
            type="button"
            onClick={openAddSig}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Tambah Pejabat
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {signatories.map((sig) => (
            <div
              key={sig.id}
              className="px-5 py-3.5 flex items-start justify-between gap-3 hover:bg-slate-50/60"
            >
              <div className="min-w-0 space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-900">
                    {sig.nama}
                  </span>
                  {sig.isDefault && (
                    <span className="text-[11px] font-semibold text-[#14532d]">
                      · Utama
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-700">{sig.jabatan}</div>
                <div className="text-xs text-slate-500 tabular-nums">
                  {sig.pangkatGolongan} · NIP. {formatNipSpaced(sig.nip)}
                </div>
                <div className="text-[11px] text-slate-400 whitespace-pre-line">
                  Tajuk TTD: {sig.jabatanHeader}
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                {!sig.isDefault && (
                  <button
                    type="button"
                    onClick={() => handleSetDefaultSig(sig.id)}
                    title="Jadikan Penandatangan Utama"
                    className="p-1.5 rounded-md text-slate-500 hover:text-[#14532d] hover:bg-emerald-50 cursor-pointer"
                  >
                    <Star className="w-4 h-4" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => openEditSig(sig)}
                  title="Ubah Pejabat"
                  className="p-1.5 rounded-md text-slate-600 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onConfirm({
                      title: 'Hapus Pejabat Penandatangan?',
                      description: `Pejabat "${sig.nama}" akan dihapus dari daftar penandatangan.`,
                      confirmLabel: 'Hapus',
                      danger: true,
                      onConfirm: () => handleDeleteSig(sig.id),
                    })
                  }
                  title="Hapus Pejabat"
                  className="p-1.5 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Bagian Kode Akun & DIPA */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">
              Kode Akun & Mata Anggaran DIPA
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Referensi pembebanan anggaran perjalanan dinas DIPA Balai KSDA Jakarta.
            </p>
          </div>
          <button
            type="button"
            onClick={openAddDipa}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Tambah DIPA
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {dipaAccounts.map((acc) => (
            <div
              key={acc.id}
              className="px-5 py-3.5 flex items-start justify-between gap-3 hover:bg-slate-50/60"
            >
              <div className="min-w-0 space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-mono font-semibold text-slate-900 tabular-nums">
                    Akun {acc.kodeAkun}
                  </span>
                  {acc.isDefault && (
                    <span className="text-[11px] font-semibold text-[#14532d]">
                      · Utama
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-700">{acc.uraian}</div>
                <div className="text-xs text-slate-500 font-mono tabular-nums">
                  {acc.nomorDipa} · TA {acc.tahunAnggaran}
                  {acc.tanggalDipa ? ` · tgl ${acc.tanggalDipa}` : ''}
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                {!acc.isDefault && (
                  <button
                    type="button"
                    onClick={() => handleSetDefaultDipa(acc.id)}
                    title="Jadikan Akun Utama"
                    className="p-1.5 rounded-md text-slate-500 hover:text-[#14532d] hover:bg-emerald-50 cursor-pointer"
                  >
                    <Star className="w-4 h-4" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => openEditDipa(acc)}
                  title="Ubah Akun DIPA"
                  className="p-1.5 rounded-md text-slate-600 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onConfirm({
                      title: 'Hapus Kode Akun DIPA?',
                      description: `Akun "${acc.kodeAkun} - ${acc.uraian}" akan dihapus dari daftar anggaran.`,
                      confirmLabel: 'Hapus',
                      danger: true,
                      onConfirm: () => handleDeleteDipa(acc.id),
                    })
                  }
                  title="Hapus Akun DIPA"
                  className="p-1.5 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Modal Pejabat */}
      {sigModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
        >
          <div className="w-full max-w-lg bg-white rounded-xl border border-slate-200 shadow-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                {sigEditMode
                  ? 'Ubah Pejabat Penandatangan'
                  : 'Tambah Pejabat Penandatangan'}
              </h3>
              <button
                type="button"
                onClick={() => setSigModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleSubmitSig} className="p-5 space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Isi otomatis dari data ASN (opsional):
                </label>
                <select
                  value=""
                  onChange={(e) => {
                    const emp = employees.find((x) => x.id === e.target.value);
                    if (!emp) return;
                    setSigForm((prev) => ({
                      ...prev,
                      nama: emp.nama,
                      nip: emp.nip,
                      pangkatGolongan: emp.pangkatGolongan,
                      jabatan: prev.jabatan || emp.jabatan,
                    }));
                  }}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-[#14532d]"
                >
                  <option value="">-- Pilih pegawai ASN untuk mengisi nama & NIP --</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.nama} ({emp.pangkatGolongan})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Pejabat & Gelar <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={sigForm.nama}
                  onChange={(e) => setSigForm({ ...sigForm, nama: e.target.value })}
                  placeholder="Contoh: Ir. Nama Pejabat, M.Si."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    NIP
                  </label>
                  <input
                    type="text"
                    value={sigForm.nip}
                    onChange={(e) => setSigForm({ ...sigForm, nip: e.target.value })}
                    placeholder="197210201999031002"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono tabular-nums text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Pangkat / Golongan
                  </label>
                  <input
                    type="text"
                    value={sigForm.pangkatGolongan}
                    onChange={(e) =>
                      setSigForm({ ...sigForm, pangkatGolongan: e.target.value })
                    }
                    placeholder="Pembina Tk. I (IV/b)"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Jabatan Lengkap <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={sigForm.jabatan}
                  onChange={(e) =>
                    setSigForm({ ...sigForm, jabatan: e.target.value })
                  }
                  placeholder="Kepala Balai Konservasi Sumber Daya Alam Jakarta"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tajuk Blok Tanda Tangan (bisa 2 baris, mis. a.n. Kepala Balai)
                </label>
                <textarea
                  rows={2}
                  value={sigForm.jabatanHeader}
                  onChange={(e) =>
                    setSigForm({ ...sigForm, jabatanHeader: e.target.value })
                  }
                  placeholder={'a.n. Kepala Balai\nKepala Seksi KSDA Wilayah I,'}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                />
              </div>

              <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sigForm.isDefault}
                  onChange={(e) =>
                    setSigForm({ ...sigForm, isDefault: e.target.checked })
                  }
                  className="w-3.5 h-3.5 accent-[#14532d]"
                />
                <span>Jadikan penandatangan utama (default)</span>
              </label>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSigModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  Simpan Pejabat
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal DIPA */}
      {dipaModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
        >
          <div className="w-full max-w-lg bg-white rounded-xl border border-slate-200 shadow-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                {dipaEditMode ? 'Ubah Kode Akun DIPA' : 'Tambah Kode Akun DIPA'}
              </h3>
              <button
                type="button"
                onClick={() => setDipaModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitDipa} className="p-5 space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kode Akun <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={dipaForm.kodeAkun}
                    onChange={(e) =>
                      setDipaForm({ ...dipaForm, kodeAkun: e.target.value })
                    }
                    placeholder="524111"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono tabular-nums text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tahun Anggaran
                  </label>
                  <input
                    type="text"
                    value={dipaForm.tahunAnggaran}
                    onChange={(e) =>
                      setDipaForm({ ...dipaForm, tahunAnggaran: e.target.value })
                    }
                    placeholder="2026"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono tabular-nums text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Uraian Mata Anggaran <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={dipaForm.uraian}
                  onChange={(e) =>
                    setDipaForm({ ...dipaForm, uraian: e.target.value })
                  }
                  placeholder="Belanja Perjalanan Dinas Biasa — Seksi KSDA Wilayah I"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nomor SP DIPA
                  </label>
                  <input
                    type="text"
                    value={dipaForm.nomorDipa}
                    onChange={(e) =>
                      setDipaForm({ ...dipaForm, nomorDipa: e.target.value })
                    }
                    placeholder="SP DIPA-029.05.2.427051/2026"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tanggal DIPA
                  </label>
                  <input
                    type="text"
                    value={dipaForm.tanggalDipa}
                    onChange={(e) =>
                      setDipaForm({ ...dipaForm, tanggalDipa: e.target.value })
                    }
                    placeholder="2 Desember 2025"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                  />
                </div>
              </div>

              <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={dipaForm.isDefault}
                  onChange={(e) =>
                    setDipaForm({ ...dipaForm, isDefault: e.target.checked })
                  }
                  className="w-3.5 h-3.5 accent-[#14532d]"
                />
                <span>Jadikan kode akun utama (default)</span>
              </label>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDipaModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  Simpan DIPA
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
