import {
  Copy,
  Download,
  Edit3,
  Eye,
  FileSpreadsheet,
  FileText,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import type { ConfirmDialogConfig, LogoSettings, SuratTugasRecord } from '../types';
import {
  BULAN_INDONESIA,
  formatRentangTanggalIndonesia,
  formatTanggalIndonesia,
  parseIsoDateParts,
} from '../utils/dateUtils';
import { generateSuratTugasDocx } from '../utils/docxGenerator';
import { exportLettersToExcel } from '../utils/excelUtils';

interface HistoryViewProps {
  letters: SuratTugasRecord[];
  logoSettings: LogoSettings;
  onPreview: (record: SuratTugasRecord) => void;
  onEdit: (record: SuratTugasRecord) => void;
  onDuplicate: (record: SuratTugasRecord) => void;
  onDelete: (id: string) => void;
  onCreateNew: () => void;
  onConfirm: (config: ConfirmDialogConfig) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export default function HistoryView({
  letters,
  logoSettings,
  onPreview,
  onEdit,
  onDuplicate,
  onDelete,
  onCreateNew,
  onConfirm,
  onNotify,
}: HistoryViewProps) {
  const [query, setQuery] = useState('');
  const [filterMonth, setFilterMonth] = useState('ALL');
  const [filterYear, setFilterYear] = useState('ALL');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const availableYears = useMemo(() => {
    const years = new Set<string>();
    letters.forEach((rec) => {
      const p = parseIsoDateParts(rec.tanggalSurat) || parseIsoDateParts(rec.tanggalMulai);
      if (p) years.add(String(p.year));
    });
    return Array.from(years).sort((a, b) => Number(b) - Number(a));
  }, [letters]);

  const filteredLetters = useMemo(() => {
    const q = query.trim().toLowerCase();
    return letters
      .filter((rec) => {
        const p =
          parseIsoDateParts(rec.tanggalSurat) || parseIsoDateParts(rec.tanggalMulai);
        if (filterMonth !== 'ALL' && (!p || String(p.month) !== filterMonth)) {
          return false;
        }
        if (filterYear !== 'ALL' && (!p || String(p.year) !== filterYear)) {
          return false;
        }
        if (!q) return true;
        const empNames = rec.pegawaiSnapshot.map((e) => `${e.nama} ${e.nip}`).join(' ');
        return (
          rec.nomorSurat.toLowerCase().includes(q) ||
          rec.maksudTugas.toLowerCase().includes(q) ||
          rec.lokasiTugas.toLowerCase().includes(q) ||
          empNames.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        const da = a.tanggalSurat || a.createdAt;
        const db = b.tanggalSurat || b.createdAt;
        return sortOrder === 'desc' ? db.localeCompare(da) : da.localeCompare(db);
      });
  }, [letters, query, filterMonth, filterYear, sortOrder]);

  const handleDownloadDocx = async (record: SuratTugasRecord) => {
    setDownloadingId(record.id);
    try {
      await generateSuratTugasDocx(record, logoSettings);
      onNotify('success', `Dokumen ${record.nomorSurat} berhasil diunduh.`);
    } catch (err) {
      console.error(err);
      onNotify('error', 'Gagal mengunduh dokumen Word (.docx).');
    } finally {
      setDownloadingId(null);
    }
  };

  const handleExportExcel = () => {
    if (filteredLetters.length === 0) {
      onNotify('info', 'Tidak ada data surat tugas untuk diekspor.');
      return;
    }
    exportLettersToExcel(filteredLetters);
    onNotify(
      'success',
      `Rekap ${filteredLetters.length} Surat Tugas berhasil diekspor ke Excel (.xlsx).`
    );
  };

  return (
    <div className="space-y-4">
      {/* Bar Filter & Aksi */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex flex-1 flex-wrap items-center gap-2.5">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Cari nomor surat, pegawai, maksud tugas, atau lokasi..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
            />
          </div>

          <select
            value={filterMonth}
            onChange={(e) => setFilterMonth(e.target.value)}
            aria-label="Filter bulan surat"
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-[#14532d]"
          >
            <option value="ALL">Semua Bulan</option>
            {BULAN_INDONESIA.map((bulan, idx) => (
              <option key={bulan} value={String(idx + 1)}>
                {bulan}
              </option>
            ))}
          </select>

          <select
            value={filterYear}
            onChange={(e) => setFilterYear(e.target.value)}
            aria-label="Filter tahun surat"
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs tabular-nums text-slate-800 focus:outline-none focus:border-[#14532d]"
          >
            <option value="ALL">Semua Tahun</option>
            {availableYears.map((yr) => (
              <option key={yr} value={yr}>
                {yr}
              </option>
            ))}
          </select>

          <select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value as 'desc' | 'asc')}
            aria-label="Urutan tanggal surat"
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-[#14532d]"
          >
            <option value="desc">Tanggal Terbaru</option>
            <option value="asc">Tanggal Terlama</option>
          </select>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-[#14532d]" />
            Export Rekap (.xlsx)
          </button>
          <button
            type="button"
            onClick={onCreateNew}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Buat Surat Baru
          </button>
        </div>
      </div>

      {/* Tabel Riwayat */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>
            Menampilkan <strong className="text-slate-900 tabular-nums">{filteredLetters.length}</strong> dari{' '}
            <strong className="text-slate-900 tabular-nums">{letters.length}</strong> Surat Tugas tersimpan
          </span>
        </div>

        {filteredLetters.length === 0 ? (
          <div className="py-14 px-6 text-center space-y-3">
            <div className="mx-auto w-11 h-11 rounded-xl bg-slate-100 text-slate-400 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-slate-900">
                {letters.length === 0
                  ? 'Belum Ada Riwayat Surat Tugas'
                  : 'Tidak Ada Surat yang Sesuai Filter'}
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {letters.length === 0
                  ? 'Surat Tugas yang Anda simpan akan tercatat di sini beserta opsi pratinjau, edit ulang, duplikat, dan unduh dokumen Word/Excel.'
                  : 'Coba ubah kata kunci pencarian atau pilih rentang bulan dan tahun lainnya.'}
              </p>
            </div>
            {letters.length === 0 && (
              <button
                type="button"
                onClick={onCreateNew}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Buat Surat Tugas Pertama
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4 w-10 text-center">No</th>
                  <th className="py-3 px-4 min-w-[210px]">Nomor & Tanggal Surat</th>
                  <th className="py-3 px-4 min-w-[200px]">Pelaksana Tugas</th>
                  <th className="py-3 px-4 min-w-[240px]">Maksud & Lokasi</th>
                  <th className="py-3 px-4 min-w-[160px]">Pelaksanaan</th>
                  <th className="py-3 px-4 text-right w-[180px]">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLetters.map((rec, idx) => (
                  <tr key={rec.id} className="hover:bg-slate-50/70 align-top">
                    <td className="py-3 px-4 text-center text-slate-500 tabular-nums">
                      {idx + 1}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-mono font-semibold text-slate-900 tabular-nums">
                        {rec.nomorSurat}
                      </div>
                      <div className="text-slate-500 mt-0.5 tabular-nums">
                        {formatTanggalIndonesia(rec.tanggalSurat)} ·{' '}
                        {rec.pakaiDipa && rec.dipaSnapshot
                          ? `DIPA ${rec.dipaSnapshot.kodeAkun}`
                          : 'Non-DIPA'}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">
                        {rec.pegawaiSnapshot[0]?.nama || '-'}
                      </div>
                      {rec.pegawaiSnapshot.length > 1 && (
                        <div className="text-slate-500 mt-0.5 tabular-nums">
                          +{rec.pegawaiSnapshot.length - 1} personil lainnya (Total{' '}
                          {rec.pegawaiSnapshot.length} orang)
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-800 line-clamp-2">
                        {rec.maksudTugas}
                      </div>
                      <div className="text-slate-500 mt-0.5 truncate max-w-xs">
                        {rec.lokasiTugas}
                      </div>
                    </td>
                    <td className="py-3 px-4 tabular-nums">
                      <div className="text-slate-800 font-medium">
                        {formatRentangTanggalIndonesia(
                          rec.tanggalMulai,
                          rec.tanggalSelesai
                        )}
                      </div>
                      <div className="text-slate-500 mt-0.5">
                        {rec.lamaHari} hari
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => onPreview(rec)}
                          title="Pratinjau Dokumen"
                          className="p-1.5 rounded-md text-slate-600 hover:text-[#14532d] hover:bg-emerald-50 transition cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleDownloadDocx(rec)}
                          disabled={downloadingId === rec.id}
                          title="Unduh Word (.docx)"
                          className="p-1.5 rounded-md text-slate-600 hover:text-[#14532d] hover:bg-emerald-50 disabled:opacity-40 transition cursor-pointer"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onEdit(rec)}
                          title="Ubah Surat"
                          className="p-1.5 rounded-md text-slate-600 hover:text-amber-700 hover:bg-amber-50 transition cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDuplicate(rec)}
                          title="Duplikat sebagai Surat Baru"
                          className="p-1.5 rounded-md text-slate-600 hover:text-blue-700 hover:bg-blue-50 transition cursor-pointer"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onConfirm({
                              title: 'Hapus Riwayat Surat Tugas?',
                              description: `Surat Tugas nomor "${rec.nomorSurat}" akan dihapus permanen dari penyimpanan lokal perangkat ini.`,
                              confirmLabel: 'Hapus Surat',
                              danger: true,
                              onConfirm: () => onDelete(rec.id),
                            })
                          }
                          title="Hapus Surat"
                          className="p-1.5 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
