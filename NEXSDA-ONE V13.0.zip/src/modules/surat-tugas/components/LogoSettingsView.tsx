import { RotateCcw, Save, Trash2, Upload } from 'lucide-react';
import { useRef, useState } from 'react';
import type { LogoSettings } from '../types';
import { DEFAULT_LOGO_SETTINGS } from '../utils/storageUtils';

interface LogoSettingsViewProps {
  settings: LogoSettings;
  onSaveSettings: (next: LogoSettings) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

export default function LogoSettingsView({
  settings,
  onSaveSettings,
  onNotify,
}: LogoSettingsViewProps) {
  const [form, setForm] = useState<LogoSettings>(settings);
  const logoInputRef = useRef<HTMLInputElement | null>(null);
  const stampInputRef = useRef<HTMLInputElement | null>(null);

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    field: 'logoBase64' | 'stampSignatureBase64'
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!/^image\/(png|jpeg|jpg)$/i.test(file.type)) {
      onNotify('error', 'Format gambar harus PNG atau JPG agar kompatibel dengan dokumen Word (.docx).');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      onNotify('error', 'Ukuran gambar maksimal 2 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      setForm((prev) => ({
        ...prev,
        [field]: result,
        ...(field === 'stampSignatureBase64' ? { showStampSignature: true } : {}),
      }));
      onNotify('info', 'Gambar berhasil dimuat. Klik Simpan Pengaturan untuk menerapkan.');
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings({ ...form, addressLine1: '', addressLine2: '' });
    onNotify('success', 'Pengaturan Kop Surat, Logo, dan Kertas berhasil disimpan.');
  };

  const handleResetDefault = () => {
    setForm(DEFAULT_LOGO_SETTINGS);
    onSaveSettings(DEFAULT_LOGO_SETTINGS);
    onNotify('info', 'Pengaturan kop surat dikembalikan ke standar Kementerian Kehutanan / BKSDA Jakarta.');
  };

  return (
    <div className="space-y-6">
      {/* Pratinjau Kop Surat Langsung */}
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-900">
            Pratinjau Kop Surat Dinas
          </h2>
          <span className="text-xs text-slate-500">
            Format Kertas: {form.paperSize === 'F4' ? 'F4 / Folio (210 × 330 mm)' : 'A4 (210 × 297 mm)'}
          </span>
        </div>

        <div className="bg-white border border-slate-300 rounded-lg p-6 max-w-4xl mx-auto text-black">
          <div
            className="flex items-center gap-4 pb-2"
            style={{ fontFamily: "'Figtree', Arial, Helvetica, sans-serif" }}
          >
            <div className="w-16 h-16 flex items-center justify-center shrink-0">
              {form.logoBase64 ? (
                <img
                  src={form.logoBase64}
                  alt="Logo Kop Surat"
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 object-contain"
                />
              ) : (
                <div className="w-14 h-14 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-[9px] font-bold text-white text-center leading-tight">
                  LOGO
                  <br />
                  KEMENHUT
                </div>
              )}
            </div>
            <div className="flex-1 text-center leading-[1.15]">
              <div className="text-[14pt] font-bold uppercase">
                {form.ministryLine1 || 'KEMENTERIAN KEHUTANAN'}
              </div>
              <div className="text-[12pt] font-bold uppercase mt-0.5">
                {form.directorateLine2}
              </div>
              <div className="text-[16pt] font-bold uppercase mt-0.5">
                {form.agencyLine3}
              </div>
            </div>
          </div>
          <div className="border-t-[3px] border-black pt-[2px]">
            <div className="border-t border-black" />
          </div>
        </div>
      </section>

      {/* Form Pengaturan Kop & Aset Gambar */}
      <form
        onSubmit={handleSave}
        className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start"
      >
        <div className="xl:col-span-7 bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Teks Header Kop Instansi & Ukuran Kertas
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Teks ini digunakan baik pada pratinjau cetak maupun dokumen Word (.docx).
            </p>
          </div>

          <div className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Baris 1 (Kementerian)
              </label>
              <input
                type="text"
                value={form.ministryLine1}
                onChange={(e) =>
                  setForm({ ...form, ministryLine1: e.target.value })
                }
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Baris 2 (Direktorat Jenderal)
              </label>
              <input
                type="text"
                value={form.directorateLine2}
                onChange={(e) =>
                  setForm({ ...form, directorateLine2: e.target.value })
                }
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Baris 3 (Nama Balai / UPT)
              </label>
              <input
                type="text"
                value={form.agencyLine3}
                onChange={(e) =>
                  setForm({ ...form, agencyLine3: e.target.value })
                }
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Ukuran Kertas Dokumen Standar
              </label>
              <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setForm({ ...form, paperSize: 'F4' })}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
                    form.paperSize === 'F4'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  F4 / Folio (210 × 330 mm)
                </button>
                <button
                  type="button"
                  onClick={() => setForm({ ...form, paperSize: 'A4' })}
                  className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition cursor-pointer ${
                    form.paperSize === 'A4'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  A4 (210 × 297 mm)
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="xl:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Logo Kop Surat & Stempel / Tanda Tangan
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Unggah berkas PNG/JPG (disarankan PNG transparan). Tersimpan lokal dalam Base64.
            </p>
          </div>

          {/* Upload Logo */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              Logo Kop Instansi (Kementerian Kehutanan / BKSDA)
            </label>
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                {form.logoBase64 ? (
                  <img
                    src={form.logoBase64}
                    alt="Pratinjau logo"
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 object-contain"
                  />
                ) : (
                  <span className="text-[10px] text-slate-400 text-center px-1">
                    Standar
                  </span>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => logoInputRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-[#14532d]" />
                  Unggah Logo
                </button>
                {form.logoBase64 && (
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, logoBase64: '' })}
                    className="inline-flex items-center gap-1 px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-red-700 text-xs font-semibold cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Hapus
                  </button>
                )}
              </div>
              <input
                ref={logoInputRef}
                type="file"
                accept="image/png,image/jpeg"
                onChange={(e) => handleImageUpload(e, 'logoBase64')}
                className="hidden"
              />
            </div>
          </div>

          {/* Upload Stempel / TTD */}
          <div className="space-y-2 pt-3 border-t border-slate-100">
            <div className="flex items-center justify-between gap-2">
              <label className="text-xs font-semibold text-slate-700">
                Gambar Stempel / Tanda Tangan (Opsional)
              </label>
              <label className="inline-flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.showStampSignature}
                  onChange={(e) =>
                    setForm({ ...form, showStampSignature: e.target.checked })
                  }
                  className="w-3.5 h-3.5 accent-[#14532d]"
                />
                <span>Tampilkan</span>
              </label>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-24 h-16 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                {form.stampSignatureBase64 ? (
                  <img
                    src={form.stampSignatureBase64}
                    alt="Pratinjau tanda tangan"
                    referrerPolicy="no-referrer"
                    className="max-w-full max-h-full object-contain"
                  />
                ) : (
                  <span className="text-[10px] text-slate-400 text-center px-1">
                    Kosong (TTD Basah)
                  </span>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => stampInputRef.current?.click()}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-[#14532d]" />
                  Unggah TTD/Stempel
                </button>
                {form.stampSignatureBase64 && (
                  <button
                    type="button"
                    onClick={() =>
                      setForm({
                        ...form,
                        stampSignatureBase64: '',
                        showStampSignature: false,
                      })
                    }
                    className="inline-flex items-center gap-1 px-3 py-2 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-red-700 text-xs font-semibold cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Hapus
                  </button>
                )}
              </div>
              <input
                ref={stampInputRef}
                type="file"
                accept="image/png,image/jpeg"
                onChange={(e) => handleImageUpload(e, 'stampSignatureBase64')}
                className="hidden"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
            <button
              type="button"
              onClick={handleResetDefault}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 text-xs font-medium cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Kembalikan Standar
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold cursor-pointer"
            >
              <Save className="w-4 h-4" />
              Simpan Pengaturan
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
