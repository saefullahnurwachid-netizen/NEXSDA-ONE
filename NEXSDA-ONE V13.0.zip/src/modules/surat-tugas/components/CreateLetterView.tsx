import {
  ArrowDown,
  ArrowUp,
  Calendar,
  ChevronDown,
  Download,
  Eye,
  Plus,
  RefreshCw,
  RotateCcw,
  Save,
  Search,
  Trash2,
  UserPlus,
  X,
} from 'lucide-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import type {
  DipaAccount,
  Employee,
  LogoSettings,
  MasterCategoryKey,
  MasterOptions,
  Signatory,
  SuratTugasRecord,
  SuratTugasTab,
} from '../types';
import {
  BULAN_INDONESIA,
  angkaTerbilang,
  composeMenimbangText,
  composeNomorSuratBksda,
  formatHariKegiatanIndonesia,
  formatNipSpaced,
  formatRentangTanggalIndonesia,
  formatTanggalIndonesia,
  getNextNomorStSequence,
  getTodayIsoDate,
  hitungLamaHari,
  parseIsoDateParts,
} from '../utils/dateUtils';
import { generateSuratTugasDocx } from '../utils/docxGenerator';

interface CreateLetterViewProps {
  employees: Employee[];
  signatories: Signatory[];
  dipaAccounts: DipaAccount[];
  masterOptions: MasterOptions;
  logoSettings: LogoSettings;
  existingLetters: SuratTugasRecord[];
  editingRecord: SuratTugasRecord | null;
  onCancelEdit: () => void;
  onSaveLetter: (record: SuratTugasRecord, isUpdate: boolean) => void;
  onOpenPreview: (record: SuratTugasRecord) => void;
  onNavigateTab: (
    tab: SuratTugasTab,
    masterCategory?: MasterCategoryKey
  ) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

interface EmployeeSlotComboboxProps {
  index: number;
  selectedEmployee: Employee | null;
  employees: Employee[];
  usedEmployeeIds: Set<string>;
  canRemove: boolean;
  canMoveUp: boolean;
  canMoveDown: boolean;
  onSelect: (emp: Employee | null) => void;
  onMove: (dir: -1 | 1) => void;
  onRemoveSlot: () => void;
}

function EmployeeSlotCombobox({
  index,
  selectedEmployee,
  employees,
  usedEmployeeIds,
  canRemove,
  canMoveUp,
  canMoveDown,
  onSelect,
  onMove,
  onRemoveSlot,
}: EmployeeSlotComboboxProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return employees
      .filter(
        (emp) =>
          emp.id === selectedEmployee?.id || !usedEmployeeIds.has(emp.id)
      )
      .filter((emp) => {
        if (!q) return true;
        return (
          emp.nama.toLowerCase().includes(q) ||
          emp.nip.toLowerCase().includes(q) ||
          emp.jabatan.toLowerCase().includes(q) ||
          emp.unit.toLowerCase().includes(q)
        );
      })
      .slice(0, 15);
  }, [employees, query, selectedEmployee?.id, usedEmployeeIds]);

  return (
    <div ref={containerRef} className="space-y-1.5">
      <div className="flex items-center justify-between gap-2">
        <label className="text-xs font-semibold text-slate-800">
          Pegawai {index + 1}{' '}
          {index === 0 && <span className="text-red-600">*</span>}
        </label>
        <div className="flex items-center gap-1">
          {canMoveUp && (
            <button
              type="button"
              onClick={() => onMove(-1)}
              title="Pindah ke atas"
              className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          )}
          {canMoveDown && (
            <button
              type="button"
              onClick={() => onMove(1)}
              title="Pindah ke bawah"
              className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <ArrowDown className="w-3.5 h-3.5" />
            </button>
          )}
          {selectedEmployee && (
            <button
              type="button"
              onClick={() => onSelect(null)}
              title="Kosongkan pilihan pegawai"
              className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          {canRemove && (
            <button
              type="button"
              onClick={onRemoveSlot}
              title="Hapus baris pegawai"
              className="p-1 rounded text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      <div className="relative">
        <button
          type="button"
          onClick={() => setOpen((prev) => !prev)}
          className="w-full flex items-center justify-between gap-2 px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-left text-sm hover:border-slate-400 focus:outline-none focus:border-[#064e3b] transition cursor-pointer"
        >
          {selectedEmployee ? (
            <span className="truncate font-medium text-slate-900">
              {selectedEmployee.nama}{' '}
              <span className="text-xs font-mono text-slate-500">
                ({formatNipSpaced(selectedEmployee.nip)})
              </span>
            </span>
          ) : (
            <span className="truncate text-slate-400">
              Pilih atau cari pegawai dari Master Pegawai...
            </span>
          )}
          <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
        </button>

        {open && (
          <div className="absolute z-30 left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
            <div className="p-2 border-b border-slate-100 bg-slate-50/70">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Ketik nama, NIP, jabatan, atau resor..."
                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-[#064e3b]"
                />
              </div>
            </div>
            <div className="max-h-56 overflow-y-auto divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <div className="px-3.5 py-3 text-xs text-slate-500">
                  Tidak ada pegawai yang cocok.
                </div>
              ) : (
                filtered.map((emp) => (
                  <button
                    key={emp.id}
                    type="button"
                    onClick={() => {
                      onSelect(emp);
                      setQuery('');
                      setOpen(false);
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-emerald-50/70 transition cursor-pointer"
                  >
                    <div className="text-xs font-semibold text-slate-900 truncate">
                      {emp.nama}
                    </div>
                    <div className="text-[11px] text-slate-500 truncate mt-0.5">
                      <span className="font-mono tabular-nums">
                        {formatNipSpaced(emp.nip)}
                      </span>{' '}
                      · {emp.pangkatGolongan} · {emp.jabatan}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {selectedEmployee && (
        <div className="px-3 py-1.5 bg-slate-50 border border-slate-200/80 rounded-lg text-[11px] text-slate-600 flex flex-wrap gap-x-3 gap-y-0.5">
          <span>
            <strong className="text-slate-700">Pangkat/Gol:</strong>{' '}
            {selectedEmployee.pangkatGolongan || '-'}
          </span>
          <span>
            <strong className="text-slate-700">Jabatan:</strong>{' '}
            {selectedEmployee.jabatan || '-'}
          </span>
        </div>
      )}
    </div>
  );
}

const DEFAULT_KODE_KLASIFIKASI = 'TU';

export default function CreateLetterView({
  employees,
  signatories,
  dipaAccounts,
  masterOptions,
  logoSettings,
  existingLetters,
  editingRecord,
  onCancelEdit,
  onSaveLetter,
  onOpenPreview,
  onNavigateTab,
  onNotify,
}: CreateLetterViewProps) {
  const defaultSignatory =
    signatories.find((s) => s.isDefault) || signatories[0];
  const defaultDipa = dipaAccounts.find((d) => d.isDefault) || dipaAccounts[0];
  const today = getTodayIsoDate();
  const todayParts = parseIsoDateParts(today) || {
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
    day: new Date().getDate(),
  };

  // 01. Jenis Surat & Sumber Pembiayaan
  const [pakaiDipa, setPakaiDipa] = useState(true);
  const [dipaId, setDipaId] = useState(defaultDipa?.id || '');
  const [dipaNomor, setDipaNomor] = useState(
    defaultDipa?.nomorDipa || 'DIPA Nomor SP DIPA-029.05.2.426945/2026'
  );
  const [dipaTahun, setDipaTahun] = useState(
    defaultDipa?.tahunAnggaran || String(todayParts.year)
  );
  const [dipaTanggal, setDipaTanggal] = useState(
    defaultDipa?.tanggalDipa || '2 Desember 2025'
  );

  // 02. Penomoran & Tanggal Surat
  const [nomorSt, setNomorSt] = useState('');
  const [kodeKlasifikasi, setKodeKlasifikasi] = useState(
    DEFAULT_KODE_KLASIFIKASI
  );
  const [bulanNomor, setBulanNomor] = useState<number>(todayParts.month);
  const [tahunNomor, setTahunNomor] = useState<string>(String(todayParts.year));
  const [tanggalSurat, setTanggalSurat] = useState(today);
  const [tempatDitetapkan, setTempatDitetapkan] = useState('Jakarta');

  // 03. Konsiderans (Menimbang) & Dasar Surat
  const [jenisDasarKegiatan, setJenisDasarKegiatan] = useState('');
  const [lokasiWilayahKerja, setLokasiWilayahKerja] = useState('');
  const [tindakLanjut, setTindakLanjut] = useState('');
  const [dasarHukum, setDasarHukum] = useState<string[]>(['']);

  // 04. Daftar Pegawai yang Ditugaskan (slot-based)
  const [employeeSlots, setEmployeeSlots] = useState<(Employee | null)[]>([
    null,
  ]);
  const [formatKepada, setFormatKepada] = useState<'otomatis' | 'langsung'>(
    'otomatis'
  );

  // 05. Pelaksanaan Kegiatan
  const [maksudTugas, setMaksudTugas] = useState('');
  const [lokasiTugas, setLokasiTugas] = useState('');
  const [tanggalMulai, setTanggalMulai] = useState(today);
  const [tanggalSelesai, setTanggalSelesai] = useState(today);
  const [hariKegiatanText, setHariKegiatanText] = useState('');
  const [tanggalKegiatanText, setTanggalKegiatanText] = useState('');
  const [showCalendarHelper, setShowCalendarHelper] = useState(false);

  // 06. Otorisasi & Pejabat Penandatangan
  const [penandatanganId, setPenandatanganId] = useState(
    defaultSignatory?.id || ''
  );

  // 07. Tembusan (Opsional)
  const [tembusan, setTembusan] = useState<string[]>([]);

  const [isDownloading, setIsDownloading] = useState(false);

  // Muat form saat mengedit atau menduplikat surat
  useEffect(() => {
    if (!editingRecord) return;
    setPakaiDipa(Boolean(editingRecord.pakaiDipa));
    setDipaId(editingRecord.dipaId || defaultDipa?.id || '');
    setDipaNomor(
      editingRecord.dipaSnapshot?.nomorDipa ||
        defaultDipa?.nomorDipa ||
        'DIPA Nomor SP DIPA-029.05.2.426945/2026'
    );
    setDipaTahun(
      editingRecord.dipaSnapshot?.tahunAnggaran ||
        defaultDipa?.tahunAnggaran ||
        '2026'
    );
    setDipaTanggal(
      editingRecord.dipaSnapshot?.tanggalDipa ||
        defaultDipa?.tanggalDipa ||
        '2 Desember 2025'
    );

    const parsedDate = parseIsoDateParts(editingRecord.tanggalSurat);
    const extractedSeq =
      editingRecord.nomorSt !== undefined
        ? editingRecord.nomorSt
        : /^ST\.(\d+)/i.exec(editingRecord.nomorSurat || '')?.[1] || '';

    setNomorSt(extractedSeq);
    setKodeKlasifikasi(
      editingRecord.kodeKlasifikasi || DEFAULT_KODE_KLASIFIKASI
    );
    setBulanNomor(
      editingRecord.bulanNomor || parsedDate?.month || todayParts.month
    );
    setTahunNomor(
      editingRecord.tahunNomor ||
        String(parsedDate?.year || todayParts.year)
    );
    setTanggalSurat(editingRecord.tanggalSurat || getTodayIsoDate());
    setTempatDitetapkan(editingRecord.tempatDitetapkan || 'Jakarta');

    setJenisDasarKegiatan(editingRecord.jenisDasarKegiatan || '');
    setLokasiWilayahKerja(
      editingRecord.lokasiWilayahKerja || editingRecord.lokasiTugas || ''
    );
    setTindakLanjut(editingRecord.tindakLanjut || '');
    setDasarHukum(
      editingRecord.dasarHukum.length > 0 ? editingRecord.dasarHukum : ['']
    );

    setEmployeeSlots(
      editingRecord.pegawaiSnapshot.length > 0
        ? editingRecord.pegawaiSnapshot
        : [null]
    );
    setFormatKepada(
      editingRecord.formatKepada === 'langsung' ? 'langsung' : 'otomatis'
    );

    setMaksudTugas(editingRecord.maksudTugas || '');
    setLokasiTugas(editingRecord.lokasiTugas || '');
    setTanggalMulai(editingRecord.tanggalMulai || getTodayIsoDate());
    setTanggalSelesai(editingRecord.tanggalSelesai || getTodayIsoDate());
    setHariKegiatanText(
      editingRecord.hariKegiatanText ||
        formatHariKegiatanIndonesia(
          editingRecord.tanggalMulai,
          editingRecord.tanggalSelesai
        )
    );
    setTanggalKegiatanText(
      editingRecord.tanggalKegiatanText ||
        formatRentangTanggalIndonesia(
          editingRecord.tanggalMulai,
          editingRecord.tanggalSelesai
        )
    );

    setPenandatanganId(
      editingRecord.penandatanganId || defaultSignatory?.id || ''
    );
    setTembusan(editingRecord.tembusan || []);
  }, [editingRecord, defaultDipa, defaultSignatory?.id, todayParts.month, todayParts.year]);

  // Pastikan tanggal selesai tidak sebelum tanggal mulai
  useEffect(() => {
    if (tanggalSelesai && tanggalMulai && tanggalSelesai < tanggalMulai) {
      setTanggalSelesai(tanggalMulai);
    }
  }, [tanggalMulai, tanggalSelesai]);

  const selectedEmployees = useMemo(
    () => employeeSlots.filter((e): e is Employee => e !== null),
    [employeeSlots]
  );

  const usedEmployeeIds = useMemo(
    () => new Set(selectedEmployees.map((e) => e.id)),
    [selectedEmployees]
  );

  const nextAutoSequence = useMemo(
    () => getNextNomorStSequence(existingLetters, tahunNomor),
    [existingLetters, tahunNomor]
  );

  const composedNomorSurat = useMemo(
    () =>
      composeNomorSuratBksda({
        nomorSt,
        kodeKlasifikasi,
        bulan: bulanNomor,
        tahun: tahunNomor,
      }),
    [nomorSt, kodeKlasifikasi, bulanNomor, tahunNomor]
  );

  const lamaHari = useMemo(
    () => hitungLamaHari(tanggalMulai, tanggalSelesai),
    [tanggalMulai, tanggalSelesai]
  );

  const menimbangPreview = useMemo(
    () =>
      composeMenimbangText({
        jenisDasarKegiatan,
        lokasiWilayahKerja,
        tindakLanjut,
      }),
    [jenisDasarKegiatan, lokasiWilayahKerja, tindakLanjut]
  );

  const activeSignatory = useMemo(
    () =>
      signatories.find((s) => s.id === penandatanganId) ||
      editingRecord?.penandatanganSnapshot ||
      defaultSignatory,
    [signatories, penandatanganId, editingRecord, defaultSignatory]
  );

  const activeDipaBase = useMemo(
    () =>
      dipaAccounts.find((d) => d.id === dipaId) ||
      editingRecord?.dipaSnapshot ||
      defaultDipa ||
      null,
    [dipaAccounts, dipaId, editingRecord, defaultDipa]
  );

  const effectiveDipaSnapshot: DipaAccount | null = useMemo(() => {
    if (!pakaiDipa) return null;
    return {
      id: activeDipaBase?.id || 'dipa-custom',
      kodeAkun: activeDipaBase?.kodeAkun || '524111',
      uraian: activeDipaBase?.uraian || 'Anggaran DIPA Balai KSDA Jakarta',
      nomorDipa: dipaNomor.trim() || 'DIPA Nomor SP DIPA-029.05.2.426945/2026',
      tahunAnggaran: dipaTahun.trim() || '2026',
      tanggalDipa: dipaTanggal.trim() || '2 Desember 2025',
    };
  }, [pakaiDipa, activeDipaBase, dipaNomor, dipaTahun, dipaTanggal]);

  const kodeKlasifikasiOptions = useMemo(() => {
    const base = masterOptions.kodeKlasifikasi || [
      { id: 'kk-tu', label: 'TU — Sub Bagian Tata Usaha', value: 'TU' },
      { id: 'kk-skw1', label: 'SKW1 — Seksi KSDA Wilayah I', value: 'SKW1' },
    ];
    if (
      kodeKlasifikasi &&
      !base.some((item) => item.value === kodeKlasifikasi)
    ) {
      return [
        { id: 'kk-current', label: kodeKlasifikasi, value: kodeKlasifikasi },
        ...base,
      ];
    }
    return base;
  }, [masterOptions.kodeKlasifikasi, kodeKlasifikasi]);

  const handleSelectDipaPreset = (id: string) => {
    setDipaId(id);
    const found = dipaAccounts.find((d) => d.id === id);
    if (found) {
      setDipaNomor(found.nomorDipa);
      setDipaTahun(found.tahunAnggaran);
      setDipaTanggal(found.tanggalDipa || '2 Desember 2025');
    }
  };

  const handleTanggalSuratChange = (val: string) => {
    setTanggalSurat(val);
    const parts = parseIsoDateParts(val);
    if (parts) {
      setBulanNomor(parts.month);
      setTahunNomor(String(parts.year));
    }
  };

  const handleApplyCalendarDates = (start: string, end: string) => {
    const safeEnd = end && start && end < start ? start : end || start;
    setTanggalMulai(start);
    setTanggalSelesai(safeEnd);
    if (start) {
      setHariKegiatanText(formatHariKegiatanIndonesia(start, safeEnd));
      setTanggalKegiatanText(formatRentangTanggalIndonesia(start, safeEnd));
    }
  };

  const handleMoveSlot = (index: number, direction: -1 | 1) => {
    setEmployeeSlots((prev) => {
      const target = index + direction;
      if (target < 0 || target >= prev.length) return prev;
      const copy = [...prev];
      const [item] = copy.splice(index, 1);
      copy.splice(target, 0, item);
      return copy;
    });
  };

  const handleResetForm = () => {
    const freshToday = getTodayIsoDate();
    const freshParts = parseIsoDateParts(freshToday) || todayParts;
    if (editingRecord) onCancelEdit();
    setPakaiDipa(true);
    setDipaId(defaultDipa?.id || '');
    setDipaNomor(
      defaultDipa?.nomorDipa || 'DIPA Nomor SP DIPA-029.05.2.426945/2026'
    );
    setDipaTahun(defaultDipa?.tahunAnggaran || String(freshParts.year));
    setDipaTanggal(defaultDipa?.tanggalDipa || '2 Desember 2025');

    setNomorSt('');
    setKodeKlasifikasi(DEFAULT_KODE_KLASIFIKASI);
    setBulanNomor(freshParts.month);
    setTahunNomor(String(freshParts.year));
    setTanggalSurat(freshToday);
    setTempatDitetapkan('Jakarta');

    setJenisDasarKegiatan('');
    setLokasiWilayahKerja('');
    setTindakLanjut('');
    setDasarHukum(['']);

    setEmployeeSlots([null]);
    setFormatKepada('otomatis');

    setMaksudTugas('');
    setLokasiTugas('');
    setTanggalMulai(freshToday);
    setTanggalSelesai(freshToday);
    setHariKegiatanText('');
    setTanggalKegiatanText('');
    setShowCalendarHelper(false);

    setPenandatanganId(defaultSignatory?.id || '');
    setTembusan([]);
    onNotify('info', 'Formulir Surat Tugas telah dikosongkan.');
  };

  const buildRecord = (): SuratTugasRecord | null => {
    const cleanDasar = dasarHukum.map((d) => d.trim()).filter(Boolean);
    if (cleanDasar.length === 0) {
      onNotify('error', 'Minimal satu poin Dasar Surat wajib diisi.');
      return null;
    }
    if (selectedEmployees.length === 0) {
      onNotify('error', 'Pilih minimal satu Pegawai yang Ditugaskan.');
      return null;
    }
    if (!maksudTugas.trim()) {
      onNotify('error', 'Jenis / Uraian Kegiatan wajib diisi.');
      return null;
    }
    if (!lokasiTugas.trim()) {
      onNotify('error', 'Lokasi Kegiatan wajib diisi.');
      return null;
    }
    if (!hariKegiatanText.trim() || !tanggalKegiatanText.trim()) {
      onNotify(
        'error',
        'Hari Kegiatan dan Tanggal Kegiatan wajib diisi (atau gunakan tombol Isi dari Kalender).'
      );
      return null;
    }
    if (!activeSignatory) {
      onNotify('error', 'Pejabat Penandatangan wajib dipilih.');
      return null;
    }

    const nowIso = new Date().toISOString();
    return {
      id: editingRecord ? editingRecord.id : `st-${Date.now()}`,
      nomorSurat: composedNomorSurat,
      nomorSt: nomorSt.trim(),
      bulanNomor,
      tahunNomor: tahunNomor.trim() || String(todayParts.year),
      kodeKlasifikasi: kodeKlasifikasi.trim() || DEFAULT_KODE_KLASIFIKASI,
      jenisDasarKegiatan: jenisDasarKegiatan.trim(),
      lokasiWilayahKerja: lokasiWilayahKerja.trim(),
      tindakLanjut: tindakLanjut.trim(),
      dasarHukum: cleanDasar,
      pegawaiIds: selectedEmployees.map((e) => e.id),
      pegawaiSnapshot: selectedEmployees,
      formatKepada,
      maksudTugas: maksudTugas.trim(),
      lokasiTugas: lokasiTugas.trim(),
      tanggalMulai,
      tanggalSelesai,
      hariKegiatanText: hariKegiatanText.trim(),
      tanggalKegiatanText: tanggalKegiatanText.trim(),
      lamaHari,
      tanggalSurat,
      tempatDitetapkan: tempatDitetapkan.trim() || 'Jakarta',
      penandatanganId: activeSignatory.id,
      penandatanganSnapshot: activeSignatory,
      dipaId: effectiveDipaSnapshot ? effectiveDipaSnapshot.id : '',
      dipaSnapshot: effectiveDipaSnapshot,
      pakaiDipa,
      tembusan: tembusan.map((t) => t.trim()).filter(Boolean),
      catatanTambahan: '',
      createdAt: editingRecord ? editingRecord.createdAt : nowIso,
      updatedAt: nowIso,
    };
  };

  const handlePreviewClick = () => {
    const rec = buildRecord();
    if (rec) onOpenPreview(rec);
  };

  const handleSaveClick = () => {
    const rec = buildRecord();
    if (!rec) return;
    onSaveLetter(rec, Boolean(editingRecord));
  };

  const handleSaveAndDownload = async () => {
    const rec = buildRecord();
    if (!rec) return;
    setIsDownloading(true);
    try {
      onSaveLetter(rec, Boolean(editingRecord));
      await generateSuratTugasDocx(rec, logoSettings);
      onNotify(
        'success',
        'Surat Tugas disimpan dan dokumen Word (.docx) berhasil diunduh.'
      );
    } catch (err) {
      console.error(err);
      onNotify(
        'error',
        'Surat tersimpan, namun gagal mengunduh file Word (.docx).'
      );
    } finally {
      setIsDownloading(false);
    }
  };

  const nonEmptyDasarCount = dasarHukum.filter((d) => d.trim().length > 0).length;
  const tindakLanjutOptions = masterOptions.tindakLanjut || [];
  const tembusanOptions = masterOptions.tembusan || [];
  const isLampiranMode =
    selectedEmployees.length > 3 && formatKepada !== 'langsung';

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
      {/* Kolom Kiri: Formulir 01–07 */}
      <div className="xl:col-span-8 space-y-5">
        {editingRecord && (
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
            <div>
              <span className="font-semibold">Mode Ubah Surat Tugas: </span>
              <span className="font-mono tabular-nums">
                {editingRecord.nomorSurat}
              </span>
            </div>
            <button
              type="button"
              onClick={handleResetForm}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white border border-amber-300 text-amber-900 hover:bg-amber-100 font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              Batalkan Ubah
            </button>
          </div>
        )}

        {/* 01. Jenis Surat & Sumber Pembiayaan */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0 flex-1">
              <h2 className="text-[15px] font-bold text-slate-900">
                01. Jenis Surat & Sumber Pembiayaan
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Otomatis menampilkan atau menyembunyikan poin pembebanan anggaran DIPA pada dokumen Word.
              </p>
            </div>

            <div className="inline-flex items-center p-1 bg-slate-100 border border-slate-200 rounded-xl shrink-0">
              <button
                type="button"
                onClick={() => setPakaiDipa(true)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold tracking-wide transition whitespace-nowrap cursor-pointer ${
                  pakaiDipa
                    ? 'bg-[#064e3b] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                ST DIPA
              </button>
              <button
                type="button"
                onClick={() => setPakaiDipa(false)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold tracking-wide transition whitespace-nowrap cursor-pointer ${
                  !pakaiDipa
                    ? 'bg-[#064e3b] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                ST NON DIPA
              </button>
            </div>
          </div>

          {pakaiDipa ? (
            <div className="space-y-4 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-800 mb-1.5">
                  Pilih Nomor DIPA Aktif
                </label>
                <div className="flex flex-col sm:flex-row gap-2.5">
                  <select
                    value={dipaId}
                    onChange={(e) => handleSelectDipaPreset(e.target.value)}
                    className="flex-1 px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-[#064e3b]"
                  >
                    {dipaAccounts.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.nomorDipa} (TA {acc.tahunAnggaran}) — Akun{' '}
                        {acc.kodeAkun}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => onNavigateTab('signatories')}
                    className="px-4 py-2.5 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 text-[#065f46] text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Kelola Master DIPA
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Nomor DIPA
                  </label>
                  <input
                    type="text"
                    value={dipaNomor}
                    onChange={(e) => setDipaNomor(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:outline-none focus:bg-white focus:border-[#064e3b]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Tahun DIPA
                  </label>
                  <input
                    type="text"
                    value={dipaTahun}
                    onChange={(e) => setDipaTahun(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono tabular-nums text-slate-900 focus:outline-none focus:bg-white focus:border-[#064e3b]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Tanggal DIPA
                  </label>
                  <input
                    type="text"
                    value={dipaTanggal}
                    onChange={(e) => setDipaTanggal(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:bg-white focus:border-[#064e3b]"
                  />
                </div>
              </div>

              <div className="px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 leading-relaxed">
                <span className="font-semibold text-[#065f46]">
                  Poin 3 Untuk:{' '}
                </span>
                “Kegiatan dibebankan pada Anggaran{' '}
                <span className="font-semibold text-slate-900">
                  {dipaNomor || '-'}
                </span>{' '}
                Balai KSDA Jakarta Tahun{' '}
                <span className="font-semibold text-slate-900">
                  {dipaTahun || '-'}
                </span>{' '}
                tanggal{' '}
                <span className="font-semibold text-slate-900">
                  {dipaTanggal || '-'}
                </span>
                ”
              </div>
            </div>
          ) : (
            <div className="px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 leading-relaxed">
              <span className="font-semibold text-slate-800">
                Mode ST NON DIPA aktif:{' '}
              </span>
              Poin pembebanan anggaran DIPA otomatis disembunyikan sehingga bagian{' '}
              <span className="font-semibold text-slate-900">Untuk</span>{' '}
              terdiri dari 3 poin sesuai template resmi Non-DIPA.
            </div>
          )}
        </section>

        {/* 02. Penomoran & Tanggal Surat */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
          <div>
            <h2 className="text-[15px] font-bold text-slate-900">
              02. Penomoran & Tanggal Surat
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Format resmi:{' '}
              <span className="font-mono font-medium text-[#065f46]">
                ST.[NOMOR]/K.13/[KODE]/Peg.10.05/B/[BULAN]/[TAHUN]
              </span>
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label className="text-xs font-semibold text-slate-800">
                  Nomor ST{' '}
                  <span className="font-normal text-slate-400">(Opsional)</span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setNomorSt(nextAutoSequence);
                    onNotify(
                      'info',
                      `Nomor urut ST diisi otomatis: ${nextAutoSequence}`
                    );
                  }}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#065f46] hover:text-[#064e3b] cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  Auto ({nextAutoSequence})
                </button>
              </div>
              <input
                type="text"
                value={nomorSt}
                onChange={(e) => setNomorSt(e.target.value)}
                placeholder="Kosongkan untuk tulis manual"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-mono tabular-nums text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
              />
              <p className="text-[11px] text-slate-500 mt-1.5 leading-snug">
                Jika dikosongkan, sistem otomatis memberi jarak spasi kosong saat dicetak.
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label className="text-xs font-semibold text-slate-800">
                  Kode Klasifikasi <span className="text-red-600">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => onNavigateTab('master', 'kodeKlasifikasi')}
                  className="text-xs font-semibold text-[#065f46] hover:text-[#064e3b] cursor-pointer"
                >
                  Kelola
                </button>
              </div>
              <select
                value={kodeKlasifikasi}
                onChange={(e) => setKodeKlasifikasi(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-mono text-slate-900 focus:outline-none focus:border-[#064e3b]"
              >
                {kodeKlasifikasiOptions.map((opt) => (
                  <option key={opt.id} value={opt.value}>
                    {opt.value}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-800 mb-1.5">
                Bulan (Angka) <span className="text-red-600">*</span>
              </label>
              <select
                value={bulanNomor}
                onChange={(e) => setBulanNomor(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-[#064e3b]"
              >
                {BULAN_INDONESIA.map((bulan, idx) => (
                  <option key={bulan} value={idx + 1}>
                    {idx + 1} — {bulan}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-800 mb-1.5">
                Tahun <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                value={tahunNomor}
                onChange={(e) => setTahunNomor(e.target.value)}
                placeholder="2026"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm font-mono tabular-nums text-slate-900 focus:outline-none focus:border-[#064e3b]"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-800 mb-1.5">
                Tanggal Penetapan Surat <span className="text-red-600">*</span>
              </label>
              <input
                type="date"
                value={tanggalSurat}
                onChange={(e) => handleTanggalSuratChange(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm tabular-nums text-slate-900 focus:outline-none focus:border-[#064e3b]"
              />
            </div>
          </div>

          <div className="px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl flex flex-wrap items-center justify-between gap-2">
            <div>
              <div className="text-[11px] text-slate-500">
                Hasil penulisan tanggal pada surat
              </div>
              <div className="text-sm font-bold text-slate-900 mt-0.5 tabular-nums">
                {tempatDitetapkan || 'Jakarta'},{' '}
                {formatTanggalIndonesia(tanggalSurat)}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] text-slate-500">
                Pratinjau Nomor Surat
              </div>
              <div className="text-xs font-mono font-semibold text-[#065f46] mt-0.5 whitespace-pre tabular-nums">
                {composedNomorSurat}
              </div>
            </div>
          </div>
        </section>

        {/* 03. Konsiderans (Menimbang) & Dasar Surat */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h2 className="text-[15px] font-bold text-slate-900">
                03. Konsiderans (Menimbang) & Dasar Surat
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Pilih dari dropdown Master Isian atau ketik langsung. Poin Dasar dapat ditambah atau dikurangi sesuai kebutuhan surat.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('master', 'dasarSurat')}
              className="text-xs font-semibold text-[#065f46] hover:text-[#064e3b] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Kelola Master Dropdown
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label className="text-xs font-semibold text-slate-800">
                  Jenis Dasar Kegiatan
                </label>
                <select
                  value=""
                  onChange={(e) => {
                    if (e.target.value) setJenisDasarKegiatan(e.target.value);
                  }}
                  className="max-w-[180px] px-2.5 py-1 bg-emerald-50/70 border border-emerald-200 rounded-lg text-[11px] font-medium text-[#065f46] focus:outline-none focus:border-[#064e3b] cursor-pointer"
                >
                  <option value="">Pilih dari Master...</option>
                  {masterOptions.maksudTugas.map((opt) => (
                    <option key={opt.id} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
              <input
                type="text"
                value={jenisDasarKegiatan}
                onChange={(e) => setJenisDasarKegiatan(e.target.value)}
                placeholder="Contoh: pengamanan kawasan konservasi"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label className="text-xs font-semibold text-slate-800">
                  Lokasi / Wilayah Kerja
                </label>
                <select
                  value=""
                  onChange={(e) => {
                    if (e.target.value) setLokasiWilayahKerja(e.target.value);
                  }}
                  className="max-w-[180px] px-2.5 py-1 bg-emerald-50/70 border border-emerald-200 rounded-lg text-[11px] font-medium text-[#065f46] focus:outline-none focus:border-[#064e3b] cursor-pointer"
                >
                  <option value="">Pilih dari Master...</option>
                  {masterOptions.tempatTujuan.map((opt) => (
                    <option key={opt.id} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
              <input
                type="text"
                value={lokasiWilayahKerja}
                onChange={(e) => setLokasiWilayahKerja(e.target.value)}
                placeholder="Contoh: Suaka Margasatwa Muara Angke, DKI Jakarta"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <label className="text-xs font-semibold text-slate-800">
                Tindak Lanjut
              </label>
              <select
                value=""
                onChange={(e) => {
                  if (e.target.value) setTindakLanjut(e.target.value);
                }}
                className="max-w-[200px] px-2.5 py-1 bg-emerald-50/70 border border-emerald-200 rounded-lg text-[11px] font-medium text-[#065f46] focus:outline-none focus:border-[#064e3b] cursor-pointer"
              >
                <option value="">Pilih dari Master...</option>
                {tindakLanjutOptions.map((opt) => (
                  <option key={opt.id} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
            <textarea
              rows={2}
              value={tindakLanjut}
              onChange={(e) => setTindakLanjut(e.target.value)}
              placeholder="Contoh: patroli pengamanan kawasan serta pemantauan ekosistem mangrove dan satwa liar"
              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
            />
          </div>

          <div className="px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 leading-relaxed">
            <span className="font-semibold text-[#065f46]">
              Pratinjau Menimbang:{' '}
            </span>
            “{menimbangPreview}”
          </div>

          {/* Daftar Dasar Surat */}
          <div className="space-y-3 pt-1">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Daftar Dasar Surat ({nonEmptyDasarCount || dasarHukum.length}{' '}
                poin)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Tambahkan baris sesuai jumlah dasar hukum / surat rujukan. Baris kosong otomatis diabaikan saat dicetak.
              </p>
            </div>

            <div className="space-y-3">
              {dasarHukum.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 border border-slate-200 rounded-xl bg-white space-y-2.5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-800">
                      Dasar {idx + 1}
                    </span>
                    <div className="flex items-center gap-2">
                      <select
                        value=""
                        onChange={(e) => {
                          const val = e.target.value;
                          if (!val) return;
                          setDasarHukum((prev) =>
                            prev.map((v, i) => (i === idx ? val : v))
                          );
                        }}
                        className="max-w-[230px] px-2.5 py-1 bg-emerald-50/70 border border-emerald-200 rounded-lg text-[11px] font-medium text-[#065f46] focus:outline-none focus:border-[#064e3b] cursor-pointer"
                      >
                        <option value="">Sisipkan dari Master Dasar...</option>
                        {masterOptions.dasarSurat.map((opt) => (
                          <option key={opt.id} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                      {dasarHukum.length > 1 && (
                        <button
                          type="button"
                          onClick={() =>
                            setDasarHukum((prev) =>
                              prev.filter((_, i) => i !== idx)
                            )
                          }
                          title="Hapus Dasar"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                  <textarea
                    rows={2}
                    value={item}
                    onChange={(e) =>
                      setDasarHukum((prev) =>
                        prev.map((v, i) => (i === idx ? e.target.value : v))
                      )
                    }
                    placeholder="Contoh: Undang-Undang Nomor 32 Tahun 2024 tentang Perubahan atas UU Nomor 5 Tahun 1990 tentang KSDAE"
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
                  />
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setDasarHukum((prev) => [...prev, ''])}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 text-[#065f46] text-xs font-semibold transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Tambah Dasar ({dasarHukum.length + 1})
            </button>
          </div>
        </section>

        {/* 04. Daftar Pegawai yang Ditugaskan */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h2 className="text-[15px] font-bold text-slate-900">
                04. Daftar Pegawai yang Ditugaskan
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                1–3 pegawai dicetak langsung dalam 1 lembar Surat Tugas. Jika lebih dari 3 pegawai, kolom Kepada otomatis tertulis “Terlampir” dan Halaman 2 (Lampiran Daftar Personil) otomatis dibuat.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('employees')}
              className="text-xs font-semibold text-[#065f46] hover:text-[#064e3b] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Kelola Master Pegawai ({employees.length})
            </button>
          </div>

          <div className="space-y-3.5">
            {employeeSlots.map((slotEmp, idx) => (
              <EmployeeSlotCombobox
                key={idx}
                index={idx}
                selectedEmployee={slotEmp}
                employees={employees}
                usedEmployeeIds={usedEmployeeIds}
                canRemove={employeeSlots.length > 1}
                canMoveUp={idx > 0}
                canMoveDown={idx < employeeSlots.length - 1}
                onSelect={(emp) =>
                  setEmployeeSlots((prev) =>
                    prev.map((item, i) => (i === idx ? emp : item))
                  )
                }
                onMove={(dir) => handleMoveSlot(idx, dir)}
                onRemoveSlot={() =>
                  setEmployeeSlots((prev) => prev.filter((_, i) => i !== idx))
                }
              />
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <button
              type="button"
              onClick={() => setEmployeeSlots((prev) => [...prev, null])}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 text-[#065f46] text-xs font-semibold transition cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" />
              Tambah Pegawai ({employeeSlots.length + 1})
            </button>

            <div className="flex flex-wrap items-center gap-3">
              {selectedEmployees.length > 3 && (
                <div className="inline-flex items-center p-0.5 bg-slate-100 border border-slate-200 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setFormatKepada('otomatis')}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition cursor-pointer ${
                      formatKepada !== 'langsung'
                        ? 'bg-white text-[#064e3b] shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Lampiran (2 Hal)
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormatKepada('langsung')}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition cursor-pointer ${
                      formatKepada === 'langsung'
                        ? 'bg-white text-[#064e3b] shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Padat 1 Hal (10,5 pt)
                  </button>
                </div>
              )}

              <span className="text-xs font-mono tabular-nums text-slate-500">
                {selectedEmployees.length} pegawai dipilih · Cetak:{' '}
                <strong
                  className={
                    isLampiranMode ? 'text-[#065f46]' : 'text-slate-700'
                  }
                >
                  {isLampiranMode
                    ? 'Lampiran (2 lembar — Terlampir)'
                    : selectedEmployees.length > 3
                      ? 'Langsung 1 Hal A4 (10,5 pt)'
                      : 'Langsung (1 lembar)'}
                </strong>
              </span>
            </div>
          </div>
        </section>

        {/* 05. Pelaksanaan Kegiatan */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h2 className="text-[15px] font-bold text-slate-900">
                05. Pelaksanaan Kegiatan
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Uraian perjalanan dinas, lokasi, hari, dan tanggal pelaksanaan kegiatan.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowCalendarHelper((prev) => !prev)}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer ${
                showCalendarHelper
                  ? 'bg-emerald-50 border-emerald-300 text-[#065f46]'
                  : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
              }`}
            >
              <Calendar className="w-3.5 h-3.5 text-[#065f46]" />
              Isi Hari & Tanggal dari Kalender
            </button>
          </div>

          {showCalendarHelper && (
            <div className="p-4 bg-emerald-50/50 border border-emerald-200 rounded-xl grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tanggal Mulai
                </label>
                <input
                  type="date"
                  value={tanggalMulai}
                  onChange={(e) =>
                    handleApplyCalendarDates(e.target.value, tanggalSelesai)
                  }
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs tabular-nums text-slate-900 focus:outline-none focus:border-[#064e3b]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tanggal Selesai
                </label>
                <input
                  type="date"
                  min={tanggalMulai}
                  value={tanggalSelesai}
                  onChange={(e) =>
                    handleApplyCalendarDates(tanggalMulai, e.target.value)
                  }
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs tabular-nums text-slate-900 focus:outline-none focus:border-[#064e3b]"
                />
              </div>
              <div className="flex items-center justify-between gap-2 px-3 py-2 bg-white border border-emerald-200 rounded-lg">
                <div className="text-xs font-semibold text-[#065f46] tabular-nums">
                  {lamaHari} ({angkaTerbilang(lamaHari)}) hari
                </div>
                <button
                  type="button"
                  onClick={() =>
                    handleApplyCalendarDates(tanggalMulai, tanggalSelesai)
                  }
                  className="text-[11px] font-semibold text-[#064e3b] hover:underline cursor-pointer"
                >
                  Terapkan
                </button>
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label className="text-xs font-semibold text-slate-800">
                  Jenis / Uraian Kegiatan{' '}
                  <span className="text-red-600">*</span>
                </label>
                <select
                  value=""
                  onChange={(e) => {
                    if (e.target.value) setMaksudTugas(e.target.value);
                  }}
                  className="max-w-[200px] px-2.5 py-1 bg-emerald-50/70 border border-emerald-200 rounded-lg text-[11px] font-medium text-[#065f46] focus:outline-none focus:border-[#064e3b] cursor-pointer"
                >
                  <option value="">Pilih dari Master...</option>
                  {masterOptions.maksudTugas.map((opt) => (
                    <option key={opt.id} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
              <textarea
                rows={2}
                value={maksudTugas}
                onChange={(e) => setMaksudTugas(e.target.value)}
                placeholder="Contoh: Patroli Pengamanan Kawasan dan Inventarisasi Jenis Burung Air"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label className="text-xs font-semibold text-slate-800">
                  Lokasi Kegiatan <span className="text-red-600">*</span>
                </label>
                <select
                  value=""
                  onChange={(e) => {
                    if (e.target.value) setLokasiTugas(e.target.value);
                  }}
                  className="max-w-[200px] px-2.5 py-1 bg-emerald-50/70 border border-emerald-200 rounded-lg text-[11px] font-medium text-[#065f46] focus:outline-none focus:border-[#064e3b] cursor-pointer"
                >
                  <option value="">Pilih dari Master...</option>
                  {masterOptions.tempatTujuan.map((opt) => (
                    <option key={opt.id} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
              <input
                type="text"
                value={lokasiTugas}
                onChange={(e) => setLokasiTugas(e.target.value)}
                placeholder="Contoh: Suaka Margasatwa Pulau Rambut, Kepulauan Seribu"
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-800 mb-1.5">
                  Hari Kegiatan <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  value={hariKegiatanText}
                  onChange={(e) => setHariKegiatanText(e.target.value)}
                  placeholder="Contoh: Kamis atau Kamis s.d. Jumat"
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-800 mb-1.5">
                  Tanggal Kegiatan <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  value={tanggalKegiatanText}
                  onChange={(e) => setTanggalKegiatanText(e.target.value)}
                  placeholder="Contoh: 26 November 2026 atau 26 s.d. 27 November 2026"
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#064e3b]"
                />
              </div>
            </div>
          </div>
        </section>

        {/* 06. Otorisasi & Pejabat Penandatangan */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h2 className="text-[15px] font-bold text-slate-900">
                06. Otorisasi & Pejabat Penandatangan
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Otomatis mengisi blok tanda tangan kanan bawah lengkap dengan spasi tanda tangan basah.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('signatories')}
              className="text-xs font-semibold text-[#065f46] hover:text-[#064e3b] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Kelola Pejabat Penandatangan
            </button>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              Pejabat Penandatangan <span className="text-red-600">*</span>
            </label>
            <select
              value={penandatanganId}
              onChange={(e) => setPenandatanganId(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-[#064e3b]"
            >
              {signatories.map((sig) => {
                const cleanRole = (sig.jabatanHeader || sig.jabatan)
                  .replace(/\n/g, ' ')
                  .replace(/,\s*$/, '');
                return (
                  <option key={sig.id} value={sig.id}>
                    {cleanRole} — {sig.nama}
                  </option>
                );
              })}
            </select>
          </div>

          {activeSignatory && (
            <div className="px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <div className="text-[11px] text-slate-500">
                  Jabatan Penandatangan
                </div>
                <div className="text-xs font-bold text-slate-900 mt-0.5 whitespace-pre-line">
                  {(activeSignatory.jabatanHeader || activeSignatory.jabatan).replace(
                    /,\s*$/,
                    ''
                  )}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">Nama Pejabat</div>
                <div className="text-xs font-bold text-slate-900 mt-0.5">
                  {activeSignatory.nama}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">NIP</div>
                <div className="text-xs font-mono font-bold text-slate-900 mt-0.5 tabular-nums">
                  {activeSignatory.nip && activeSignatory.nip !== '-'
                    ? `NIP. ${formatNipSpaced(activeSignatory.nip)}`
                    : '-'}
                </div>
              </div>
            </div>
          )}
        </section>

        {/* 07. Tembusan (Opsional) */}
        <section className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h2 className="text-[15px] font-bold text-slate-900">
                07. Tembusan{' '}
                <span className="font-normal text-slate-400">(Opsional)</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Dicetak pada bagian paling bawah kiri dokumen. Kosongkan jika surat tidak memerlukan tembusan.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('master', 'tembusan')}
              className="text-xs font-semibold text-[#065f46] hover:text-[#064e3b] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Kelola Master Tembusan
            </button>
          </div>

          {tembusan.length === 0 ? (
            <div className="px-4 py-4 border border-dashed border-slate-300 rounded-xl flex flex-wrap items-center justify-between gap-3 bg-slate-50/40">
              <p className="text-xs text-slate-500 max-w-sm leading-relaxed">
                Tidak ada tembusan pada surat ini. Pilih dari Master atau tambah baris jika diperlukan.
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value=""
                  onChange={(e) => {
                    const val = e.target.value;
                    if (!val) return;
                    setTembusan((prev) =>
                      prev.includes(val) ? prev : [...prev, val]
                    );
                  }}
                  className="px-3 py-2 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs font-semibold text-[#065f46] focus:outline-none focus:border-[#064e3b] cursor-pointer"
                >
                  <option value="">+ Pilih dari Master...</option>
                  {tembusanOptions.map((opt) => (
                    <option key={opt.id} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setTembusan([''])}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 text-[#065f46] text-xs font-semibold transition whitespace-nowrap cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Tambah Tembusan
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="space-y-2">
                {tembusan.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="w-6 text-xs font-mono tabular-nums text-slate-500 text-right shrink-0">
                      {idx + 1}.
                    </span>
                    <input
                      type="text"
                      value={item}
                      onChange={(e) =>
                        setTembusan((prev) =>
                          prev.map((v, i) => (i === idx ? e.target.value : v))
                        )
                      }
                      placeholder="Contoh: Kepala Sub Bagian Tata Usaha Balai KSDA Jakarta"
                      className="flex-1 px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:border-[#064e3b]"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setTembusan((prev) => prev.filter((_, i) => i !== idx))
                      }
                      title="Hapus tembusan"
                      className="p-2 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value=""
                  onChange={(e) => {
                    const val = e.target.value;
                    if (!val) return;
                    setTembusan((prev) => {
                      const cleaned = prev.filter((x) => x.trim().length > 0);
                      return cleaned.includes(val) ? prev : [...cleaned, val];
                    });
                  }}
                  className="px-3 py-2 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs font-semibold text-[#065f46] focus:outline-none focus:border-[#064e3b] cursor-pointer"
                >
                  <option value="">+ Pilih dari Master...</option>
                  {tembusanOptions.map((opt) => (
                    <option key={opt.id} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setTembusan((prev) => [...prev, ''])}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 text-[#065f46] text-xs font-semibold transition cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Tambah Tembusan
                </button>
              </div>
            </div>
          )}
        </section>
      </div>

      {/* Kolom Kanan: Ringkasan Langsung & Aksi Dokumen */}
      <aside className="xl:col-span-4 xl:sticky xl:top-6 space-y-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900">
              Ringkasan Surat Tugas
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Periksa kelengkapan sebelum menyimpan atau mengunduh dokumen resmi.
            </p>
          </div>

          <dl className="space-y-2.5 text-xs">
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500 shrink-0">Jenis Surat</dt>
              <dd className="font-bold text-[#065f46] text-right">
                {pakaiDipa ? 'ST DIPA (4 poin Untuk)' : 'ST NON DIPA (3 poin)'}
              </dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500 shrink-0">Nomor Surat</dt>
              <dd className="font-mono font-semibold text-slate-900 text-right break-all whitespace-pre-wrap tabular-nums">
                {composedNomorSurat}
              </dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500 shrink-0">Tanggal Penetapan</dt>
              <dd className="font-medium text-slate-900 text-right tabular-nums">
                {tempatDitetapkan}, {formatTanggalIndonesia(tanggalSurat)}
              </dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500 shrink-0">Pegawai</dt>
              <dd className="font-medium text-slate-900 text-right tabular-nums">
                {selectedEmployees.length} orang (
                {isLampiranMode ? 'Terlampir · 2 lembar' : '1 lembar'})
              </dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500 shrink-0">Hari / Tanggal</dt>
              <dd className="font-medium text-slate-900 text-right">
                {hariKegiatanText || '-'}
                {tanggalKegiatanText ? `, ${tanggalKegiatanText}` : ''}
              </dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500 shrink-0">Penandatangan</dt>
              <dd className="font-medium text-slate-900 text-right truncate">
                {activeSignatory?.nama || '-'}
              </dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500 shrink-0">Ukuran Kertas</dt>
              <dd className="font-medium text-slate-900 text-right">
                {logoSettings.paperSize === 'F4'
                  ? 'F4 / Folio (210 × 330 mm)'
                  : 'A4 (210 × 297 mm)'}
              </dd>
            </div>
          </dl>

          <div className="pt-3 border-t border-slate-100 space-y-2">
            <button
              type="button"
              onClick={() => void handleSaveAndDownload()}
              disabled={isDownloading}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#064e3b] hover:bg-[#065f46] disabled:opacity-60 text-white text-xs font-semibold transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              {isDownloading
                ? 'Menyimpan & Mengunduh...'
                : editingRecord
                  ? 'Simpan Perubahan & Unduh .docx'
                  : 'Simpan & Unduh Word (.docx)'}
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handlePreviewClick}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold transition whitespace-nowrap cursor-pointer"
              >
                <Eye className="w-4 h-4 text-[#065f46]" />
                Pratinjau
              </button>
              <button
                type="button"
                onClick={handleSaveClick}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold transition whitespace-nowrap cursor-pointer"
              >
                <Save className="w-4 h-4 text-[#065f46]" />
                {editingRecord ? 'Perbarui' : 'Simpan Saja'}
              </button>
            </div>

            <button
              type="button"
              onClick={handleResetForm}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 text-xs font-medium transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Formulir
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
}
