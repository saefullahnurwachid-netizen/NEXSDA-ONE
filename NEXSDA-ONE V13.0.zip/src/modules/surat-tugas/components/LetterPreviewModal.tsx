import { Download, Printer, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { LogoSettings, SuratTugasRecord } from '../types';
import {
  composeMenimbangText,
  formatNipSpaced,
  formatTanggalIndonesia,
} from '../utils/dateUtils';
import {
  buildUntukPoints,
  formatDasarItems,
  generateSuratTugasDocx,
  getBodyFontPt,
  getPrintableNomorSurat,
  isRecordLampiranMode,
} from '../utils/docxGenerator';

interface LetterPreviewModalProps {
  record: SuratTugasRecord | null;
  logoSettings: LogoSettings;
  onClose: () => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

function DefaultKemenhutEmblemSvg() {
  return (
    <svg
      viewBox="0 0 100 100"
      style={{ width: '1.9cm', height: '1.9cm' }}
      className="block mx-auto shrink-0"
      aria-label="Lambang Kementerian Kehutanan"
    >
      <defs>
        <clipPath id="kemenhut-circle-clip">
          <circle cx="50" cy="50" r="46" />
        </clipPath>
      </defs>
      <g clipPath="url(#kemenhut-circle-clip)">
        <path
          d="M0 0 H100 V58 C78 46 62 46 50 58 C38 46 22 46 0 58 Z"
          fill="#231f20"
        />
        <path
          d="M0 54 C24 44 39 50 50 64 C61 50 76 44 100 54 V100 H0 Z"
          fill="#808285"
        />
        <path
          d="M47 84 C47 64 41 48 25 32 L30 28 C41 39 46 49 48 61 V22 H52 V61 C54 49 59 39 70 28 L75 32 C59 48 53 64 53 84 Z"
          fill="#ffffff"
        />
        <path
          d="M49 54 C41 46 31 44 18 46 L19 41 C31 39 42 42 49 49 Z"
          fill="#ffffff"
        />
        <path
          d="M51 54 C59 46 69 44 82 46 L81 41 C69 39 58 42 51 49 Z"
          fill="#ffffff"
        />
        <ellipse cx="50" cy="14" rx="4" ry="7" fill="#ffffff" />
        <ellipse
          cx="36"
          cy="19"
          rx="3.5"
          ry="6"
          transform="rotate(-24 36 19)"
          fill="#ffffff"
        />
        <ellipse
          cx="64"
          cy="19"
          rx="3.5"
          ry="6"
          transform="rotate(24 64 19)"
          fill="#ffffff"
        />
        <ellipse
          cx="22"
          cy="30"
          rx="3.2"
          ry="5.5"
          transform="rotate(-48 22 30)"
          fill="#ffffff"
        />
        <ellipse
          cx="78"
          cy="30"
          rx="3.2"
          ry="5.5"
          transform="rotate(48 78 30)"
          fill="#ffffff"
        />
        <path d="M16 86 Q50 76 84 86 L84 91 Q50 81 16 91 Z" fill="#ffffff" />
      </g>
    </svg>
  );
}

function SignatureTableBlock({
  record,
  logoSettings,
}: {
  record: SuratTugasRecord;
  logoSettings: LogoSettings;
}) {
  const sig = record.penandatanganSnapshot;
  const sigHeaderLines = (sig.jabatanHeader || sig.jabatan || 'Kepala Balai,')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);

  return (
    <table
      className="border-collapse st-no-break"
      style={{
        width: '18.46cm',
        tableLayout: 'fixed',
        marginTop: '16pt',
        fontSize: '11pt',
        lineHeight: 1.15,
      }}
    >
      <colgroup>
        <col style={{ width: '12.06cm' }} />
        <col style={{ width: '6.4cm' }} />
      </colgroup>
      <tbody>
        <tr>
          <td style={{ padding: 0 }} />
          <td style={{ padding: 0, textAlign: 'left', verticalAlign: 'top' }}>
            <div>
              {record.tempatDitetapkan || 'Jakarta'},{' '}
              {formatTanggalIndonesia(record.tanggalSurat)}
            </div>
            {sigHeaderLines.map((line, idx) => (
              <div key={idx}>{line}</div>
            ))}

            {logoSettings.showStampSignature &&
            logoSettings.stampSignatureBase64 ? (
              <div style={{ margin: '4pt 0' }}>
                <img
                  src={logoSettings.stampSignatureBase64}
                  alt="Tanda Tangan dan Stempel"
                  referrerPolicy="no-referrer"
                  style={{ height: '50pt', objectFit: 'contain' }}
                />
              </div>
            ) : (
              <div style={{ height: '50pt' }} />
            )}

            <div>{sig.nama}</div>
            {sig.nip && sig.nip !== '-' && (
              <div className="tabular-nums">
                NIP. {formatNipSpaced(sig.nip)}
              </div>
            )}
          </td>
        </tr>
      </tbody>
    </table>
  );
}

export default function LetterPreviewModal({
  record,
  logoSettings,
  onClose,
  onNotify,
}: LetterPreviewModalProps) {
  const [isDownloading, setIsDownloading] = useState(false);
  const [compactOverride, setCompactOverride] = useState<
    'otomatis' | 'langsung' | null
  >(null);

  useEffect(() => {
    setCompactOverride(null);
  }, [record?.id]);

  if (!record) return null;

  const effectiveRecord: SuratTugasRecord = compactOverride
    ? { ...record, formatKepada: compactOverride }
    : record;

  const menimbangText = composeMenimbangText(effectiveRecord);
  const dasarItems = formatDasarItems(effectiveRecord.dasarHukum);
  const untukPoints = buildUntukPoints(effectiveRecord);
  const tembusanItems = (effectiveRecord.tembusan || [])
    .map((t) => t.trim())
    .filter(Boolean);

  const isLampiranMode = isRecordLampiranMode(effectiveRecord);
  const bodyFontPt = getBodyFontPt(effectiveRecord);
  const nomorPrintable = getPrintableNomorSurat(effectiveRecord, true);
  const isF4 = logoSettings.paperSize === 'F4';

  const handleDownloadDocx = async () => {
    setIsDownloading(true);
    try {
      await generateSuratTugasDocx(effectiveRecord, logoSettings);
      onNotify('success', 'Dokumen Word (.docx) Surat Tugas berhasil diunduh.');
    } catch (err) {
      console.error(err);
      onNotify('error', 'Gagal membuat file Word (.docx). Silakan coba lagi.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // Lembar A4 tepat: 21,0 cm × 29,7 cm; Margin: Atas 0.25", Kanan 0.5", Bawah 0.81", Kiri 0.5"; Area cetak = 18,46 cm
  const sheetStyle: React.CSSProperties = {
    width: '21cm',
    minHeight: isF4 ? '33cm' : '29.7cm',
    padding: '0.25in 0.5in 0.81in 0.5in',
    fontFamily: "'Bookman Old Style', 'URW Bookman', Georgia, serif",
    fontSize: `${bodyFontPt}pt`,
    lineHeight: 1.15,
    boxSizing: 'border-box',
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="preview-surat-tugas-title"
      className="fixed inset-0 z-50 flex flex-col bg-slate-950/70 backdrop-blur-xs p-3 sm:p-5 overflow-hidden print:static print:bg-white print:p-0"
    >
      {/* Toolbar Modal (Tersembunyi saat Print / PDF) */}
      <div className="mx-auto w-full max-w-5xl flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-t-xl px-5 py-3.5 print:hidden">
        <div className="min-w-0">
          <h2
            id="preview-surat-tugas-title"
            className="text-sm font-semibold text-slate-900 truncate"
          >
            Pratinjau Dokumen Surat Tugas (A4 — Area Cetak 18,46 cm)
          </h2>
          <p className="text-xs text-slate-500 tabular-nums truncate">
            {effectiveRecord.pakaiDipa ? 'ST DIPA' : 'ST NON DIPA'} · Kop
            Figtree (14/12/16 pt) · Isi Bookman Old Style {bodyFontPt} pt ·
            Kertas {logoSettings.paperSize} ·{' '}
            {effectiveRecord.pegawaiSnapshot.length} pegawai
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {effectiveRecord.pegawaiSnapshot.length > 3 && (
            <div className="inline-flex items-center p-0.5 bg-slate-100 border border-slate-200 rounded-lg">
              <button
                type="button"
                onClick={() => setCompactOverride('otomatis')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition cursor-pointer ${
                  isLampiranMode
                    ? 'bg-white text-[#064e3b] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Lampiran (2 Hal)
              </button>
              <button
                type="button"
                onClick={() => setCompactOverride('langsung')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition cursor-pointer ${
                  !isLampiranMode
                    ? 'bg-white text-[#064e3b] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Padat 1 Hal (10,5 pt)
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Cetak / Simpan PDF
          </button>
          <button
            type="button"
            onClick={() => void handleDownloadDocx()}
            disabled={isDownloading}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#064e3b] hover:bg-[#065f46] disabled:opacity-60 text-white text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            {isDownloading ? 'Menyiapkan...' : 'Unduh Word (.docx)'}
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup pratinjau"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Kanvas Dokumen Resmi A4 Presisi */}
      <div className="mx-auto w-full max-w-5xl flex-1 overflow-auto bg-slate-200/80 border-x border-b border-slate-200 rounded-b-xl p-4 sm:p-6 space-y-6 print:space-y-0 print:overflow-visible print:bg-white print:border-0 print:p-0 print:max-w-none">
        {/* HALAMAN 1: SURAT TUGAS */}
        <div
          id="surat-tugas-print-sheet"
          className={`st-print-sheet mx-auto bg-white text-black shadow-sm border border-slate-300 ${
            tembusanItems.length > 0 ? 'st-has-tembusan' : ''
          }`}
          style={{
            ...sheetStyle,
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <div style={{ flex: '1 0 auto' }}>
          {/* 1. TABEL KOP SURAT (2,0 cm + 16,46 cm = 18,46 cm — Font Figtree) */}
          <table
            className="border-collapse"
            style={{
              width: '18.46cm',
              tableLayout: 'fixed',
              fontFamily: "'Figtree', Arial, Helvetica, sans-serif",
            }}
          >
            <colgroup>
              <col style={{ width: '2.0cm' }} />
              <col style={{ width: '16.46cm' }} />
            </colgroup>
            <tbody>
              <tr>
                <td
                  style={{
                    padding: 0,
                    verticalAlign: 'middle',
                    textAlign: 'center',
                  }}
                >
                  {logoSettings.logoBase64 ? (
                    <img
                      src={logoSettings.logoBase64}
                      alt="Logo Kementerian Kehutanan"
                      referrerPolicy="no-referrer"
                      style={{
                        width: '1.9cm',
                        height: '1.9cm',
                        objectFit: 'contain',
                        display: 'block',
                        margin: '0 auto',
                      }}
                    />
                  ) : (
                    <DefaultKemenhutEmblemSvg />
                  )}
                </td>
                <td
                  style={{
                    padding: 0,
                    verticalAlign: 'middle',
                    textAlign: 'center',
                    lineHeight: 1.15,
                  }}
                >
                  <div
                    style={{
                      fontSize: '14pt',
                      fontWeight: 700,
                      textTransform: 'uppercase',
                      margin: '0 0 1pt 0',
                    }}
                  >
                    {logoSettings.ministryLine1 || 'KEMENTERIAN KEHUTANAN'}
                  </div>
                  <div
                    style={{
                      fontSize: '12pt',
                      fontWeight: 700,
                      textTransform: 'uppercase',
                      margin: '0 0 1pt 0',
                    }}
                  >
                    {logoSettings.directorateLine2 ||
                      'DIREKTORAT JENDERAL KONSERVASI SUMBER DAYA ALAM DAN EKOSISTEM'}
                  </div>
                  <div
                    style={{
                      fontSize: '16pt',
                      fontWeight: 700,
                      textTransform: 'uppercase',
                      margin: 0,
                    }}
                  >
                    {logoSettings.agencyLine3 ||
                      'BALAI KONSERVASI SUMBER DAYA ALAM JAKARTA'}
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          {/* Garis Bawah Kop Tebal-Tipis (2 pt) */}
          <div
            style={{
              width: '18.46cm',
              borderTop: '2pt solid #000000',
              paddingTop: '1.5pt',
              marginTop: '3pt',
              marginBottom: '6pt',
            }}
          >
            <div style={{ borderTop: '0.75pt solid #000000' }} />
          </div>

          {/* 2. JUDUL, NOMOR (BOLD) & KEPALA BALAI */}
          <div
            style={{
              width: '18.46cm',
              textAlign: 'center',
              fontSize: '11pt',
              lineHeight: 1.15,
            }}
          >
            <div style={{ fontWeight: 700, marginBottom: '4pt' }}>
              SURAT TUGAS
            </div>
            <div
              className="tabular-nums whitespace-pre-wrap"
              style={{ fontWeight: 700, marginBottom: '4pt' }}
            >
              NOMOR : {nomorPrintable}
            </div>
            <div style={{ fontWeight: 700, marginBottom: '6pt' }}>
              KEPALA BALAI
            </div>
          </div>

          {/* 3. MENIMBANG (2,5 cm + 0,4 cm + 15,56 cm = 18,46 cm) */}
          <table
            className="border-collapse"
            style={{
              width: '18.46cm',
              tableLayout: 'fixed',
              fontSize: `${bodyFontPt}pt`,
              lineHeight: 1.15,
              marginBottom: '6pt',
            }}
          >
            <colgroup>
              <col style={{ width: '2.5cm' }} />
              <col style={{ width: '0.4cm' }} />
              <col style={{ width: '15.56cm' }} />
            </colgroup>
            <tbody>
              <tr style={{ verticalAlign: 'top' }}>
                <td style={{ padding: 0, textAlign: 'left' }}>Menimbang</td>
                <td style={{ padding: 0, textAlign: 'center' }}>:</td>
                <td style={{ padding: 0, textAlign: 'justify' }}>
                  {menimbangText}
                </td>
              </tr>
            </tbody>
          </table>

          {/* 4. DASAR (2,5 cm + 0,4 cm + 0,6 cm + 14,96 cm = 18,46 cm) */}
          <table
            className="border-collapse"
            style={{
              width: '18.46cm',
              tableLayout: 'fixed',
              fontSize: `${bodyFontPt}pt`,
              lineHeight: 1.15,
              marginBottom: '6pt',
            }}
          >
            <colgroup>
              <col style={{ width: '2.5cm' }} />
              <col style={{ width: '0.4cm' }} />
              <col style={{ width: '0.6cm' }} />
              <col style={{ width: '14.96cm' }} />
            </colgroup>
            <tbody>
              {dasarItems.map((item, idx) => {
                const isLast = idx === dasarItems.length - 1;
                const pb = isLast ? '0' : '2.5pt';
                return (
                  <tr key={idx} style={{ verticalAlign: 'top' }}>
                    <td
                      style={{
                        padding: `0 0 ${pb} 0`,
                        textAlign: 'left',
                      }}
                    >
                      {idx === 0 ? 'Dasar' : ''}
                    </td>
                    <td
                      style={{
                        padding: `0 0 ${pb} 0`,
                        textAlign: 'center',
                      }}
                    >
                      {idx === 0 ? ':' : ''}
                    </td>
                    <td
                      className="tabular-nums"
                      style={{
                        padding: `0 0 ${pb} 0`,
                        textAlign: 'left',
                      }}
                    >
                      {idx + 1}.
                    </td>
                    <td
                      style={{
                        padding: `0 0 ${pb} 0`,
                        textAlign: 'justify',
                      }}
                    >
                      {item}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* 5. MEMBERI TUGAS */}
          <div
            style={{
              width: '18.46cm',
              textAlign: 'center',
              fontWeight: 700,
              fontSize: '11pt',
              lineHeight: 1.15,
              marginTop: '6pt',
              marginBottom: '6pt',
            }}
          >
            MEMBERI TUGAS
          </div>

          {/* 6. KEPADA */}
          {isLampiranMode ? (
            <table
              className="border-collapse"
              style={{
                width: '18.46cm',
                tableLayout: 'fixed',
                fontSize: `${bodyFontPt}pt`,
                lineHeight: 1.15,
                marginBottom: '6pt',
              }}
            >
              <colgroup>
                <col style={{ width: '2.5cm' }} />
                <col style={{ width: '0.4cm' }} />
                <col style={{ width: '15.56cm' }} />
              </colgroup>
              <tbody>
                <tr style={{ verticalAlign: 'top' }}>
                  <td style={{ padding: 0, textAlign: 'left' }}>Kepada</td>
                  <td style={{ padding: 0, textAlign: 'center' }}>:</td>
                  <td style={{ padding: 0, textAlign: 'left' }}>Terlampir</td>
                </tr>
              </tbody>
            </table>
          ) : (
            <table
              className="border-collapse"
              style={{
                width: '18.46cm',
                tableLayout: 'fixed',
                fontSize: `${bodyFontPt}pt`,
                lineHeight: 1.15,
                marginBottom: '6pt',
              }}
            >
              {/* 2,5 + 0,4 + 0,6 + 3,2 + 0,4 + 11,36 = 18,46 cm */}
              <colgroup>
                <col style={{ width: '2.5cm' }} />
                <col style={{ width: '0.4cm' }} />
                <col style={{ width: '0.6cm' }} />
                <col style={{ width: '3.2cm' }} />
                <col style={{ width: '0.4cm' }} />
                <col style={{ width: '11.36cm' }} />
              </colgroup>
              <tbody>
                {(effectiveRecord.pegawaiSnapshot.length > 0
                  ? effectiveRecord.pegawaiSnapshot
                  : [
                      {
                        id: 'empty',
                        nama: '-',
                        nip: '-',
                        pangkatGolongan: '-',
                        jabatan: '-',
                        unit: '-',
                      },
                    ]
                ).flatMap((emp, empIdx, arr) => {
                  const namaNip =
                    emp.nip && emp.nip !== '-'
                      ? `${emp.nama} / ${formatNipSpaced(emp.nip)}`
                      : emp.nama;
                  const rows: [string, string][] = [
                    ['Nama / NIP', namaNip],
                    ['Pangkat / Gol.', emp.pangkatGolongan || '-'],
                    ['Jabatan', emp.jabatan || '-'],
                  ];
                  const isVeryLastEmp = empIdx === arr.length - 1;
                  return rows.map(([label, val], fieldIdx) => {
                    const isVeryFirst = empIdx === 0 && fieldIdx === 0;
                    const isEmpFirst = fieldIdx === 0;
                    const isEmpLast = fieldIdx === rows.length - 1;
                    const pb =
                      isEmpLast && isVeryLastEmp
                        ? '0'
                        : isEmpLast
                          ? arr.length > 3
                            ? '2pt'
                            : '3pt'
                          : '1pt';
                    return (
                      <tr
                        key={`${emp.id || empIdx}-${label}`}
                        style={{ verticalAlign: 'top' }}
                      >
                        <td style={{ padding: `0 0 ${pb} 0`, textAlign: 'left' }}>
                          {isVeryFirst ? 'Kepada' : ''}
                        </td>
                        <td
                          style={{ padding: `0 0 ${pb} 0`, textAlign: 'center' }}
                        >
                          {isVeryFirst ? ':' : ''}
                        </td>
                        <td
                          className="tabular-nums"
                          style={{ padding: `0 0 ${pb} 0`, textAlign: 'left' }}
                        >
                          {isEmpFirst ? `${empIdx + 1}.` : ''}
                        </td>
                        <td
                          style={{
                            padding: `0 0 ${pb} 0`,
                            textAlign: 'left',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {label}
                        </td>
                        <td
                          style={{ padding: `0 0 ${pb} 0`, textAlign: 'center' }}
                        >
                          :
                        </td>
                        <td style={{ padding: `0 0 ${pb} 0`, textAlign: 'left' }}>
                          {val}
                        </td>
                      </tr>
                    );
                  });
                })}
              </tbody>
            </table>
          )}

          {/* 7. UNTUK (2,5 cm + 0,4 cm + 0,6 cm + 14,96 cm = 18,46 cm) */}
          <table
            className="border-collapse"
            style={{
              width: '18.46cm',
              tableLayout: 'fixed',
              fontSize: `${bodyFontPt}pt`,
              lineHeight: 1.15,
            }}
          >
            <colgroup>
              <col style={{ width: '2.5cm' }} />
              <col style={{ width: '0.4cm' }} />
              <col style={{ width: '0.6cm' }} />
              <col style={{ width: '14.96cm' }} />
            </colgroup>
            <tbody>
              {untukPoints.map((point, idx) => {
                const isLast = idx === untukPoints.length - 1;
                const pb = isLast ? '0' : '2.5pt';
                return (
                  <tr key={idx} style={{ verticalAlign: 'top' }}>
                    <td style={{ padding: `0 0 ${pb} 0`, textAlign: 'left' }}>
                      {idx === 0 ? 'Untuk' : ''}
                    </td>
                    <td style={{ padding: `0 0 ${pb} 0`, textAlign: 'center' }}>
                      {idx === 0 ? ':' : ''}
                    </td>
                    <td
                      className="tabular-nums"
                      style={{ padding: `0 0 ${pb} 0`, textAlign: 'left' }}
                    >
                      {idx + 1}.
                    </td>
                    <td style={{ padding: `0 0 ${pb} 0`, textAlign: 'justify' }}>
                      {point}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* 8. BLOK TANDA TANGAN (12,06 cm + 6,4 cm = 18,46 cm) */}
          <SignatureTableBlock
            record={effectiveRecord}
            logoSettings={logoSettings}
          />
          </div>

          {/* 9. TEMBUSAN (OPSIONAL — POJOK KIRI BAWAH, TIDAK BOLD & TANPA UNDERLINE) */}
          {tembusanItems.length > 0 && (
            <div
              className="st-no-break"
              style={{
                width: '18.46cm',
                marginTop: 'auto',
                paddingTop: '12pt',
                fontSize: '10pt',
                lineHeight: 1.15,
                textAlign: 'left',
              }}
            >
              <div style={{ marginBottom: '2pt' }}>Tembusan :</div>
              <ol
                style={{
                  margin: 0,
                  paddingLeft: '16pt',
                  listStyleType: 'decimal',
                }}
              >
                {tembusanItems.map((t, idx) => (
                  <li key={idx} style={{ marginBottom: '1pt' }}>
                    {t}
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>

        {/* HALAMAN 2: LAMPIRAN DAFTAR PERSONIL (JIKA > 3 PEGAWAI & MODE LAMPIRAN) */}
        {isLampiranMode && (
          <div
            className="st-print-sheet mx-auto bg-white text-black shadow-sm border border-slate-300 print:break-before-page"
            style={sheetStyle}
          >
            <table
              className="border-collapse"
              style={{
                width: '18.46cm',
                tableLayout: 'fixed',
                fontSize: '10pt',
                lineHeight: 1.15,
                marginBottom: '8pt',
              }}
            >
              <colgroup>
                <col style={{ width: '8.96cm' }} />
                <col style={{ width: '9.5cm' }} />
              </colgroup>
              <tbody>
                <tr>
                  <td style={{ padding: 0 }} />
                  <td style={{ padding: 0, verticalAlign: 'top' }}>
                    <div>Lampiran Surat Tugas Kepala Balai KSDA Jakarta</div>
                    <div className="flex gap-1.5">
                      <span style={{ width: '1.5cm', display: 'inline-block' }}>
                        Nomor
                      </span>
                      <span>:</span>
                      <span className="whitespace-pre-wrap tabular-nums">
                        {nomorPrintable}
                      </span>
                    </div>
                    <div className="flex gap-1.5">
                      <span style={{ width: '1.5cm', display: 'inline-block' }}>
                        Tanggal
                      </span>
                      <span>:</span>
                      <span>
                        {formatTanggalIndonesia(effectiveRecord.tanggalSurat)}
                      </span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>

            <div
              style={{
                width: '18.46cm',
                textAlign: 'center',
                fontWeight: 700,
                fontSize: '11pt',
                marginTop: '6pt',
                marginBottom: '8pt',
              }}
            >
              DAFTAR PEGAWAI YANG DITUGASKAN
            </div>

            <table
              className="border-collapse border border-black"
              style={{
                width: '18.46cm',
                tableLayout: 'fixed',
                fontSize: '10pt',
                lineHeight: 1.15,
              }}
            >
              <colgroup>
                <col style={{ width: '1.1cm' }} />
                <col style={{ width: '6.56cm' }} />
                <col style={{ width: '4.3cm' }} />
                <col style={{ width: '6.5cm' }} />
              </colgroup>
              <thead>
                <tr className="bg-slate-100">
                  <th className="border border-black px-1.5 py-1.5 text-center">
                    No
                  </th>
                  <th className="border border-black px-2 py-1.5 text-left">
                    Nama / NIP
                  </th>
                  <th className="border border-black px-2 py-1.5 text-left">
                    Pangkat / Gol.
                  </th>
                  <th className="border border-black px-2 py-1.5 text-left">
                    Jabatan
                  </th>
                </tr>
              </thead>
              <tbody>
                {effectiveRecord.pegawaiSnapshot.map((emp, idx) => (
                  <tr key={emp.id || idx} style={{ verticalAlign: 'top' }}>
                    <td className="border border-black px-1.5 py-1.5 text-center tabular-nums">
                      {idx + 1}.
                    </td>
                    <td className="border border-black px-2 py-1.5">
                      <div>{emp.nama}</div>
                      {emp.nip && emp.nip !== '-' && (
                        <div
                          className="tabular-nums"
                          style={{ fontSize: '9.5pt' }}
                        >
                          NIP. {formatNipSpaced(emp.nip)}
                        </div>
                      )}
                    </td>
                    <td className="border border-black px-2 py-1.5">
                      {emp.pangkatGolongan || '-'}
                    </td>
                    <td className="border border-black px-2 py-1.5">
                      {emp.jabatan || '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <SignatureTableBlock
              record={effectiveRecord}
              logoSettings={logoSettings}
            />
          </div>
        )}
      </div>
    </div>
  );
}
