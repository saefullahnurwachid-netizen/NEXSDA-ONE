import {
  Download,
  Edit3,
  FileSpreadsheet,
  Plus,
  RefreshCw,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useMemo, useRef, useState } from 'react';
import type { ConfirmDialogConfig, Employee } from '../types';
import { formatNipSpaced } from '../utils/dateUtils';
import {
  downloadEmployeeImportTemplate,
  exportEmployeesToExcel,
  parseEmployeesFromExcel,
} from '../utils/excelUtils';

interface EmployeesViewProps {
  employees: Employee[];
  onSaveEmployee: (employee: Employee, isEdit: boolean) => void;
  onDeleteEmployee: (id: string) => void;
  onImportEmployees: (imported: Employee[]) => void;
  onResyncSk01: () => Promise<void>;
  onConfirm: (config: ConfirmDialogConfig) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

const EMPTY_FORM = {
  id: '',
  nama: '',
  nip: '',
  pangkatGolongan: '',
  jabatan: '',
  unit: '',
};

export default function EmployeesView({
  employees,
  onSaveEmployee,
  onDeleteEmployee,
  onImportEmployees,
  onResyncSk01,
  onConfirm,
  onNotify,
}: EmployeesViewProps) {
  const [query, setQuery] = useState('');
  const [unitFilter, setUnitFilter] = useState('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const unitGroups = useMemo(
    () => [
      { value: 'ALL', label: 'Semua Unit / Seksi' },
      { value: 'Seksi KSDA Wilayah I', label: 'Seksi KSDA Wilayah I' },
      { value: 'Resor Jakarta Pusat', label: 'Resor Jakarta Pusat' },
      { value: 'Resor Jakarta Selatan', label: 'Resor Jakarta Selatan' },
      { value: 'Resor Jakarta Timur', label: 'Resor Jakarta Timur' },
      { value: 'Resor Bekasi', label: 'Resor Bekasi' },
      { value: 'Sub Bagian Tata Usaha', label: 'Sub Bagian Tata Usaha' },
      { value: 'Kantor Balai', label: 'Kantor Balai KSDA Jakarta' },
      { value: 'Seksi KSDA Wilayah II', label: 'Seksi KSDA Wilayah II' },
      { value: 'Seksi KSDA Wilayah III', label: 'Seksi KSDA Wilayah III' },
    ],
    []
  );

  const filteredEmployees = useMemo(() => {
    const q = query.trim().toLowerCase();
    return employees.filter((emp) => {
      if (
        unitFilter !== 'ALL' &&
        !emp.unit.toLowerCase().includes(unitFilter.toLowerCase())
      ) {
        return false;
      }
      if (!q) return true;
      return (
        emp.nama.toLowerCase().includes(q) ||
        emp.nip.toLowerCase().includes(q) ||
        emp.pangkatGolongan.toLowerCase().includes(q) ||
        emp.jabatan.toLowerCase().includes(q) ||
        emp.unit.toLowerCase().includes(q)
      );
    });
  }, [employees, query, unitFilter]);

  const openAddModal = () => {
    setForm(EMPTY_FORM);
    setIsEditMode(false);
    setIsModalOpen(true);
  };

  const openEditModal = (emp: Employee) => {
    setForm({
      id: emp.id,
      nama: emp.nama,
      nip: emp.nip,
      pangkatGolongan: emp.pangkatGolongan,
      jabatan: emp.jabatan,
      unit: emp.unit,
    });
    setIsEditMode(true);
    setIsModalOpen(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nama.trim()) {
      onNotify('error', 'Nama Pegawai wajib diisi.');
      return;
    }
    const payload: Employee = {
      id: isEditMode ? form.id : `emp-${Date.now()}`,
      nama: form.nama.trim(),
      nip: form.nip.replace(/\s+/g, '') || '-',
      pangkatGolongan: form.pangkatGolongan.trim() || '-',
      jabatan: form.jabatan.trim() || '-',
      unit: form.unit.trim() || 'Balai KSDA Jakarta',
      source: 'manual',
    };
    onSaveEmployee(payload, isEditMode);
    setIsModalOpen(false);
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const parsed = await parseEmployeesFromExcel(file);
      if (parsed.length === 0) {
        onNotify(
          'error',
          'Tidak ditemukan data pegawai yang valid pada berkas Excel tersebut.'
        );
        return;
      }
      onImportEmployees(parsed);
    } catch (err) {
      console.error(err);
      onNotify('error', 'Gagal membaca berkas Excel. Pastikan format sesuai template.');
    }
  };

  const handleResync = async () => {
    setIsSyncing(true);
    try {
      await onResyncSk01();
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
        <div className="flex flex-1 flex-wrap items-center gap-2.5">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Cari nama pegawai, NIP, golongan, jabatan, atau unit..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
            />
          </div>

          <select
            value={unitFilter}
            onChange={(e) => setUnitFilter(e.target.value)}
            aria-label="Filter unit kerja"
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-[#14532d]"
          >
            {unitGroups.map((g) => (
              <option key={g.value} value={g.value}>
                {g.label}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => void handleResync()}
            disabled={isSyncing}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            Sinkron SK 01/2026
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-[#14532d]" />
            Import Excel
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={(e) => void handleImportFile(e)}
            className="hidden"
          />

          <button
            type="button"
            onClick={downloadEmployeeImportTemplate}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Template
          </button>

          <button
            type="button"
            onClick={() => {
              exportEmployeesToExcel(filteredEmployees);
              onNotify(
                'success',
                `${filteredEmployees.length} data pegawai berhasil diekspor ke Excel.`
              );
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-[#14532d]" />
            Export Excel
          </button>

          <button
            type="button"
            onClick={openAddModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Tambah Pegawai
          </button>
        </div>
      </div>

      {/* Tabel Data Pegawai */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
          <span>
            Menampilkan{' '}
            <strong className="text-slate-900 tabular-nums">
              {filteredEmployees.length}
            </strong>{' '}
            dari{' '}
            <strong className="text-slate-900 tabular-nums">
              {employees.length}
            </strong>{' '}
            pegawai ASN Balai KSDA Jakarta
          </span>
          <span>Sumber awal: SK Kepala Balai KSDA Jakarta Nomor 01 Tahun 2026</span>
        </div>

        <div className="overflow-x-auto max-h-[560px] overflow-y-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold z-10">
              <tr>
                <th className="py-3 px-4 w-10 text-center">No</th>
                <th className="py-3 px-4 min-w-[200px]">Nama Pegawai</th>
                <th className="py-3 px-4 min-w-[170px]">NIP</th>
                <th className="py-3 px-4 min-w-[150px]">Pangkat / Golongan</th>
                <th className="py-3 px-4 min-w-[200px]">Jabatan</th>
                <th className="py-3 px-4 min-w-[220px]">Unit / Seksi</th>
                <th className="py-3 px-4 text-right w-24">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEmployees.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-500">
                    Tidak ada pegawai yang sesuai dengan pencarian.
                  </td>
                </tr>
              ) : (
                filteredEmployees.map((emp, idx) => (
                  <tr key={emp.id} className="hover:bg-slate-50/70 align-top">
                    <td className="py-2.5 px-4 text-center text-slate-500 tabular-nums">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-4 font-semibold text-slate-900">
                      {emp.nama}
                    </td>
                    <td className="py-2.5 px-4 font-mono tabular-nums text-slate-700">
                      {formatNipSpaced(emp.nip)}
                    </td>
                    <td className="py-2.5 px-4 text-slate-700">
                      {emp.pangkatGolongan}
                    </td>
                    <td className="py-2.5 px-4 text-slate-700">{emp.jabatan}</td>
                    <td className="py-2.5 px-4 text-slate-600">{emp.unit}</td>
                    <td className="py-2.5 px-4">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => openEditModal(emp)}
                          title="Ubah data pegawai"
                          className="p-1.5 rounded-md text-slate-600 hover:text-amber-700 hover:bg-amber-50 transition cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onConfirm({
                              title: 'Hapus Data Pegawai?',
                              description: `Pegawai "${emp.nama}" akan dihapus dari daftar master pegawai Surat Tugas. Riwayat surat lama tetap aman.`,
                              confirmLabel: 'Hapus Pegawai',
                              danger: true,
                              onConfirm: () => onDeleteEmployee(emp.id),
                            })
                          }
                          title="Hapus pegawai"
                          className="p-1.5 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Tambah / Edit Pegawai */}
      {isModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
        >
          <div className="w-full max-w-lg bg-white rounded-xl border border-slate-200 shadow-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                {isEditMode ? 'Ubah Data Pegawai ASN' : 'Tambah Pegawai Baru'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-5 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Lengkap & Gelar <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={form.nama}
                  onChange={(e) => setForm({ ...form, nama: e.target.value })}
                  placeholder="Contoh: Deni Mulyana, S.Hut."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    NIP
                  </label>
                  <input
                    type="text"
                    value={form.nip}
                    onChange={(e) => setForm({ ...form, nip: e.target.value })}
                    placeholder="198307172007101001"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono tabular-nums text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Pangkat / Golongan
                  </label>
                  <input
                    type="text"
                    value={form.pangkatGolongan}
                    onChange={(e) =>
                      setForm({ ...form, pangkatGolongan: e.target.value })
                    }
                    placeholder="Penata (III/c)"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Jabatan
                </label>
                <input
                  type="text"
                  value={form.jabatan}
                  onChange={(e) => setForm({ ...form, jabatan: e.target.value })}
                  placeholder="Polisi Kehutanan Ahli Muda"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Unit / Seksi / Resor
                </label>
                <input
                  type="text"
                  value={form.unit}
                  onChange={(e) => setForm({ ...form, unit: e.target.value })}
                  placeholder="Seksi KSDA Wilayah I (Resor Jakarta Timur)"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold cursor-pointer"
                >
                  {isEditMode ? 'Simpan Perubahan' : 'Simpan Pegawai'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
