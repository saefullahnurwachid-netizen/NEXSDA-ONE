import { Check, Edit3, Plus, RotateCcw, Trash2, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type {
  ConfirmDialogConfig,
  MasterCategoryKey,
  MasterOptionItem,
  MasterOptions,
} from '../types';
import { DEFAULT_MASTER_OPTIONS } from '../utils/storageUtils';

interface MasterOptionsViewProps {
  options: MasterOptions;
  initialCategory?: MasterCategoryKey;
  onSaveOptions: (next: MasterOptions) => void;
  onConfirm: (config: ConfirmDialogConfig) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

type CategoryKey = MasterCategoryKey;

const CATEGORY_META: { key: CategoryKey; title: string; subtitle: string; placeholder: string }[] = [
  {
    key: 'dasarSurat',
    title: 'Dasar Surat',
    subtitle: 'Template peraturan perundang-undangan, SK Kepala Balai, atau nomor DIPA untuk poin Dasar.',
    placeholder: 'Contoh: Undang-Undang Nomor 32 Tahun 2024 tentang Perubahan atas UU Nomor 5 Tahun 1990...',
  },
  {
    key: 'maksudTugas',
    title: 'Maksud / Jenis Kegiatan',
    subtitle: 'Template uraian kegiatan rutin seperti SMART Patrol, Evakuasi Satwa, atau Penyuluhan.',
    placeholder: 'Contoh: Patroli Perlindungan dan Pengawasan Peredaran Tumbuhan dan Satwa Liar (SMART Patrol)',
  },
  {
    key: 'tempatTujuan',
    title: 'Tempat / Lokasi Tujuan',
    subtitle: 'Daftar cepat wilayah kerja 4 resor Seksi KSDA Wilayah I dan lokasi operasional.',
    placeholder: 'Contoh: Wilayah Kerja Resor Jakarta Timur, Kota Administrasi Jakarta Timur',
  },
  {
    key: 'tindakLanjut',
    title: 'Tindak Lanjut (Menimbang)',
    subtitle: 'Template frasa tindak lanjut pada bagian Menimbang surat tugas resmi BKSDA Jakarta.',
    placeholder: 'Contoh: penugasan personil Balai KSDA Jakarta untuk melaksanakan kegiatan dimaksud',
  },
  {
    key: 'kodeKlasifikasi',
    title: 'Kode Klasifikasi',
    subtitle: 'Daftar kode unit/klasifikasi yang muncul pada dropdown penomoran surat (mis. TU, SKW1, SKW2).',
    placeholder: 'Contoh: TU',
  },
  {
    key: 'tembusan',
    title: 'Master Tembusan',
    subtitle: 'Daftar cepat penerima tembusan di bagian kiri bawah Surat Tugas.',
    placeholder: 'Contoh: Kepala Sub Bagian Tata Usaha Balai KSDA Jakarta',
  },
];

export default function MasterOptionsView({
  options,
  initialCategory,
  onSaveOptions,
  onConfirm,
  onNotify,
}: MasterOptionsViewProps) {
  const [activeCategory, setActiveCategory] = useState<CategoryKey>(
    initialCategory || 'dasarSurat'
  );
  const [editingId, setEditingId] = useState<string | null>(null);
  const [label, setLabel] = useState('');
  const [value, setValue] = useState('');

  useEffect(() => {
    if (initialCategory) {
      setActiveCategory(initialCategory);
      setEditingId(null);
      setLabel('');
      setValue('');
    }
  }, [initialCategory]);

  const meta =
    CATEGORY_META.find((c) => c.key === activeCategory) || CATEGORY_META[0];
  const currentList = options[activeCategory] || [];

  const resetForm = () => {
    setEditingId(null);
    setLabel('');
    setValue('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!label.trim() || !value.trim()) {
      onNotify('error', 'Judul singkat dan isi teks template wajib diisi.');
      return;
    }

    const updatedItem: MasterOptionItem = {
      id: editingId || `${activeCategory}-${Date.now()}`,
      label: label.trim(),
      value: value.trim(),
    };

    const nextList = editingId
      ? currentList.map((it) => (it.id === editingId ? updatedItem : it))
      : [...currentList, updatedItem];

    onSaveOptions({
      ...options,
      [activeCategory]: nextList,
    });
    onNotify(
      'success',
      editingId
        ? `Template ${meta.title} berhasil diperbarui.`
        : `Template ${meta.title} baru berhasil ditambahkan.`
    );
    resetForm();
  };

  const handleStartEdit = (item: MasterOptionItem) => {
    setEditingId(item.id);
    setLabel(item.label);
    setValue(item.value);
  };

  const handleDelete = (id: string) => {
    const nextList = currentList.filter((it) => it.id !== id);
    onSaveOptions({
      ...options,
      [activeCategory]: nextList,
    });
    if (editingId === id) resetForm();
    onNotify('success', `Template ${meta.title} berhasil dihapus.`);
  };

  const handleResetCategory = () => {
    onConfirm({
      title: `Kembalikan Standar ${meta.title}?`,
      description: `Daftar ${meta.title} akan dikembalikan ke template standar Balai KSDA Jakarta.`,
      confirmLabel: 'Kembalikan Standar',
      onConfirm: () => {
        onSaveOptions({
          ...options,
          [activeCategory]: DEFAULT_MASTER_OPTIONS[activeCategory],
        });
        resetForm();
        onNotify('info', `Daftar ${meta.title} dikembalikan ke template standar.`);
      },
    });
  };

  return (
    <div className="space-y-5">
      {/* Selector Kategori */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200">
          {CATEGORY_META.map((cat) => (
            <button
              key={cat.key}
              type="button"
              onClick={() => {
                setActiveCategory(cat.key);
                resetForm();
              }}
              className={`px-3.5 py-1.5 rounded-md text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer ${
                activeCategory === cat.key
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat.title} ({(options[cat.key] || []).length})
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={handleResetCategory}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset Kategori Ini
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Form Tambah / Ubah Template */}
        <form
          onSubmit={handleSubmit}
          className="xl:col-span-5 bg-white border border-slate-200 rounded-xl p-5 space-y-3.5"
        >
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                {editingId ? `Ubah Template ${meta.title}` : `Tambah ${meta.title}`}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">{meta.subtitle}</p>
            </div>
            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Label Singkat (Tampil di Pilihan Cepat){' '}
              <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              required
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="Contoh: SMART Patrol Pengawasan TSL"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Isi Teks Lengkap <span className="text-red-600">*</span>
            </label>
            <textarea
              rows={4}
              required
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder={meta.placeholder}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:bg-white focus:border-[#14532d]"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
            )}
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#14532d] hover:bg-[#166534] text-white text-xs font-semibold cursor-pointer"
            >
              {editingId ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  Simpan Perubahan
                </>
              ) : (
                <>
                  <Plus className="w-3.5 h-3.5" />
                  Tambah Template
                </>
              )}
            </button>
          </div>
        </form>

        {/* Daftar Template Tersimpan */}
        <div className="xl:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900">
              Daftar Template {meta.title} ({currentList.length})
            </h3>
          </div>

          {currentList.length === 0 ? (
            <div className="py-10 px-6 text-center text-xs text-slate-500">
              Belum ada template tersimpan pada kategori ini.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {currentList.map((item, idx) => (
                <div
                  key={item.id}
                  className="px-5 py-3.5 flex items-start justify-between gap-3 hover:bg-slate-50/60"
                >
                  <div className="min-w-0 space-y-1">
                    <div className="text-xs font-semibold text-slate-900">
                      <span className="font-mono tabular-nums text-slate-400 mr-1.5">
                        {idx + 1}.
                      </span>
                      {item.label}
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {item.value}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleStartEdit(item)}
                      title="Ubah template"
                      className="p-1.5 rounded-md text-slate-600 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onConfirm({
                          title: `Hapus Template ${meta.title}?`,
                          description: `Template "${item.label}" akan dihapus dari daftar pilihan cepat.`,
                          confirmLabel: 'Hapus',
                          danger: true,
                          onConfirm: () => handleDelete(item.id),
                        })
                      }
                      title="Hapus template"
                      className="p-1.5 rounded-md text-slate-500 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
