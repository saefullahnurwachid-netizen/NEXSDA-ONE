import type {
  DipaAccount,
  Employee,
  LogoSettings,
  MasterOptions,
  Signatory,
  SuratTugasRecord,
} from '../types';

export const STORAGE_KEYS = {
  LETTERS: 'nexsda_surat_tugas_letters',
  EMPLOYEES: 'nexsda_surat_tugas_employees',
  SIGNATORIES: 'nexsda_surat_tugas_signatories',
  DIPA: 'nexsda_surat_tugas_dipa',
  LOGO: 'nexsda_surat_tugas_logo',
  MASTER_OPTIONS: 'nexsda_surat_tugas_master_options',
  SK01_SYNCED_FLAG: 'nexsda_surat_tugas_sk01_synced_v1',
} as const;

interface RawSk01AsnRecord {
  nama?: string;
  nip?: string;
  gol?: string;
  jabatan?: string;
  unit?: string;
}

declare global {
  interface Window {
    DEFAULT_SK01_2026_ASN?: RawSk01AsnRecord[];
  }
}

export const DEFAULT_LOGO_SETTINGS: LogoSettings = {
  ministryLine1: 'KEMENTERIAN KEHUTANAN',
  directorateLine2: 'DIREKTORAT JENDERAL KONSERVASI SUMBER DAYA ALAM DAN EKOSISTEM',
  agencyLine3: 'BALAI KONSERVASI SUMBER DAYA ALAM JAKARTA',
  addressLine1: '',
  addressLine2: '',
  logoBase64: '',
  stampSignatureBase64: '',
  showStampSignature: false,
  paperSize: 'A4',
};

export const DEFAULT_SIGNATORIES: Signatory[] = [
  {
    id: 'sig-kepala-balai',
    nama: 'Kepala Balai KSDA Jakarta',
    nip: '-',
    pangkatGolongan: 'Pembina Tk. I (IV/b)',
    jabatan: 'Kepala Balai Konservasi Sumber Daya Alam Jakarta',
    jabatanHeader: 'Kepala Balai,',
    isDefault: true,
  },
  {
    id: 'sig-plh-kepala-balai',
    nama: 'Plh. Kepala Balai KSDA Jakarta',
    nip: '-',
    pangkatGolongan: 'Pembina (IV/a)',
    jabatan: 'Plh. Kepala Balai Konservasi Sumber Daya Alam Jakarta',
    jabatanHeader: 'Plh. Kepala Balai,',
    isDefault: false,
  },
  {
    id: 'sig-kepala-seksi-1',
    nama: 'Kepala Seksi KSDA Wilayah I',
    nip: '-',
    pangkatGolongan: 'Penata Tk. I (III/d)',
    jabatan: 'Kepala Seksi Konservasi Sumber Daya Alam Wilayah I',
    jabatanHeader: 'a.n. Kepala Balai\nKepala Seksi KSDA Wilayah I,',
    isDefault: false,
  },
  {
    id: 'sig-kasubbag-tu',
    nama: 'Kepala Sub Bagian Tata Usaha',
    nip: '-',
    pangkatGolongan: 'Penata Tk. I (III/d)',
    jabatan: 'Kepala Sub Bagian Tata Usaha Balai KSDA Jakarta',
    jabatanHeader: 'a.n. Kepala Balai\nKepala Sub Bagian Tata Usaha,',
    isDefault: false,
  },
];

export const DEFAULT_DIPA_ACCOUNTS: DipaAccount[] = [
  {
    id: 'dipa-524111-skw1',
    kodeAkun: '524111',
    uraian: 'Belanja Perjalanan Dinas Biasa — Seksi KSDA Wilayah I',
    nomorDipa: 'DIPA Nomor SP DIPA-029.05.2.426945/2026',
    tahunAnggaran: '2026',
    tanggalDipa: '2 Desember 2025',
    isDefault: true,
  },
  {
    id: 'dipa-524113-skw1',
    kodeAkun: '524113',
    uraian: 'Belanja Perjalanan Dinas Dalam Kota — Pengawasan & Evakuasi TSL',
    nomorDipa: 'DIPA Nomor SP DIPA-029.05.2.426945/2026',
    tahunAnggaran: '2026',
    tanggalDipa: '2 Desember 2025',
    isDefault: false,
  },
  {
    id: 'dipa-524114-patrol',
    kodeAkun: '524114',
    uraian: 'Belanja Perjalanan Dinas Paket Meeting Dalam Kota / Koordinasi',
    nomorDipa: 'DIPA Nomor SP DIPA-029.05.2.426945/2026',
    tahunAnggaran: '2026',
    tanggalDipa: '2 Desember 2025',
    isDefault: false,
  },
];

export const DEFAULT_MASTER_OPTIONS: MasterOptions = {
  dasarSurat: [
    {
      id: 'dasar-1',
      label: 'UU No. 32 Tahun 2024 (KSDAE)',
      value:
        'Undang-Undang Nomor 32 Tahun 2024 tentang Perubahan atas Undang-Undang Nomor 5 Tahun 1990 tentang Konservasi Sumber Daya Alam Hayati dan Ekosistemnya',
    },
    {
      id: 'dasar-2',
      label: 'PP No. 8 Tahun 1999 (Pemanfaatan TSL)',
      value:
        'Peraturan Pemerintah Nomor 8 Tahun 1999 tentang Pemanfaatan Jenis Tumbuhan dan Satwa Liar',
    },
    {
      id: 'dasar-3',
      label: 'SK Kepala Balai No. 01 Tahun 2026',
      value:
        'Keputusan Kepala Balai Konservasi Sumber Daya Alam Jakarta Nomor 01 Tahun 2026 tanggal 5 Januari 2026 tentang Penataan dan Penempatan Pegawai Aparatur Sipil Negara Lingkup Balai KSDA Jakarta',
    },
    {
      id: 'dasar-4',
      label: 'DIPA Balai KSDA Jakarta TA 2026',
      value:
        'Daftar Isian Pelaksanaan Anggaran (DIPA) Balai Konservasi Sumber Daya Alam Jakarta Tahun Anggaran 2026 Nomor SP DIPA-029.05.2.427051/2026',
    },
  ],
  maksudTugas: [
    {
      id: 'maksud-1',
      label: 'SMART Patrol Pengawasan Peredaran TSL',
      value:
        'Patroli Perlindungan dan Pengawasan Peredaran Tumbuhan dan Satwa Liar (SMART Patrol)',
    },
    {
      id: 'maksud-2',
      label: 'Evakuasi & Penanganan Konflik Satwa Liar',
      value:
        'Evakuasi, penyelamatan, dan penanganan konflik satwa liar perkotaan serta serah terima satwa',
    },
    {
      id: 'maksud-3',
      label: 'Pemeriksaan Stok & Pengawasan Pengedar/LK',
      value:
        'Verifikasi lapangan, pemeriksaan buku stok (stock opname), dan pembinaan teknis pada Lembaga Konservasi dan pengedar TSL',
    },
    {
      id: 'maksud-4',
      label: 'Penyuluhan & Sosialisasi Konservasi KSDAE',
      value:
        'Penyuluhan kehutanan dan sosialisasi peraturan perlindungan tumbuhan dan satwa liar kepada masyarakat',
    },
    {
      id: 'maksud-5',
      label: 'Koordinasi Lintas Instansi & Monitoring Lapangan',
      value:
        'Koordinasi lintas instansi serta monitoring dan evaluasi kegiatan konservasi sumber daya alam hayati dan ekosistemnya',
    },
  ],
  tempatTujuan: [
    {
      id: 'lokasi-1',
      label: 'Wilayah Kerja Resor Jakarta Pusat',
      value: 'Wilayah Kerja Resor Jakarta Pusat, Kota Administrasi Jakarta Pusat',
    },
    {
      id: 'lokasi-2',
      label: 'Wilayah Kerja Resor Jakarta Selatan',
      value: 'Wilayah Kerja Resor Jakarta Selatan, Kota Administrasi Jakarta Selatan',
    },
    {
      id: 'lokasi-3',
      label: 'Wilayah Kerja Resor Jakarta Timur',
      value: 'Wilayah Kerja Resor Jakarta Timur, Kota Administrasi Jakarta Timur',
    },
    {
      id: 'lokasi-4',
      label: 'Wilayah Kerja Resor Bekasi (Kota & Kab. Bekasi)',
      value: 'Wilayah Kerja Resor Bekasi (Kota Bekasi dan Kabupaten Bekasi)',
    },
    {
      id: 'lokasi-5',
      label: 'Seluruh Wilayah Seksi KSDA Wilayah I',
      value:
        'Wilayah Kerja Seksi KSDA Wilayah I (Jakarta Pusat, Jakarta Selatan, Jakarta Timur, dan Bekasi)',
    },
    {
      id: 'lokasi-6',
      label: 'Pusat Penyelamatan Satwa (PPS) Tegal Alur',
      value: 'Pusat Penyelamatan Satwa (PPS) Tegal Alur, Jakarta Barat',
    },
  ],
  tindakLanjut: [
    {
      id: 'tl-1',
      label: 'Penugasan Personil Pelaksanaan Kegiatan',
      value:
        'penugasan personil Balai KSDA Jakarta untuk melaksanakan kegiatan dimaksud',
    },
    {
      id: 'tl-2',
      label: 'Pengawasan & Patroli Perlindungan TSL',
      value:
        'patroli pengawasan peredaran tumbuhan dan satwa liar serta pengumpulan bahan keterangan di lapangan',
    },
    {
      id: 'tl-3',
      label: 'Evakuasi & Penyelamatan Satwa Liar',
      value:
        'tindakan cepat evakuasi dan penyelamatan satwa liar guna menjamin keselamatan masyarakat dan satwa',
    },
    {
      id: 'tl-4',
      label: 'Verifikasi & Pemeriksaan Administrasi/Lapangan',
      value:
        'verifikasi lapangan dan pemeriksaan kepatuhan administrasi penatausahaan TSL',
    },
  ],
  kodeKlasifikasi: [
    { id: 'kk-tu', label: 'TU — Sub Bagian Tata Usaha', value: 'TU' },
    { id: 'kk-skw1', label: 'SKW1 — Seksi KSDA Wilayah I', value: 'SKW1' },
    { id: 'kk-skw2', label: 'SKW2 — Seksi KSDA Wilayah II', value: 'SKW2' },
    { id: 'kk-skw3', label: 'SKW3 — Seksi KSDA Wilayah III', value: 'SKW3' },
  ],
  tembusan: [
    {
      id: 'temb-1',
      label: 'Kasubbag Tata Usaha Balai KSDA Jakarta',
      value: 'Kepala Sub Bagian Tata Usaha Balai KSDA Jakarta',
    },
    {
      id: 'temb-2',
      label: 'Kepala Seksi KSDA Wilayah I',
      value: 'Kepala Seksi KSDA Wilayah I Balai KSDA Jakarta',
    },
    {
      id: 'temb-3',
      label: 'Kepala Seksi KSDA Wilayah II',
      value: 'Kepala Seksi KSDA Wilayah II Balai KSDA Jakarta',
    },
    {
      id: 'temb-4',
      label: 'Kepala Seksi KSDA Wilayah III',
      value: 'Kepala Seksi KSDA Wilayah III Balai KSDA Jakarta',
    },
    {
      id: 'temb-5',
      label: 'Arsip',
      value: 'Arsip',
    },
  ],
};

function readJsonStorage<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJsonStorage<T>(key: string, data: T): void {
  try {
    window.localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.error(`Gagal menyimpan data ke localStorage (${key}):`, err);
  }
}

export function loadStoredLetters(): SuratTugasRecord[] {
  return readJsonStorage<SuratTugasRecord[]>(STORAGE_KEYS.LETTERS, []);
}

export function saveStoredLetters(letters: SuratTugasRecord[]): void {
  writeJsonStorage(STORAGE_KEYS.LETTERS, letters);
}

export function loadStoredEmployees(): Employee[] {
  return readJsonStorage<Employee[]>(STORAGE_KEYS.EMPLOYEES, []);
}

export function saveStoredEmployees(employees: Employee[]): void {
  writeJsonStorage(STORAGE_KEYS.EMPLOYEES, employees);
}

export function loadStoredSignatories(): Signatory[] {
  const list = readJsonStorage<Signatory[]>(STORAGE_KEYS.SIGNATORIES, []);
  return list.length > 0 ? list : DEFAULT_SIGNATORIES;
}

export function saveStoredSignatories(signatories: Signatory[]): void {
  writeJsonStorage(STORAGE_KEYS.SIGNATORIES, signatories);
}

export function loadStoredDipaAccounts(): DipaAccount[] {
  const list = readJsonStorage<DipaAccount[]>(STORAGE_KEYS.DIPA, []);
  return list.length > 0 ? list : DEFAULT_DIPA_ACCOUNTS;
}

export function saveStoredDipaAccounts(accounts: DipaAccount[]): void {
  writeJsonStorage(STORAGE_KEYS.DIPA, accounts);
}

export function loadStoredLogoSettings(): LogoSettings {
  const saved = readJsonStorage<Partial<LogoSettings>>(STORAGE_KEYS.LOGO, {});
  return { ...DEFAULT_LOGO_SETTINGS, ...saved };
}

export function saveStoredLogoSettings(settings: LogoSettings): void {
  writeJsonStorage(STORAGE_KEYS.LOGO, settings);
}

export function loadStoredMasterOptions(): MasterOptions {
  const saved = readJsonStorage<Partial<MasterOptions>>(
    STORAGE_KEYS.MASTER_OPTIONS,
    {}
  );
  return {
    dasarSurat:
      Array.isArray(saved.dasarSurat) && saved.dasarSurat.length > 0
        ? saved.dasarSurat
        : DEFAULT_MASTER_OPTIONS.dasarSurat,
    maksudTugas:
      Array.isArray(saved.maksudTugas) && saved.maksudTugas.length > 0
        ? saved.maksudTugas
        : DEFAULT_MASTER_OPTIONS.maksudTugas,
    tempatTujuan:
      Array.isArray(saved.tempatTujuan) && saved.tempatTujuan.length > 0
        ? saved.tempatTujuan
        : DEFAULT_MASTER_OPTIONS.tempatTujuan,
    tindakLanjut:
      Array.isArray(saved.tindakLanjut) && saved.tindakLanjut.length > 0
        ? saved.tindakLanjut
        : DEFAULT_MASTER_OPTIONS.tindakLanjut,
    kodeKlasifikasi:
      Array.isArray(saved.kodeKlasifikasi) && saved.kodeKlasifikasi.length > 0
        ? saved.kodeKlasifikasi
        : DEFAULT_MASTER_OPTIONS.kodeKlasifikasi,
    tembusan:
      Array.isArray(saved.tembusan) && saved.tembusan.length > 0
        ? saved.tembusan
        : DEFAULT_MASTER_OPTIONS.tembusan,
  };
}

export function saveStoredMasterOptions(options: MasterOptions): void {
  writeJsonStorage(STORAGE_KEYS.MASTER_OPTIONS, options);
}

function mapRawSk01ToEmployees(raw: RawSk01AsnRecord[]): Employee[] {
  return raw
    .filter((item) => item && typeof item.nama === 'string' && item.nama.trim().length > 0)
    .map((item, idx) => {
      const cleanNip = String(item.nip || '').replace(/\s+/g, '');
      return {
        id: cleanNip ? `asn-${idx + 1}-${cleanNip}` : `asn-sk01-${idx + 1}`,
        nama: String(item.nama || '').trim(),
        nip: cleanNip || '-',
        pangkatGolongan: String(item.gol || '-').trim(),
        jabatan: String(item.jabatan || '-').trim(),
        unit: String(item.unit || 'Balai KSDA Jakarta').trim(),
        source: 'sk01_2026' as const,
      };
    });
}

let sk01LoadPromise: Promise<Employee[]> | null = null;

export function loadSk01AsnData(): Promise<Employee[]> {
  if (typeof window === 'undefined') return Promise.resolve([]);
  if (Array.isArray(window.DEFAULT_SK01_2026_ASN) && window.DEFAULT_SK01_2026_ASN.length > 0) {
    return Promise.resolve(mapRawSk01ToEmployees(window.DEFAULT_SK01_2026_ASN));
  }
  if (sk01LoadPromise) return sk01LoadPromise;

  sk01LoadPromise = new Promise<Employee[]>((resolve) => {
    const existingScript = document.querySelector<HTMLScriptElement>(
      'script[data-nexsda-sk01="true"]'
    );
    if (existingScript) {
      existingScript.addEventListener('load', () => {
        resolve(mapRawSk01ToEmployees(window.DEFAULT_SK01_2026_ASN || []));
      });
      existingScript.addEventListener('error', () => resolve([]));
      return;
    }

    const script = document.createElement('script');
    script.src = '/assets/data/sk01_2026_asn.js';
    script.async = true;
    script.dataset.nexsdaSk01 = 'true';
    script.onload = () => {
      resolve(mapRawSk01ToEmployees(window.DEFAULT_SK01_2026_ASN || []));
    };
    script.onerror = () => {
      console.warn('Tidak dapat memuat /assets/data/sk01_2026_asn.js');
      resolve([]);
    };
    document.head.appendChild(script);
  });

  return sk01LoadPromise;
}

export function mergeEmployeesWithSk01(
  existing: Employee[],
  sk01List: Employee[]
): { merged: Employee[]; addedCount: number } {
  const existingKeys = new Set(
    existing.map((e) => {
      const normName = e.nama.trim().toLowerCase();
      const normNip = e.nip.replace(/\s+/g, '');
      return `${normName}|${normNip}`;
    })
  );
  const existingNames = new Set(existing.map((e) => e.nama.trim().toLowerCase()));

  const additions: Employee[] = [];
  for (const emp of sk01List) {
    const normNip = emp.nip.replace(/\s+/g, '');
    const normName = emp.nama.trim().toLowerCase();
    const pairKey = `${normName}|${normNip}`;
    const alreadyExists = existingKeys.has(pairKey) || existingNames.has(normName);
    if (!alreadyExists) {
      additions.push(emp);
      existingKeys.add(pairKey);
      existingNames.add(normName);
    }
  }

  return {
    merged: [...existing, ...additions],
    addedCount: additions.length,
  };
}

export interface SuratTugasBackupPayload {
  app: 'NEXSDA-ONE-SURAT-TUGAS';
  version: 1;
  exportedAt: string;
  data: {
    letters: SuratTugasRecord[];
    employees: Employee[];
    signatories: Signatory[];
    dipaAccounts: DipaAccount[];
    logoSettings: LogoSettings;
    masterOptions: MasterOptions;
  };
}

export function buildBackupPayload(
  data: SuratTugasBackupPayload['data']
): SuratTugasBackupPayload {
  return {
    app: 'NEXSDA-ONE-SURAT-TUGAS',
    version: 1,
    exportedAt: new Date().toISOString(),
    data,
  };
}

export function parseBackupPayload(rawJson: string): SuratTugasBackupPayload['data'] {
  const parsed = JSON.parse(rawJson) as Partial<SuratTugasBackupPayload>;
  if (!parsed || parsed.app !== 'NEXSDA-ONE-SURAT-TUGAS' || !parsed.data) {
    throw new Error(
      'Format berkas cadangan tidak valid. Pastikan berkas berasal dari fitur Backup JSON Sistem Surat Tugas NEXSDA-ONE.'
    );
  }
  const d = parsed.data;
  return {
    letters: Array.isArray(d.letters) ? d.letters : [],
    employees: Array.isArray(d.employees) ? d.employees : [],
    signatories:
      Array.isArray(d.signatories) && d.signatories.length > 0
        ? d.signatories
        : DEFAULT_SIGNATORIES,
    dipaAccounts:
      Array.isArray(d.dipaAccounts) && d.dipaAccounts.length > 0
        ? d.dipaAccounts
        : DEFAULT_DIPA_ACCOUNTS,
    logoSettings: { ...DEFAULT_LOGO_SETTINGS, ...(d.logoSettings || {}) },
    masterOptions: {
      dasarSurat:
        Array.isArray(d.masterOptions?.dasarSurat) && d.masterOptions.dasarSurat.length > 0
          ? d.masterOptions.dasarSurat
          : DEFAULT_MASTER_OPTIONS.dasarSurat,
      maksudTugas:
        Array.isArray(d.masterOptions?.maksudTugas) && d.masterOptions.maksudTugas.length > 0
          ? d.masterOptions.maksudTugas
          : DEFAULT_MASTER_OPTIONS.maksudTugas,
      tempatTujuan:
        Array.isArray(d.masterOptions?.tempatTujuan) && d.masterOptions.tempatTujuan.length > 0
          ? d.masterOptions.tempatTujuan
          : DEFAULT_MASTER_OPTIONS.tempatTujuan,
      tindakLanjut:
        Array.isArray(d.masterOptions?.tindakLanjut) && d.masterOptions.tindakLanjut.length > 0
          ? d.masterOptions.tindakLanjut
          : DEFAULT_MASTER_OPTIONS.tindakLanjut,
      kodeKlasifikasi:
        Array.isArray(d.masterOptions?.kodeKlasifikasi) && d.masterOptions.kodeKlasifikasi.length > 0
          ? d.masterOptions.kodeKlasifikasi
          : DEFAULT_MASTER_OPTIONS.kodeKlasifikasi,
      tembusan:
        Array.isArray(d.masterOptions?.tembusan) && d.masterOptions.tembusan.length > 0
          ? d.masterOptions.tembusan
          : DEFAULT_MASTER_OPTIONS.tembusan,
    },
  };
}
