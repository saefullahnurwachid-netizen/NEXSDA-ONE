import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import type { Employee, SuratTugasRecord } from '../types';
import { formatNipSpaced, formatTanggalIndonesia } from './dateUtils';

export function exportLettersToExcel(letters: SuratTugasRecord[]): void {
  const rows = letters.map((rec, idx) => ({
    No: idx + 1,
    'Nomor Surat': rec.nomorSurat,
    'Tanggal Surat': formatTanggalIndonesia(rec.tanggalSurat),
    'Pegawai Pelaksana': rec.pegawaiSnapshot
      .map((p) => `${p.nama} (${formatNipSpaced(p.nip)})`)
      .join('; '),
    'Jumlah Personil': rec.pegawaiSnapshot.length,
    'Maksud / Tujuan Tugas': rec.maksudTugas,
    'Lokasi / Wilayah Tugas': rec.lokasiTugas,
    'Tanggal Mulai': formatTanggalIndonesia(rec.tanggalMulai),
    'Tanggal Selesai': formatTanggalIndonesia(rec.tanggalSelesai),
    'Lama (Hari)': rec.lamaHari,
    'Pejabat Penandatangan': rec.penandatanganSnapshot?.nama || '-',
    'Pembebanan Anggaran DIPA':
      rec.pakaiDipa && rec.dipaSnapshot
        ? `${rec.dipaSnapshot.kodeAkun} - ${rec.dipaSnapshot.uraian} (${rec.dipaSnapshot.nomorDipa})`
        : 'Non-DIPA / Tidak Dibebankan',
  }));

  const ws = XLSX.utils.json_to_sheet(rows);
  ws['!cols'] = [
    { wch: 5 },
    { wch: 30 },
    { wch: 18 },
    { wch: 42 },
    { wch: 14 },
    { wch: 45 },
    { wch: 32 },
    { wch: 18 },
    { wch: 18 },
    { wch: 12 },
    { wch: 28 },
    { wch: 38 },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Rekap Surat Tugas');

  const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([out], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const stamp = new Date().toISOString().slice(0, 10);
  saveAs(blob, `Rekap_Surat_Tugas_BKSDA_Jakarta_${stamp}.xlsx`);
}

export function exportEmployeesToExcel(employees: Employee[]): void {
  const rows = employees.map((emp, idx) => ({
    No: idx + 1,
    Nama: emp.nama,
    NIP: emp.nip,
    'Pangkat/Golongan': emp.pangkatGolongan,
    Jabatan: emp.jabatan,
    'Unit/Seksi': emp.unit,
  }));

  const ws = XLSX.utils.json_to_sheet(rows);
  ws['!cols'] = [
    { wch: 5 },
    { wch: 32 },
    { wch: 22 },
    { wch: 24 },
    { wch: 34 },
    { wch: 48 },
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Data Pegawai ASN');

  const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([out], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const stamp = new Date().toISOString().slice(0, 10);
  saveAs(blob, `Data_Pegawai_ASN_BKSDA_Jakarta_${stamp}.xlsx`);
}

export function downloadEmployeeImportTemplate(): void {
  const sample = [
    {
      Nama: 'Contoh Nama Pegawai, S.Hut',
      NIP: '199001012015031001',
      'Pangkat/Golongan': 'Penata (III/c)',
      Jabatan: 'Polisi Kehutanan Ahli Muda',
      'Unit/Seksi': 'Seksi KSDA Wilayah I (Resor Jakarta Pusat)',
    },
  ];
  const ws = XLSX.utils.json_to_sheet(sample);
  ws['!cols'] = [
    { wch: 30 },
    { wch: 22 },
    { wch: 22 },
    { wch: 30 },
    { wch: 42 },
  ];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Template Pegawai');
  const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([out], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  saveAs(blob, 'Template_Import_Pegawai_Surat_Tugas.xlsx');
}

export async function parseEmployeesFromExcel(file: File): Promise<Employee[]> {
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: 'array' });
  const sheetName = wb.SheetNames[0];
  if (!sheetName) return [];
  const ws = wb.Sheets[sheetName];
  const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, {
    defval: '',
  });

  const findField = (row: Record<string, unknown>, candidates: string[]): string => {
    const entries = Object.entries(row);
    for (const c of candidates) {
      const target = c.toLowerCase();
      const hit = entries.find(([k]) => k.trim().toLowerCase() === target);
      if (hit && String(hit[1]).trim()) return String(hit[1]).trim();
    }
    for (const c of candidates) {
      const target = c.toLowerCase();
      const hit = entries.find(([k]) => k.trim().toLowerCase().includes(target));
      if (hit && String(hit[1]).trim()) return String(hit[1]).trim();
    }
    return '';
  };

  const results: Employee[] = [];
  rawRows.forEach((row, idx) => {
    const nama = findField(row, ['nama', 'nama pegawai', 'nama lengkap']);
    if (!nama) return;
    const nip = findField(row, ['nip', 'nomor induk pegawai']).replace(/\s+/g, '') || '-';
    const pangkatGolongan =
      findField(row, ['pangkat/golongan', 'pangkat', 'golongan', 'gol']) || '-';
    const jabatan = findField(row, ['jabatan', 'posisi']) || '-';
    const unit =
      findField(row, ['unit/seksi', 'unit kerja', 'unit', 'seksi', 'resor']) ||
      'Balai KSDA Jakarta';

    results.push({
      id: `imp-${Date.now()}-${idx}`,
      nama,
      nip,
      pangkatGolongan,
      jabatan,
      unit,
      source: 'manual',
    });
  });

  return results;
}
