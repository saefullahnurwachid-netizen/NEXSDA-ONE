import {
  AlignmentType,
  BorderStyle,
  Document,
  ImageRun,
  OverlapType,
  Packer,
  Paragraph,
  RelativeHorizontalPosition,
  RelativeVerticalPosition,
  Table,
  TableAnchorType,
  TableCell,
  TableLayoutType,
  TableRow,
  TextRun,
  VerticalAlign,
  WidthType,
  convertMillimetersToTwip,
} from 'docx';
import { saveAs } from 'file-saver';
import type { LogoSettings, SuratTugasRecord } from '../types';
import {
  composeMenimbangText,
  formatHariKegiatanIndonesia,
  formatNipSpaced,
  formatRentangTanggalIndonesia,
  formatTanggalIndonesia,
} from './dateUtils';

const KOP_FONT = 'Figtree';
const FONT_FAMILY = 'Bookman Old Style';
const LINE_SINGLE = 240; // 1.0x
const LINE_BODY = 276; // 1.15x

const mm = (val: number) => convertMillimetersToTwip(val);
const inch = (val: number) => Math.round(val * 1440);
const pt = (val: number) => Math.round(val * 20);
const halfPt = (val: number) => Math.round(val * 2);

// Lebar Area Cetak Efektif A4 = 21,0 cm - 0,5" (1,27 cm kiri) - 0,5" (1,27 cm kanan) = 18,46 cm (184,6 mm)
const W_TOTAL = mm(184.6);
const W_KOP_LOGO = mm(20); // 2,0 cm
const W_KOP_TEXT = W_TOTAL - W_KOP_LOGO; // 16,46 cm (2,0 + 16,46 = 18,46 cm)

const W_LABEL = mm(25); // 2,5 cm
const W_COLON = mm(4); // 0,4 cm
const W_CONTENT = W_TOTAL - W_LABEL - W_COLON; // 15,56 cm (2,5 + 0,4 + 15,56 = 18,46 cm)
const W_NUM = mm(6); // 0,6 cm
const W_URAIAN = W_TOTAL - W_LABEL - W_COLON - W_NUM; // 14,96 cm (2,5 + 0,4 + 0,6 + 14,96 = 18,46 cm)
const W_ATTR = mm(32); // 3,2 cm
const W_ATTR_VAL = W_TOTAL - W_LABEL - W_COLON - W_NUM - W_ATTR - W_COLON; // 11,36 cm

const W_SIG_RIGHT = mm(64); // 6,4 cm
const W_SIG_LEFT = W_TOTAL - W_SIG_RIGHT; // 12,06 cm (12,06 + 6,4 = 18,46 cm)

const ZERO_CELL_MARGINS = { top: 0, bottom: 0, left: 0, right: 0 };

function decodeBase64DataUrl(
  dataUrl: string
): { bytes: Uint8Array; type: 'png' | 'jpg' } | null {
  if (!dataUrl || typeof dataUrl !== 'string') return null;
  const match = /^data:image\/(png|jpeg|jpg);base64,(.+)$/i.exec(dataUrl.trim());
  if (!match) return null;
  try {
    const ext = match[1].toLowerCase() === 'png' ? 'png' : 'jpg';
    if (typeof window !== 'undefined' && typeof window.atob === 'function') {
      const binary = window.atob(match[2]);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      return { bytes, type: ext };
    }
    const buf = Buffer.from(match[2], 'base64');
    return { bytes: new Uint8Array(buf), type: ext };
  } catch {
    return null;
  }
}

const NO_BORDERS = {
  top: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  bottom: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  left: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  right: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  insideHorizontal: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
  insideVertical: { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' },
};

const THIN_CELL_BORDERS = {
  top: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
  bottom: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
  left: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
  right: { style: BorderStyle.SINGLE, size: 4, color: '000000' },
};

export function isRecordLampiranMode(record: SuratTugasRecord): boolean {
  if (record.pegawaiSnapshot.length <= 3) return false;
  return record.formatKepada !== 'langsung';
}

export function getBodyFontPt(record: SuratTugasRecord): number {
  // 11 pt standar; otomatis 10,5 pt jika >3 pegawai dicetak langsung dalam 1 halaman A4
  if (record.pegawaiSnapshot.length > 3 && !isRecordLampiranMode(record)) {
    return 10.5;
  }
  return 11;
}

export function getPrintableNomorSurat(
  record: SuratTugasRecord,
  useNonBreakingBlank = false
): string {
  const raw = record.nomorSurat || '';
  if (!useNonBreakingBlank) return raw;
  return raw.replace(
    /ST\.\s+\//,
    'ST.\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0/'
  );
}

export function formatDasarItems(dasarList: string[]): string[] {
  const cleaned = dasarList
    .map((d) => d.trim().replace(/[;.]+$/, ''))
    .filter(Boolean);
  if (cleaned.length === 0) return ['-'];
  return cleaned.map((item, idx) =>
    idx < cleaned.length - 1 ? `${item};` : `${item}.`
  );
}

export function buildUntukPoints(record: SuratTugasRecord): string[] {
  const cleanMaksud = (record.maksudTugas || '').trim().replace(/\.+$/, '');
  const cleanLokasi = (record.lokasiTugas || '').trim().replace(/\.+$/, '');
  const point1 = /^melaksanakan perjalanan dinas/i.test(cleanMaksud)
    ? `${cleanMaksud} di ${cleanLokasi}`
    : `Melaksanakan perjalanan dinas dalam rangka ${cleanMaksud} di ${cleanLokasi}`;

  const hari =
    (record.hariKegiatanText || '').trim() ||
    formatHariKegiatanIndonesia(record.tanggalMulai, record.tanggalSelesai);
  const rentang =
    (record.tanggalKegiatanText || '').trim() ||
    formatRentangTanggalIndonesia(record.tanggalMulai, record.tanggalSelesai);
  const point2 = `Pelaksanaan kegiatan pada hari ${hari} tanggal ${rentang}`;

  const points: string[] = [point1, point2];

  if (record.pakaiDipa && record.dipaSnapshot) {
    const nomorDipa =
      record.dipaSnapshot.nomorDipa ||
      'DIPA Nomor SP DIPA-029.05.2.426945/2026';
    const tahunDipa = record.dipaSnapshot.tahunAnggaran || '2026';
    const tanggalDipa = record.dipaSnapshot.tanggalDipa || '2 Desember 2025';
    points.push(
      `Kegiatan dibebankan pada Anggaran ${nomorDipa} Balai KSDA Jakarta Tahun ${tahunDipa} tanggal ${tanggalDipa}`
    );
  }

  if (record.catatanTambahan && record.catatanTambahan.trim()) {
    points.push(record.catatanTambahan.trim());
  }

  points.push(
    'Melaporkan hasilnya secara obyektif kepada Kepala Balai KSDA Jakarta paling lambat 1 (satu) minggu setelah pelaksanaan kegiatan.'
  );

  return points;
}

function createCell(
  widthDxa: number,
  children: Paragraph[],
  verticalAlign:
    | typeof VerticalAlign.TOP
    | typeof VerticalAlign.CENTER
    | typeof VerticalAlign.BOTTOM = VerticalAlign.TOP
): TableCell {
  return new TableCell({
    width: { size: widthDxa, type: WidthType.DXA },
    verticalAlign,
    borders: NO_BORDERS,
    margins: ZERO_CELL_MARGINS,
    children,
  });
}

function createLetterhead(logoSettings: LogoSettings): (Paragraph | Table)[] {
  const decodedLogo = decodeBase64DataUrl(logoSettings.logoBase64);

  const headerTextParagraphs: Paragraph[] = [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: pt(1), line: LINE_BODY },
      children: [
        new TextRun({
          text: (logoSettings.ministryLine1 || 'KEMENTERIAN KEHUTANAN').toUpperCase(),
          font: KOP_FONT,
          size: halfPt(14), // 14 pt Bold
          bold: true,
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: pt(1), line: LINE_BODY },
      children: [
        new TextRun({
          text: (
            logoSettings.directorateLine2 ||
            'DIREKTORAT JENDERAL KONSERVASI SUMBER DAYA ALAM DAN EKOSISTEM'
          ).toUpperCase(),
          font: KOP_FONT,
          size: halfPt(12), // 12 pt Bold
          bold: true,
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 0, line: LINE_BODY },
      children: [
        new TextRun({
          text: (
            logoSettings.agencyLine3 ||
            'BALAI KONSERVASI SUMBER DAYA ALAM JAKARTA'
          ).toUpperCase(),
          font: KOP_FONT,
          size: halfPt(16), // 16 pt Bold
          bold: true,
        }),
      ],
    }),
  ];

  // Logo proporsional 1,9 cm x 1,9 cm (72 px x 72 px pada 96 DPI) di kolom 2,0 cm
  const logoCell = new TableCell({
    width: { size: W_KOP_LOGO, type: WidthType.DXA },
    verticalAlign: VerticalAlign.CENTER,
    borders: NO_BORDERS,
    margins: ZERO_CELL_MARGINS,
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 0, line: LINE_SINGLE },
        children: decodedLogo
          ? [
              new ImageRun({
                data: decodedLogo.bytes,
                type: decodedLogo.type,
                transformation: { width: 72, height: 72 },
              }),
            ]
          : [],
      }),
    ],
  });

  const textCell = new TableCell({
    width: { size: W_KOP_TEXT, type: WidthType.DXA },
    verticalAlign: VerticalAlign.CENTER,
    borders: NO_BORDERS,
    margins: ZERO_CELL_MARGINS,
    children: headerTextParagraphs,
  });

  const kopTable = new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: [W_KOP_LOGO, W_KOP_TEXT],
    layout: TableLayoutType.FIXED,
    borders: NO_BORDERS,
    rows: [
      new TableRow({
        cantSplit: true,
        children: [logoCell, textCell],
      }),
    ],
  });

  // Garis bawah kop tebal-tipis (2 pt = size 16 dalam 1/8 pt)
  const doubleRule = new Paragraph({
    spacing: { before: pt(2), after: pt(6), line: LINE_SINGLE },
    border: {
      bottom: {
        style: BorderStyle.THICK_THIN_MEDIUM_GAP,
        size: 16,
        color: '000000',
        space: 1,
      },
    },
    children: [],
  });

  return [kopTable, doubleRule];
}

function createMenimbangTable(
  record: SuratTugasRecord,
  bodySizeHalfPt: number
): Table {
  const menimbangText = composeMenimbangText(record);

  return new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: [W_LABEL, W_COLON, W_CONTENT],
    layout: TableLayoutType.FIXED,
    borders: NO_BORDERS,
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          createCell(W_LABEL, [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              spacing: { before: 0, after: pt(6), line: LINE_BODY },
              children: [
                new TextRun({
                  text: 'Menimbang',
                  font: FONT_FAMILY,
                  size: bodySizeHalfPt,
                }),
              ],
            }),
          ]),
          createCell(W_COLON, [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 0, after: pt(6), line: LINE_BODY },
              children: [
                new TextRun({
                  text: ':',
                  font: FONT_FAMILY,
                  size: bodySizeHalfPt,
                }),
              ],
            }),
          ]),
          createCell(W_CONTENT, [
            new Paragraph({
              alignment: AlignmentType.JUSTIFIED,
              spacing: { before: 0, after: pt(6), line: LINE_BODY },
              children: [
                new TextRun({
                  text: menimbangText,
                  font: FONT_FAMILY,
                  size: bodySizeHalfPt,
                }),
              ],
            }),
          ]),
        ],
      }),
    ],
  });
}

function createDasarTable(
  dasarList: string[],
  bodySizeHalfPt: number
): Table {
  const formatted = formatDasarItems(dasarList);

  const rows = formatted.map((text, index) => {
    const isFirst = index === 0;
    const isLast = index === formatted.length - 1;
    const afterSpace = isLast ? pt(6) : pt(2.5);

    return new TableRow({
      cantSplit: true,
      children: [
        createCell(W_LABEL, [
          new Paragraph({
            alignment: AlignmentType.LEFT,
            spacing: { before: 0, after: afterSpace, line: LINE_BODY },
            children: [
              new TextRun({
                text: isFirst ? 'Dasar' : '',
                font: FONT_FAMILY,
                size: bodySizeHalfPt,
              }),
            ],
          }),
        ]),
        createCell(W_COLON, [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 0, after: afterSpace, line: LINE_BODY },
            children: [
              new TextRun({
                text: isFirst ? ':' : '',
                font: FONT_FAMILY,
                size: bodySizeHalfPt,
              }),
            ],
          }),
        ]),
        createCell(W_NUM, [
          new Paragraph({
            alignment: AlignmentType.LEFT,
            spacing: { before: 0, after: afterSpace, line: LINE_BODY },
            children: [
              new TextRun({
                text: `${index + 1}.`,
                font: FONT_FAMILY,
                size: bodySizeHalfPt,
              }),
            ],
          }),
        ]),
        createCell(W_URAIAN, [
          new Paragraph({
            alignment: AlignmentType.JUSTIFIED,
            spacing: { before: 0, after: afterSpace, line: LINE_BODY },
            children: [
              new TextRun({
                text,
                font: FONT_FAMILY,
                size: bodySizeHalfPt,
              }),
            ],
          }),
        ]),
      ],
    });
  });

  return new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: [W_LABEL, W_COLON, W_NUM, W_URAIAN],
    layout: TableLayoutType.FIXED,
    borders: NO_BORDERS,
    rows,
  });
}

function createKepadaTerlampirTable(bodySizeHalfPt: number): Table {
  return new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: [W_LABEL, W_COLON, W_CONTENT],
    layout: TableLayoutType.FIXED,
    borders: NO_BORDERS,
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          createCell(W_LABEL, [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              spacing: { before: 0, after: pt(6), line: LINE_BODY },
              children: [
                new TextRun({
                  text: 'Kepada',
                  font: FONT_FAMILY,
                  size: bodySizeHalfPt,
                }),
              ],
            }),
          ]),
          createCell(W_COLON, [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 0, after: pt(6), line: LINE_BODY },
              children: [
                new TextRun({
                  text: ':',
                  font: FONT_FAMILY,
                  size: bodySizeHalfPt,
                }),
              ],
            }),
          ]),
          createCell(W_CONTENT, [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              spacing: { before: 0, after: pt(6), line: LINE_BODY },
              children: [
                new TextRun({
                  text: 'Terlampir',
                  font: FONT_FAMILY,
                  size: bodySizeHalfPt,
                }),
              ],
            }),
          ]),
        ],
      }),
    ],
  });
}

function createKepadaDaftarTable(
  record: SuratTugasRecord,
  bodySizeHalfPt: number
): Table {
  const employees =
    record.pegawaiSnapshot.length > 0
      ? record.pegawaiSnapshot
      : [
          {
            id: 'empty',
            nama: '-',
            nip: '-',
            pangkatGolongan: '-',
            jabatan: '-',
            unit: '-',
          },
        ];

  const rows: TableRow[] = [];
  const compact = employees.length > 3;

  employees.forEach((emp, empIdx) => {
    const namaNip =
      emp.nip && emp.nip !== '-'
        ? `${emp.nama} / ${formatNipSpaced(emp.nip)}`
        : emp.nama;

    const fields: [string, string][] = [
      ['Nama / NIP', namaNip],
      ['Pangkat / Gol.', emp.pangkatGolongan || '-'],
      ['Jabatan', emp.jabatan || '-'],
    ];

    const isVeryLastEmp = empIdx === employees.length - 1;

    fields.forEach(([label, val], fieldIdx) => {
      const isVeryFirst = empIdx === 0 && fieldIdx === 0;
      const isEmpFirst = fieldIdx === 0;
      const isEmpLast = fieldIdx === fields.length - 1;

      let afterSpace = pt(1);
      if (isEmpLast && isVeryLastEmp) {
        afterSpace = pt(6);
      } else if (isEmpLast) {
        afterSpace = compact ? pt(2) : pt(3);
      }

      rows.push(
        new TableRow({
          cantSplit: true,
          children: [
            createCell(W_LABEL, [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                spacing: { before: 0, after: afterSpace, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: isVeryFirst ? 'Kepada' : '',
                    font: FONT_FAMILY,
                    size: bodySizeHalfPt,
                  }),
                ],
              }),
            ]),
            createCell(W_COLON, [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: afterSpace, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: isVeryFirst ? ':' : '',
                    font: FONT_FAMILY,
                    size: bodySizeHalfPt,
                  }),
                ],
              }),
            ]),
            createCell(W_NUM, [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                spacing: { before: 0, after: afterSpace, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: isEmpFirst ? `${empIdx + 1}.` : '',
                    font: FONT_FAMILY,
                    size: bodySizeHalfPt,
                  }),
                ],
              }),
            ]),
            createCell(W_ATTR, [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                spacing: { before: 0, after: afterSpace, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: label,
                    font: FONT_FAMILY,
                    size: bodySizeHalfPt,
                  }),
                ],
              }),
            ]),
            createCell(W_COLON, [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: afterSpace, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: ':',
                    font: FONT_FAMILY,
                    size: bodySizeHalfPt,
                  }),
                ],
              }),
            ]),
            createCell(W_ATTR_VAL, [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                spacing: { before: 0, after: afterSpace, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: val,
                    font: FONT_FAMILY,
                    size: bodySizeHalfPt,
                  }),
                ],
              }),
            ]),
          ],
        })
      );
    });
  });

  return new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: [W_LABEL, W_COLON, W_NUM, W_ATTR, W_COLON, W_ATTR_VAL],
    layout: TableLayoutType.FIXED,
    borders: NO_BORDERS,
    rows,
  });
}

function createUntukTable(
  record: SuratTugasRecord,
  bodySizeHalfPt: number
): Table {
  const poinList = buildUntukPoints(record);

  const rows = poinList.map((text, idx) => {
    const isFirst = idx === 0;
    const isLast = idx === poinList.length - 1;
    const afterSpace = isLast ? 0 : pt(2.5);

    return new TableRow({
      cantSplit: true,
      children: [
        createCell(W_LABEL, [
          new Paragraph({
            alignment: AlignmentType.LEFT,
            spacing: { before: 0, after: afterSpace, line: LINE_BODY },
            children: [
              new TextRun({
                text: isFirst ? 'Untuk' : '',
                font: FONT_FAMILY,
                size: bodySizeHalfPt,
              }),
            ],
          }),
        ]),
        createCell(W_COLON, [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 0, after: afterSpace, line: LINE_BODY },
            children: [
              new TextRun({
                text: isFirst ? ':' : '',
                font: FONT_FAMILY,
                size: bodySizeHalfPt,
              }),
            ],
          }),
        ]),
        createCell(W_NUM, [
          new Paragraph({
            alignment: AlignmentType.LEFT,
            spacing: { before: 0, after: afterSpace, line: LINE_BODY },
            children: [
              new TextRun({
                text: `${idx + 1}.`,
                font: FONT_FAMILY,
                size: bodySizeHalfPt,
              }),
            ],
          }),
        ]),
        createCell(W_URAIAN, [
          new Paragraph({
            alignment: AlignmentType.JUSTIFIED,
            spacing: { before: 0, after: afterSpace, line: LINE_BODY },
            children: [
              new TextRun({
                text,
                font: FONT_FAMILY,
                size: bodySizeHalfPt,
              }),
            ],
          }),
        ]),
      ],
    });
  });

  return new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: [W_LABEL, W_COLON, W_NUM, W_URAIAN],
    layout: TableLayoutType.FIXED,
    borders: NO_BORDERS,
    rows,
  });
}

function createSignatureSection(
  record: SuratTugasRecord,
  logoSettings: LogoSettings
): Table {
  const sig = record.penandatanganSnapshot;
  const sigSize = halfPt(11); // 11 pt Regular Arial
  const headerLines = (sig.jabatanHeader || sig.jabatan || 'Kepala Balai,')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);

  const decodedStamp =
    logoSettings.showStampSignature && logoSettings.stampSignatureBase64
      ? decodeBase64DataUrl(logoSettings.stampSignatureBase64)
      : null;

  const rightParagraphs: Paragraph[] = [
    new Paragraph({
      alignment: AlignmentType.LEFT,
      keepNext: true,
      spacing: { before: pt(16), after: 0, line: LINE_BODY }, // 16 pt dari poin terakhir Untuk
      children: [
        new TextRun({
          text: `${record.tempatDitetapkan || 'Jakarta'}, ${formatTanggalIndonesia(
            record.tanggalSurat
          )}`,
          font: FONT_FAMILY,
          size: sigSize,
        }),
      ],
    }),
    ...headerLines.map(
      (line) =>
        new Paragraph({
          alignment: AlignmentType.LEFT,
          keepNext: true,
          spacing: { before: 0, after: 0, line: LINE_BODY },
          children: [
            new TextRun({
              text: line,
              font: FONT_FAMILY,
              size: sigSize,
            }),
          ],
        })
    ),
  ];

  if (decodedStamp) {
    rightParagraphs.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        keepNext: true,
        spacing: { before: pt(4), after: pt(4), line: LINE_SINGLE },
        children: [
          new ImageRun({
            data: decodedStamp.bytes,
            type: decodedStamp.type,
            transformation: { width: 120, height: 64 },
          }),
        ],
      })
    );
  } else {
    // Ruang tanda tangan basah: 50 pt (setara ~4 kali enter, rentang 45 pt - 55 pt)
    rightParagraphs.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        keepNext: true,
        spacing: { before: pt(50), after: 0, line: LINE_SINGLE },
        children: [new TextRun({ text: '', font: FONT_FAMILY, size: sigSize })],
      })
    );
  }

  rightParagraphs.push(
    new Paragraph({
      alignment: AlignmentType.LEFT,
      keepNext: Boolean(sig.nip && sig.nip !== '-'),
      spacing: { before: 0, after: 0, line: LINE_BODY },
      children: [
        new TextRun({
          text: sig.nama,
          font: FONT_FAMILY,
          size: sigSize,
        }),
      ],
    })
  );

  if (sig.nip && sig.nip !== '-') {
    rightParagraphs.push(
      new Paragraph({
        alignment: AlignmentType.LEFT,
        spacing: { before: 0, after: 0, line: LINE_BODY },
        children: [
          new TextRun({
            text: `NIP. ${formatNipSpaced(sig.nip)}`,
            font: FONT_FAMILY,
            size: sigSize,
          }),
        ],
      })
    );
  }

  return new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: [W_SIG_LEFT, W_SIG_RIGHT],
    layout: TableLayoutType.FIXED,
    borders: NO_BORDERS,
    rows: [
      new TableRow({
        cantSplit: true, // Cegah blok tanda tangan terpotong antar halaman
        children: [
          createCell(W_SIG_LEFT, [new Paragraph({ children: [] })]),
          createCell(W_SIG_RIGHT, rightParagraphs),
        ],
      }),
    ],
  });
}

function createLampiranPage(
  record: SuratTugasRecord,
  logoSettings: LogoSettings
): (Paragraph | Table)[] {
  const nomorPrintable = getPrintableNomorSurat(record, true);
  const tanggalPrintable = formatTanggalIndonesia(record.tanggalSurat);

  const metaRight = mm(95);
  const metaLeft = W_TOTAL - metaRight;

  const metaTable = new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: [metaLeft, metaRight],
    layout: TableLayoutType.FIXED,
    borders: NO_BORDERS,
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          createCell(metaLeft, [new Paragraph({ children: [] })]),
          createCell(metaRight, [
            new Paragraph({
              spacing: { before: 0, after: pt(1), line: LINE_BODY },
              children: [
                new TextRun({
                  text: 'Lampiran Surat Tugas Kepala Balai KSDA Jakarta',
                  font: FONT_FAMILY,
                  size: halfPt(10),
                }),
              ],
            }),
            new Paragraph({
              spacing: { before: 0, after: pt(1), line: LINE_BODY },
              children: [
                new TextRun({
                  text: `Nomor\t: ${nomorPrintable}`,
                  font: FONT_FAMILY,
                  size: halfPt(10),
                }),
              ],
            }),
            new Paragraph({
              spacing: { before: 0, after: pt(8), line: LINE_BODY },
              children: [
                new TextRun({
                  text: `Tanggal\t: ${tanggalPrintable}`,
                  font: FONT_FAMILY,
                  size: halfPt(10),
                }),
              ],
            }),
          ]),
        ],
      }),
    ],
  });

  const title = new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: pt(6), after: pt(8), line: LINE_BODY },
    children: [
      new TextRun({
        text: 'DAFTAR PEGAWAI YANG DITUGASKAN',
        font: FONT_FAMILY,
        size: halfPt(11),
        bold: true,
      }),
    ],
  });

  // Total = 11 + 65,6 + 43 + 65 = 184,6 mm
  const colW = [
    mm(11),
    mm(65.6),
    mm(43),
    W_TOTAL - mm(11) - mm(65.6) - mm(43),
  ];

  const headerRow = new TableRow({
    tableHeader: true,
    cantSplit: true,
    children: [
      { label: 'No', width: colW[0], align: AlignmentType.CENTER },
      { label: 'Nama / NIP', width: colW[1], align: AlignmentType.LEFT },
      { label: 'Pangkat / Gol.', width: colW[2], align: AlignmentType.LEFT },
      { label: 'Jabatan', width: colW[3], align: AlignmentType.LEFT },
    ].map(
      (col) =>
        new TableCell({
          width: { size: col.width, type: WidthType.DXA },
          borders: THIN_CELL_BORDERS,
          shading: { fill: 'F1F5F9' },
          verticalAlign: VerticalAlign.CENTER,
          margins: { top: pt(3), bottom: pt(3), left: pt(4), right: pt(4) },
          children: [
            new Paragraph({
              alignment: col.align,
              spacing: { before: 0, after: 0, line: LINE_BODY },
              children: [
                new TextRun({
                  text: col.label,
                  font: FONT_FAMILY,
                  size: halfPt(10),
                  bold: true,
                }),
              ],
            }),
          ],
        })
    ),
  });

  const dataRows = record.pegawaiSnapshot.map(
    (emp, idx) =>
      new TableRow({
        cantSplit: true,
        children: [
          new TableCell({
            width: { size: colW[0], type: WidthType.DXA },
            borders: THIN_CELL_BORDERS,
            verticalAlign: VerticalAlign.TOP,
            margins: { top: pt(3), bottom: pt(3), left: pt(3), right: pt(3) },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 0, after: 0, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: `${idx + 1}.`,
                    font: FONT_FAMILY,
                    size: halfPt(10),
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            width: { size: colW[1], type: WidthType.DXA },
            borders: THIN_CELL_BORDERS,
            verticalAlign: VerticalAlign.TOP,
            margins: { top: pt(3), bottom: pt(3), left: pt(4), right: pt(4) },
            children: [
              new Paragraph({
                spacing: { before: 0, after: pt(1), line: LINE_BODY },
                children: [
                  new TextRun({
                    text: emp.nama,
                    font: FONT_FAMILY,
                    size: halfPt(10),
                  }),
                ],
              }),
              new Paragraph({
                spacing: { before: 0, after: 0, line: LINE_BODY },
                children: [
                  new TextRun({
                    text:
                      emp.nip && emp.nip !== '-'
                        ? `NIP. ${formatNipSpaced(emp.nip)}`
                        : '-',
                    font: FONT_FAMILY,
                    size: halfPt(9.5),
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            width: { size: colW[2], type: WidthType.DXA },
            borders: THIN_CELL_BORDERS,
            verticalAlign: VerticalAlign.TOP,
            margins: { top: pt(3), bottom: pt(3), left: pt(4), right: pt(4) },
            children: [
              new Paragraph({
                spacing: { before: 0, after: 0, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: emp.pangkatGolongan || '-',
                    font: FONT_FAMILY,
                    size: halfPt(10),
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            width: { size: colW[3], type: WidthType.DXA },
            borders: THIN_CELL_BORDERS,
            verticalAlign: VerticalAlign.TOP,
            margins: { top: pt(3), bottom: pt(3), left: pt(4), right: pt(4) },
            children: [
              new Paragraph({
                spacing: { before: 0, after: 0, line: LINE_BODY },
                children: [
                  new TextRun({
                    text: emp.jabatan || '-',
                    font: FONT_FAMILY,
                    size: halfPt(10),
                  }),
                ],
              }),
            ],
          }),
        ],
      })
  );

  const empTable = new Table({
    width: { size: W_TOTAL, type: WidthType.DXA },
    columnWidths: colW,
    layout: TableLayoutType.FIXED,
    rows: [headerRow, ...dataRows],
  });

  return [
    new Paragraph({ pageBreakBefore: true, children: [] }),
    metaTable,
    title,
    empTable,
    createSignatureSection(record, logoSettings),
  ];
}

export function buildSuratTugasDocument(
  record: SuratTugasRecord,
  logoSettings: LogoSettings
): Document {
  const isF4 = logoSettings.paperSize === 'F4';
  const pageWidth = mm(210); // 21,0 cm
  const pageHeight = mm(isF4 ? 330 : 297); // A4 Portrait = 29,7 cm

  const isLampiranMode = isRecordLampiranMode(record);
  const bodyFontPt = getBodyFontPt(record);
  const bodySizeHalfPt = halfPt(bodyFontPt);
  const nomorPrintable = getPrintableNomorSurat(record, true);

  const children: (Paragraph | Table)[] = [
    ...createLetterhead(logoSettings),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: pt(4), line: LINE_BODY },
      children: [
        new TextRun({
          text: 'SURAT TUGAS',
          font: FONT_FAMILY,
          size: halfPt(11),
          bold: true,
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: pt(4), line: LINE_BODY },
      children: [
        new TextRun({
          text: `NOMOR : ${nomorPrintable}`,
          font: FONT_FAMILY,
          size: halfPt(11),
          bold: true,
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: pt(6), line: LINE_BODY },
      children: [
        new TextRun({
          text: 'KEPALA BALAI',
          font: FONT_FAMILY,
          size: halfPt(11),
          bold: true,
        }),
      ],
    }),
    createMenimbangTable(record, bodySizeHalfPt),
    createDasarTable(record.dasarHukum, bodySizeHalfPt),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: pt(6), after: pt(6), line: LINE_BODY },
      children: [
        new TextRun({
          text: 'MEMBERI TUGAS',
          font: FONT_FAMILY,
          size: halfPt(11),
          bold: true,
        }),
      ],
    }),
    isLampiranMode
      ? createKepadaTerlampirTable(bodySizeHalfPt)
      : createKepadaDaftarTable(record, bodySizeHalfPt),
    createUntukTable(record, bodySizeHalfPt),
    createSignatureSection(record, logoSettings),
  ];

  const tembusanClean = (record.tembusan || [])
    .map((t) => t.trim())
    .filter(Boolean);
  if (tembusanClean.length > 0) {
    const tembusanParagraphs: Paragraph[] = [
      new Paragraph({
        alignment: AlignmentType.LEFT,
        keepNext: true,
        spacing: { before: 0, after: pt(2), line: LINE_BODY },
        children: [
          new TextRun({
            text: 'Tembusan :',
            font: FONT_FAMILY,
            size: halfPt(10),
          }),
        ],
      }),
      ...tembusanClean.map(
        (item, idx) =>
          new Paragraph({
            alignment: AlignmentType.LEFT,
            spacing: { before: 0, after: pt(1), line: LINE_BODY },
            children: [
              new TextRun({
                text: `${idx + 1}. ${item}`,
                font: FONT_FAMILY,
                size: halfPt(10),
              }),
            ],
          })
      ),
    ];

    children.push(
      new Table({
        width: { size: W_TOTAL, type: WidthType.DXA },
        columnWidths: [W_TOTAL],
        layout: TableLayoutType.FIXED,
        borders: NO_BORDERS,
        float: {
          horizontalAnchor: TableAnchorType.MARGIN,
          relativeHorizontalPosition: RelativeHorizontalPosition.LEFT,
          verticalAnchor: TableAnchorType.MARGIN,
          relativeVerticalPosition: RelativeVerticalPosition.BOTTOM,
          topFromText: pt(10),
          overlap: OverlapType.NEVER,
        },
        rows: [
          new TableRow({
            cantSplit: true,
            children: [createCell(W_TOTAL, tembusanParagraphs)],
          }),
        ],
      })
    );

    if (isLampiranMode) {
      // Paragraf jangkar agar tabel Tembusan tetap terkunci di pojok kiri bawah Halaman 1
      children.push(
        new Paragraph({
          spacing: { before: 0, after: 0, line: LINE_SINGLE },
          children: [],
        })
      );
    }
  }

  if (isLampiranMode) {
    children.push(...createLampiranPage(record, logoSettings));
  }

  return new Document({
    sections: [
      {
        properties: {
          page: {
            size: {
              width: pageWidth,
              height: pageHeight,
            },
            margin: {
              top: inch(0.25), // 0,25" (0,635 cm)
              bottom: inch(0.81), // 0,81" (2,057 cm)
              left: inch(0.5), // 0,5" (1,27 cm) — area cetak luas 18,46 cm
              right: inch(0.5), // 0,5" (1,27 cm)
              gutter: 0, // 0"
              header: inch(0.25),
              footer: inch(0.4),
            },
          },
        },
        children,
      },
    ],
  });
}

export async function generateSuratTugasDocx(
  record: SuratTugasRecord,
  logoSettings: LogoSettings
): Promise<void> {
  const doc = buildSuratTugasDocument(record, logoSettings);
  const blob = await Packer.toBlob(doc);
  const safeNomor = record.nomorSurat
    .replace(/[^a-zA-Z0-9._-]+/g, '_')
    .replace(/^_+|_+$/g, '');
  const filename = `Surat_Tugas_${safeNomor || 'BKSDA'}_${record.tanggalSurat || 'draft'}.docx`;
  saveAs(blob, filename);
}
