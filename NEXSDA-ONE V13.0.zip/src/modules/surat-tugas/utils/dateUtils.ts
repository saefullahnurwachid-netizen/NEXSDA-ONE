import type { SuratTugasRecord } from '../types';

export const HARI_INDONESIA = [
  'Minggu',
  'Senin',
  'Selasa',
  'Rabu',
  'Kamis',
  'Jumat',
  'Sabtu',
] as const;

export const BULAN_INDONESIA = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
] as const;

export const BULAN_ROMAWI = [
  'I',
  'II',
  'III',
  'IV',
  'V',
  'VI',
  'VII',
  'VIII',
  'IX',
  'X',
  'XI',
  'XII',
] as const;

export function getTodayIsoDate(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseIsoDateParts(
  dateStr: string
): { year: number; month: number; day: number } | null {
  if (!dateStr) return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(dateStr.trim());
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  return { year, month, day };
}

export function getNamaHariIndonesia(dateStr: string): string {
  const parts = parseIsoDateParts(dateStr);
  if (!parts) return '-';
  const dt = new Date(Date.UTC(parts.year, parts.month - 1, parts.day));
  return HARI_INDONESIA[dt.getUTCDay()] || '-';
}

export function formatHariKegiatanIndonesia(
  startDate: string,
  endDate: string
): string {
  const start = parseIsoDateParts(startDate);
  const end = parseIsoDateParts(endDate || startDate);
  if (!start) return '-';
  const hariMulai = getNamaHariIndonesia(startDate);
  if (!end) return hariMulai;

  if (
    start.year === end.year &&
    start.month === end.month &&
    start.day === end.day
  ) {
    return hariMulai;
  }

  const hariSelesai = getNamaHariIndonesia(endDate);
  return `${hariMulai} s.d. ${hariSelesai}`;
}

export function formatTanggalIndonesia(dateStr: string): string {
  const parts = parseIsoDateParts(dateStr);
  if (!parts) return dateStr || '-';
  return `${parts.day} ${BULAN_INDONESIA[parts.month - 1]} ${parts.year}`;
}

export function formatRentangTanggalIndonesia(
  startDate: string,
  endDate: string
): string {
  const start = parseIsoDateParts(startDate);
  const end = parseIsoDateParts(endDate || startDate);
  if (!start) return '-';
  if (!end) return formatTanggalIndonesia(startDate);

  if (
    start.year === end.year &&
    start.month === end.month &&
    start.day === end.day
  ) {
    return `${start.day} ${BULAN_INDONESIA[start.month - 1]} ${start.year}`;
  }

  if (start.year === end.year && start.month === end.month) {
    return `${start.day} s.d. ${end.day} ${BULAN_INDONESIA[start.month - 1]} ${start.year}`;
  }

  if (start.year === end.year) {
    return `${start.day} ${BULAN_INDONESIA[start.month - 1]} s.d. ${end.day} ${BULAN_INDONESIA[end.month - 1]} ${start.year}`;
  }

  return `${start.day} ${BULAN_INDONESIA[start.month - 1]} ${start.year} s.d. ${end.day} ${BULAN_INDONESIA[end.month - 1]} ${end.year}`;
}

export function hitungLamaHari(startDate: string, endDate: string): number {
  const start = parseIsoDateParts(startDate);
  const end = parseIsoDateParts(endDate || startDate);
  if (!start || !end) return 1;
  const utcStart = Date.UTC(start.year, start.month - 1, start.day);
  const utcEnd = Date.UTC(end.year, end.month - 1, end.day);
  const diffDays = Math.floor((utcEnd - utcStart) / 86400000) + 1;
  return diffDays >= 1 ? diffDays : 1;
}

export function bulanKeRomawi(month1To12: number): string {
  if (month1To12 < 1 || month1To12 > 12) return 'I';
  return BULAN_ROMAWI[month1To12 - 1];
}

export function angkaTerbilang(n: number): string {
  const num = Math.floor(Math.abs(n));
  const satuan = [
    'nol',
    'satu',
    'dua',
    'tiga',
    'empat',
    'lima',
    'enam',
    'tujuh',
    'delapan',
    'sembilan',
    'sepuluh',
    'sebelas',
  ];
  if (num < 12) return satuan[num];
  if (num < 20) return `${satuan[num - 10]} belas`;
  if (num < 100) {
    const puluh = Math.floor(num / 10);
    const sisa = num % 10;
    return sisa === 0
      ? `${satuan[puluh]} puluh`
      : `${satuan[puluh]} puluh ${satuan[sisa]}`;
  }
  if (num < 200) {
    const sisa = num - 100;
    return sisa === 0 ? 'seratus' : `seratus ${angkaTerbilang(sisa)}`;
  }
  if (num < 1000) {
    const ratus = Math.floor(num / 100);
    const sisa = num % 100;
    return sisa === 0
      ? `${satuan[ratus]} ratus`
      : `${satuan[ratus]} ratus ${angkaTerbilang(sisa)}`;
  }
  return String(num);
}

export function formatNipSpaced(nip: string): string {
  const clean = String(nip || '').replace(/\s+/g, '');
  if (/^\d{18}$/.test(clean)) {
    return `${clean.slice(0, 8)} ${clean.slice(8, 14)} ${clean.slice(14, 15)} ${clean.slice(15, 18)}`;
  }
  return nip || '-';
}

export function getNextNomorStSequence(
  existingRecords: SuratTugasRecord[],
  tahun: string | number
): string {
  const targetYear = Number(tahun) || new Date().getFullYear();
  let maxSeq = 0;

  for (const rec of existingRecords) {
    const recYear =
      Number(rec.tahunNomor) ||
      parseIsoDateParts(rec.tanggalSurat)?.year ||
      targetYear;
    if (recYear !== targetYear) continue;

    if (rec.nomorSt && /^\d+$/.test(rec.nomorSt.trim())) {
      const seq = Number(rec.nomorSt.trim());
      if (seq > maxSeq) maxSeq = seq;
      continue;
    }

    const m = /^ST\.(\d+)/i.exec(rec.nomorSurat.trim());
    if (m) {
      const seq = Number(m[1]);
      if (seq > maxSeq) maxSeq = seq;
    }
  }

  return String(maxSeq + 1).padStart(3, '0');
}

export function composeNomorSuratBksda(params: {
  nomorSt?: string;
  kodeKlasifikasi?: string;
  bulan: number | string;
  tahun: number | string;
  useNonBreakingBlank?: boolean;
}): string {
  const cleanNomor = (params.nomorSt || '').trim();
  const blankGap = params.useNonBreakingBlank
    ? '\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0'
    : '        ';
  const seqPart = cleanNomor || blankGap;
  const cleanKode =
    (params.kodeKlasifikasi || 'TU').trim().replace(/^\/+|\/+$/g, '') || 'TU';
  const cleanBulan = String(params.bulan || new Date().getMonth() + 1).trim();
  const cleanTahun = String(params.tahun || new Date().getFullYear()).trim();

  return `ST.${seqPart}/K.13/${cleanKode}/Peg.10.05/B/${cleanBulan}/${cleanTahun}`;
}

/**
 * Format resmi BKSDA Jakarta sesuai template:
 * ST.{{NOMOR_ST}}/K.13/{{KODE_KLASIFIKASI}}/Peg.10.05/B/{{BULAN}}/{{TAHUN}}
 */
export function generateNomorSuratOtomatis(
  existingRecords: SuratTugasRecord[],
  tanggalSurat: string,
  kodeKlasifikasi = 'TU'
): string {
  const parts =
    parseIsoDateParts(tanggalSurat) || parseIsoDateParts(getTodayIsoDate())!;
  const nextSeq = getNextNomorStSequence(existingRecords, parts.year);
  return composeNomorSuratBksda({
    nomorSt: nextSeq,
    kodeKlasifikasi,
    bulan: parts.month,
    tahun: parts.year,
  });
}

export function composeMenimbangText(record: {
  menimbangCustom?: string;
  jenisDasarKegiatan?: string;
  lokasiWilayahKerja?: string;
  maksudTugas?: string;
  lokasiTugas?: string;
  tindakLanjut?: string;
}): string {
  if (record.menimbangCustom && record.menimbangCustom.trim()) {
    return record.menimbangCustom.trim();
  }
  const jenis = (record.jenisDasarKegiatan || record.maksudTugas || '')
    .trim()
    .replace(/\.+$/, '');
  const wilayah = (record.lokasiWilayahKerja || record.lokasiTugas || '')
    .trim()
    .replace(/\.+$/, '');
  const tindakLanjut = (record.tindakLanjut || '')
    .trim()
    .replace(/[;.]+$/, '');

  const jenisText = jenis || '...';
  const wilayahText = wilayah || '...';
  const tindakLanjutText = tindakLanjut || '...';

  const lokasiFrasa =
    wilayah && /^wilayah\s+/i.test(wilayah)
      ? `di ${wilayahText}`
      : `di wilayah ${wilayahText}`;

  return `Bahwa dalam rangka ${jenisText} ${lokasiFrasa} perlu dilakukan ${tindakLanjutText};`;
}
