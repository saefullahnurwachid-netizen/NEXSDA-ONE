import { saveAs } from 'file-saver';
import {
  AlertCircle,
  BookmarkCheck,
  CheckCircle2,
  Download,
  FilePlus2,
  History,
  Image as ImageIcon,
  Info,
  ListChecks,
  Upload,
  Users,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import CreateLetterView from './components/CreateLetterView';
import DipaSignatoryView from './components/DipaSignatoryView';
import EmployeesView from './components/EmployeesView';
import HistoryView from './components/HistoryView';
import LetterPreviewModal from './components/LetterPreviewModal';
import LogoSettingsView from './components/LogoSettingsView';
import MasterOptionsView from './components/MasterOptionsView';
import type {
  ConfirmDialogConfig,
  DipaAccount,
  Employee,
  LogoSettings,
  MasterCategoryKey,
  MasterOptions,
  Signatory,
  SuratTugasRecord,
  SuratTugasTab,
  ToastNotice,
} from './types';
import { generateNomorSuratOtomatis, getTodayIsoDate } from './utils/dateUtils';
import {
  STORAGE_KEYS,
  buildBackupPayload,
  loadSk01AsnData,
  loadStoredDipaAccounts,
  loadStoredEmployees,
  loadStoredLetters,
  loadStoredLogoSettings,
  loadStoredMasterOptions,
  loadStoredSignatories,
  mergeEmployeesWithSk01,
  parseBackupPayload,
  saveStoredDipaAccounts,
  saveStoredEmployees,
  saveStoredLetters,
  saveStoredLogoSettings,
  saveStoredMasterOptions,
  saveStoredSignatories,
} from './utils/storageUtils';

const TABS: {
  id: SuratTugasTab;
  label: string;
  icon: typeof FilePlus2;
}[] = [
  { id: 'create', label: 'Buat Surat', icon: FilePlus2 },
  { id: 'history', label: 'Riwayat Surat', icon: History },
  { id: 'employees', label: 'Data Pegawai (ASN)', icon: Users },
  { id: 'signatories', label: 'Penandatangan & DIPA', icon: BookmarkCheck },
  { id: 'logo', label: 'Kop & Logo', icon: ImageIcon },
  { id: 'master', label: 'Master Opsi Surat', icon: ListChecks },
];

export default function SuratTugasModule() {
  const [activeTab, setActiveTab] = useState<SuratTugasTab>('create');
  const [activeMasterCategory, setActiveMasterCategory] =
    useState<MasterCategoryKey>('dasarSurat');

  const handleNavigateTab = useCallback(
    (tab: SuratTugasTab, masterCategory?: MasterCategoryKey) => {
      if (masterCategory) {
        setActiveMasterCategory(masterCategory);
      }
      setActiveTab(tab);
    },
    []
  );

  const [letters, setLetters] = useState<SuratTugasRecord[]>(() =>
    loadStoredLetters()
  );
  const [employees, setEmployees] = useState<Employee[]>(() =>
    loadStoredEmployees()
  );
  const [signatories, setSignatories] = useState<Signatory[]>(() =>
    loadStoredSignatories()
  );
  const [dipaAccounts, setDipaAccounts] = useState<DipaAccount[]>(() =>
    loadStoredDipaAccounts()
  );
  const [logoSettings, setLogoSettings] = useState<LogoSettings>(() =>
    loadStoredLogoSettings()
  );
  const [masterOptions, setMasterOptions] = useState<MasterOptions>(() =>
    loadStoredMasterOptions()
  );

  const [editingRecord, setEditingRecord] = useState<SuratTugasRecord | null>(
    null
  );
  const [previewRecord, setPreviewRecord] = useState<SuratTugasRecord | null>(
    null
  );
  const [toasts, setToasts] = useState<ToastNotice[]>([]);
  const [confirmDialog, setConfirmDialog] =
    useState<ConfirmDialogConfig | null>(null);

  const restoreInputRef = useRef<HTMLInputElement | null>(null);

  const notify = useCallback(
    (type: ToastNotice['type'], message: string) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      setToasts((prev) => [...prev, { id, type, message }]);
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4200);
    },
    []
  );

  // Sinkronisasi awal otomatis daftar ASN dari public/assets/data/sk01_2026_asn.js
  useEffect(() => {
    let active = true;
    const syncInitial = async () => {
      const sk01List = await loadSk01AsnData();
      if (!active || sk01List.length === 0) return;

      const currentStored = loadStoredEmployees();
      const alreadySynced =
        window.localStorage.getItem(STORAGE_KEYS.SK01_SYNCED_FLAG) === '1';

      if (currentStored.length === 0 || !alreadySynced) {
        const { merged, addedCount } = mergeEmployeesWithSk01(
          currentStored,
          sk01List
        );
        saveStoredEmployees(merged);
        window.localStorage.setItem(STORAGE_KEYS.SK01_SYNCED_FLAG, '1');
        setEmployees(merged);
        if (addedCount > 0) {
          notify(
            'info',
            `Berhasil menyinkronkan ${addedCount} personil ASN dari Master SK 01 Tahun 2026.`
          );
        }
      }
    };
    void syncInitial();
    return () => {
      active = false;
    };
  }, [notify]);

  const handleSaveLetter = useCallback(
    (record: SuratTugasRecord, isUpdate: boolean) => {
      setLetters((prev) => {
        const next = isUpdate
          ? prev.map((l) => (l.id === record.id ? record : l))
          : [record, ...prev];
        saveStoredLetters(next);
        return next;
      });
      if (isUpdate) {
        setEditingRecord(null);
        notify('success', `Perubahan Surat Tugas ${record.nomorSurat} berhasil disimpan.`);
      } else {
        notify('success', `Surat Tugas ${record.nomorSurat} berhasil disimpan ke riwayat.`);
      }
    },
    [notify]
  );

  const handleDeleteLetter = useCallback(
    (id: string) => {
      setLetters((prev) => {
        const next = prev.filter((l) => l.id !== id);
        saveStoredLetters(next);
        return next;
      });
      if (editingRecord?.id === id) setEditingRecord(null);
      notify('success', 'Riwayat Surat Tugas berhasil dihapus.');
    },
    [editingRecord?.id, notify]
  );

  const handleEditLetter = useCallback((record: SuratTugasRecord) => {
    setEditingRecord(record);
    setActiveTab('create');
  }, []);

  const handleDuplicateLetter = useCallback(
    (record: SuratTugasRecord) => {
      const today = getTodayIsoDate();
      const freshNomor = generateNomorSuratOtomatis(
        letters,
        today,
        record.kodeKlasifikasi
      );
      const duplicated: SuratTugasRecord = {
        ...record,
        id: `st-${Date.now()}`,
        nomorSurat: freshNomor,
        tanggalSurat: today,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      // Muat ke formulir sebagai surat baru (bukan menimpa surat lama)
      setEditingRecord(null);
      setActiveTab('create');
      window.setTimeout(() => {
        setEditingRecord({ ...duplicated, id: `st-dup-${Date.now()}` });
      }, 0);
      notify(
        'info',
        `Surat diduplikat dengan nomor baru ${freshNomor}. Silakan sesuaikan lalu simpan.`
      );
    },
    [letters, notify]
  );

  const handleSaveEmployee = useCallback(
    (emp: Employee, isEdit: boolean) => {
      setEmployees((prev) => {
        const next = isEdit
          ? prev.map((e) => (e.id === emp.id ? emp : e))
          : [emp, ...prev];
        saveStoredEmployees(next);
        return next;
      });
      notify(
        'success',
        isEdit
          ? `Data pegawai "${emp.nama}" berhasil diperbarui.`
          : `Pegawai "${emp.nama}" berhasil ditambahkan.`
      );
    },
    [notify]
  );

  const handleDeleteEmployee = useCallback(
    (id: string) => {
      setEmployees((prev) => {
        const next = prev.filter((e) => e.id !== id);
        saveStoredEmployees(next);
        return next;
      });
      notify('success', 'Data pegawai berhasil dihapus.');
    },
    [notify]
  );

  const handleImportEmployees = useCallback(
    (imported: Employee[]) => {
      setEmployees((prev) => {
        const { merged, addedCount } = mergeEmployeesWithSk01(prev, imported);
        saveStoredEmployees(merged);
        notify(
          'success',
          `Import selesai: ${addedCount} pegawai baru ditambahkan (${imported.length - addedCount} duplikat dilewati).`
        );
        return merged;
      });
    },
    [notify]
  );

  const handleResyncSk01 = useCallback(async () => {
    const sk01List = await loadSk01AsnData();
    if (sk01List.length === 0) {
      notify('error', 'Berkas Master ASN SK 01/2026 tidak dapat dimuat.');
      return;
    }
    setEmployees((prev) => {
      const { merged, addedCount } = mergeEmployeesWithSk01(prev, sk01List);
      saveStoredEmployees(merged);
      notify(
        'success',
        addedCount > 0
          ? `Sinkronisasi SK 01/2026 selesai: ${addedCount} pegawai baru ditambahkan.`
          : `Seluruh ${sk01List.length} personil ASN SK 01/2026 sudah tersinkronisasi.`
      );
      return merged;
    });
  }, [notify]);

  const handleSaveSignatories = useCallback((list: Signatory[]) => {
    setSignatories(list);
    saveStoredSignatories(list);
  }, []);

  const handleSaveDipaAccounts = useCallback((list: DipaAccount[]) => {
    setDipaAccounts(list);
    saveStoredDipaAccounts(list);
  }, []);

  const handleSaveLogoSettings = useCallback((next: LogoSettings) => {
    setLogoSettings(next);
    saveStoredLogoSettings(next);
  }, []);

  const handleSaveMasterOptions = useCallback((next: MasterOptions) => {
    setMasterOptions(next);
    saveStoredMasterOptions(next);
  }, []);

  // Backup & Restore JSON
  const handleExportBackup = () => {
    const payload = buildBackupPayload({
      letters,
      employees,
      signatories,
      dipaAccounts,
      logoSettings,
      masterOptions,
    });
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const stamp = new Date().toISOString().slice(0, 10);
    saveAs(blob, `Backup_Sistem_Surat_Tugas_NEXSDA_${stamp}.json`);
    notify('success', 'Berkas cadangan (Backup JSON) berhasil diunduh.');
  };

  const handleRestoreBackupFile = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const text = await file.text();
      const restored = parseBackupPayload(text);
      setConfirmDialog({
        title: 'Pulihkan Data dari Cadangan JSON?',
        description: `Berkas berisi ${restored.letters.length} surat tugas dan ${restored.employees.length} data pegawai. Data modul Surat Tugas saat ini akan diganti dengan isi berkas cadangan.`,
        confirmLabel: 'Ya, Pulihkan Data',
        onConfirm: () => {
          setLetters(restored.letters);
          saveStoredLetters(restored.letters);
          setEmployees(restored.employees);
          saveStoredEmployees(restored.employees);
          setSignatories(restored.signatories);
          saveStoredSignatories(restored.signatories);
          setDipaAccounts(restored.dipaAccounts);
          saveStoredDipaAccounts(restored.dipaAccounts);
          setLogoSettings(restored.logoSettings);
          saveStoredLogoSettings(restored.logoSettings);
          setMasterOptions(restored.masterOptions);
          saveStoredMasterOptions(restored.masterOptions);
          setEditingRecord(null);
          notify(
            'success',
            `Pemulihan selesai: ${restored.letters.length} surat dan ${restored.employees.length} pegawai berhasil dipulihkan.`
          );
        },
      });
    } catch (err) {
      notify(
        'error',
        err instanceof Error ? err.message : 'Gagal membaca berkas cadangan JSON.'
      );
    }
  };

  // Saat duplikat, pastikan mode adalah buat baru saat disimpan
  const isActuallyUpdating = Boolean(
    editingRecord && letters.some((l) => l.id === editingRecord.id)
  );

  return (
    <div
      className="flex flex-col h-full w-full bg-slate-50 text-slate-900 overflow-hidden"
      style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}
    >
      {/* Header Modul & Navigasi Tab Internal (Tersembunyi saat Print) */}
      <div className="bg-white border-b border-slate-200 shrink-0 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-4 pb-3 flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-lg font-bold tracking-tight text-slate-900 truncate">
              Sistem Surat Tugas — Balai KSDA Jakarta
            </h1>
            <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
              Seksi KSDA Wilayah I · {letters.length} surat tersimpan ·{' '}
              {employees.length} personil ASN · Kertas {logoSettings.paperSize}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleExportBackup}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-[#14532d]" />
              Backup JSON
            </button>
            <button
              type="button"
              onClick={() => restoreInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-[#14532d]" />
              Restore JSON
            </button>
            <input
              ref={restoreInputRef}
              type="file"
              accept=".json,application/json"
              onChange={(e) => void handleRestoreBackupFile(e)}
              className="hidden"
            />
          </div>
        </div>

        {/* Navigasi Tab Internal */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 overflow-x-auto">
          <nav
            aria-label="Navigasi Sistem Surat Tugas"
            className="flex items-center gap-1 border-t border-slate-100 pt-1"
          >
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`inline-flex items-center gap-2 px-3.5 py-2.5 text-xs font-semibold border-b-2 transition whitespace-nowrap shrink-0 cursor-pointer ${
                    isActive
                      ? 'border-[#14532d] text-[#14532d]'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{tab.label}</span>
                  {tab.id === 'history' && letters.length > 0 && (
                    <span className="text-[11px] font-mono tabular-nums text-slate-400">
                      ({letters.length})
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Konten Utama Modul */}
      <div className="flex-1 overflow-y-auto print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
          {activeTab === 'create' && (
            <CreateLetterView
              employees={employees}
              signatories={signatories}
              dipaAccounts={dipaAccounts}
              masterOptions={masterOptions}
              logoSettings={logoSettings}
              existingLetters={letters}
              editingRecord={editingRecord}
              onCancelEdit={() => setEditingRecord(null)}
              onSaveLetter={(rec) => handleSaveLetter(rec, isActuallyUpdating)}
              onOpenPreview={(rec) => setPreviewRecord(rec)}
              onNavigateTab={handleNavigateTab}
              onNotify={notify}
            />
          )}

          {activeTab === 'history' && (
            <HistoryView
              letters={letters}
              logoSettings={logoSettings}
              onPreview={(rec) => setPreviewRecord(rec)}
              onEdit={handleEditLetter}
              onDuplicate={handleDuplicateLetter}
              onDelete={handleDeleteLetter}
              onCreateNew={() => {
                setEditingRecord(null);
                setActiveTab('create');
              }}
              onConfirm={(cfg) => setConfirmDialog(cfg)}
              onNotify={notify}
            />
          )}

          {activeTab === 'employees' && (
            <EmployeesView
              employees={employees}
              onSaveEmployee={handleSaveEmployee}
              onDeleteEmployee={handleDeleteEmployee}
              onImportEmployees={handleImportEmployees}
              onResyncSk01={handleResyncSk01}
              onConfirm={(cfg) => setConfirmDialog(cfg)}
              onNotify={notify}
            />
          )}

          {activeTab === 'signatories' && (
            <DipaSignatoryView
              signatories={signatories}
              dipaAccounts={dipaAccounts}
              employees={employees}
              onSaveSignatories={handleSaveSignatories}
              onSaveDipaAccounts={handleSaveDipaAccounts}
              onConfirm={(cfg) => setConfirmDialog(cfg)}
              onNotify={notify}
            />
          )}

          {activeTab === 'logo' && (
            <LogoSettingsView
              settings={logoSettings}
              onSaveSettings={handleSaveLogoSettings}
              onNotify={notify}
            />
          )}

          {activeTab === 'master' && (
            <MasterOptionsView
              options={masterOptions}
              initialCategory={activeMasterCategory}
              onSaveOptions={handleSaveMasterOptions}
              onConfirm={(cfg) => setConfirmDialog(cfg)}
              onNotify={notify}
            />
          )}
        </div>
      </div>

      {/* Modal Pratinjau Dokumen Resmi */}
      <LetterPreviewModal
        record={previewRecord}
        logoSettings={logoSettings}
        onClose={() => setPreviewRecord(null)}
        onNotify={notify}
      />

      {/* Modal Konfirmasi Aksi */}
      {confirmDialog && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 print:hidden"
        >
          <div className="w-full max-w-md bg-white rounded-xl border border-slate-200 shadow-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100">
              <h3 className="text-sm font-semibold text-slate-900">
                {confirmDialog.title}
              </h3>
            </div>
            <div className="px-5 py-4 text-xs text-slate-600 leading-relaxed">
              {confirmDialog.description}
            </div>
            <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDialog(null)}
                className="px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  const fn = confirmDialog.onConfirm;
                  setConfirmDialog(null);
                  fn();
                }}
                className={`px-4 py-2 rounded-lg text-white text-xs font-semibold cursor-pointer ${
                  confirmDialog.danger
                    ? 'bg-red-600 hover:bg-red-700'
                    : 'bg-[#14532d] hover:bg-[#166534]'
                }`}
              >
                {confirmDialog.confirmLabel || 'Konfirmasi'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notifikasi Toast */}
      {toasts.length > 0 && (
        <div
          aria-live="polite"
          className="fixed bottom-4 right-4 z-[70] flex flex-col gap-2 max-w-sm print:hidden"
        >
          {toasts.map((t) => (
            <div
              key={t.id}
              className={`flex items-start gap-2.5 px-4 py-3 rounded-xl border shadow-lg text-xs font-medium bg-white ${
                t.type === 'success'
                  ? 'border-emerald-300 text-emerald-950'
                  : t.type === 'error'
                    ? 'border-red-300 text-red-950'
                    : 'border-slate-300 text-slate-900'
              }`}
            >
              {t.type === 'success' && (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              )}
              {t.type === 'error' && (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              )}
              {t.type === 'info' && (
                <Info className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
              )}
              <span className="flex-1 leading-snug">{t.message}</span>
              <button
                type="button"
                onClick={() =>
                  setToasts((prev) => prev.filter((item) => item.id !== t.id))
                }
                aria-label="Tutup notifikasi"
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
