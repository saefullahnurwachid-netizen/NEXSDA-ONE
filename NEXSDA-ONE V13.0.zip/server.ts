import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express from 'express';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

dotenv.config();

const CURRENT_DIR =
  typeof import.meta !== 'undefined' && typeof import.meta.url === 'string'
    ? path.dirname(fileURLToPath(import.meta.url))
    : process.cwd();

const PORT = Number(process.env.PORT || 3000);
const DRIVE_DB_FILENAME = 'NEXSDA_ONE_Database_Live.json';
const DEFAULT_APPS_SCRIPT_URL =
  'https://script.google.com/macros/s/AKfycbyfZIbbabLNrs41_iNUa_-0z4WOGoqCTGCZLsybHkwD2p3MLo3ZFOozZPTo1OmwbV3XmQ/exec';

function getEditAccessCode(): string {
  return (process.env.NEXSDA_EDIT_CODE || 'NexsdaONE@134').trim();
}

function getEditTokenSecret(): Buffer {
  return crypto
    .createHash('sha256')
    .update(`nexsda-one-edit-session:${getEditAccessCode()}`)
    .digest();
}

function safeCompareText(a: string, b: string): boolean {
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function createEditSessionToken(): string {
  const payload = Buffer.from(
    JSON.stringify({ role: 'editor', exp: Date.now() + 24 * 60 * 60 * 1000 }),
    'utf8'
  ).toString('base64url');
  const sig = crypto
    .createHmac('sha256', getEditTokenSecret())
    .update(payload)
    .digest('base64url');
  return `${payload}.${sig}`;
}

function verifyEditSessionToken(token: string | null | undefined): boolean {
  if (!token || typeof token !== 'string') return false;
  const parts = token.split('.');
  if (parts.length !== 2) return false;
  const [payload, sig] = parts;
  if (!payload || !sig) return false;
  const expectedSig = crypto
    .createHmac('sha256', getEditTokenSecret())
    .update(payload)
    .digest('base64url');
  if (!safeCompareText(sig, expectedSig)) return false;
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as {
      role?: string;
      exp?: number;
    };
    return parsed.role === 'editor' && typeof parsed.exp === 'number' && parsed.exp > Date.now();
  } catch {
    return false;
  }
}

function extractEditToken(req: express.Request): string {
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) {
    return auth.slice(7).trim();
  }
  const headerToken = req.headers['x-edit-token'];
  return typeof headerToken === 'string' ? headerToken.trim() : '';
}

function resolveDriveBackend() {
  const explicitScriptUrl = (process.env.GOOGLE_DRIVE_APPS_SCRIPT_URL || '').trim();
  const saCreds = parseServiceAccountCredentials();
  const scriptUrl = explicitScriptUrl || (!saCreds ? DEFAULT_APPS_SCRIPT_URL : '');
  return { scriptUrl, saCreds };
}

interface ServiceAccountCredentials {
  client_email: string;
  private_key: string;
  token_uri?: string;
}

let cachedSaToken: { token: string; expiresAt: number } | null = null;

function parseServiceAccountCredentials(): ServiceAccountCredentials | null {
  const raw = (process.env.GOOGLE_SERVICE_ACCOUNT_JSON || '').trim();
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as ServiceAccountCredentials;
    if (parsed.client_email && parsed.private_key) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

function base64UrlEncode(input: Buffer | string): string {
  return Buffer.from(input)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

async function getServiceAccountAccessToken(
  creds: ServiceAccountCredentials
): Promise<string> {
  const nowSec = Math.floor(Date.now() / 1000);
  if (cachedSaToken && cachedSaToken.expiresAt > nowSec + 60) {
    return cachedSaToken.token;
  }

  const tokenUri = creds.token_uri || 'https://oauth2.googleapis.com/token';
  const header = base64UrlEncode(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = base64UrlEncode(
    JSON.stringify({
      iss: creds.client_email,
      scope: 'https://www.googleapis.com/auth/drive',
      aud: tokenUri,
      iat: nowSec,
      exp: nowSec + 3600,
    })
  );

  const signingInput = `${header}.${claim}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(signingInput);
  signer.end();
  const signature = base64UrlEncode(signer.sign(creds.private_key));
  const assertion = `${signingInput}.${signature}`;

  const tokenRes = await fetch(tokenUri, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion,
    }),
  });

  if (!tokenRes.ok) {
    const errText = await tokenRes.text();
    throw new Error(`Service account token request failed: ${tokenRes.status} ${errText}`);
  }

  const tokenData = (await tokenRes.json()) as {
    access_token?: string;
    expires_in?: number;
  };
  if (!tokenData.access_token) {
    throw new Error('Service account access_token missing in OAuth response');
  }

  cachedSaToken = {
    token: tokenData.access_token,
    expiresAt: nowSec + Number(tokenData.expires_in || 3600),
  };
  return cachedSaToken.token;
}

async function resolveServiceAccountFileId(accessToken: string): Promise<string | null> {
  const directFileId = (process.env.GOOGLE_DRIVE_FILE_ID || '').trim();
  if (directFileId) return directFileId;

  const folderId = (process.env.GOOGLE_DRIVE_FOLDER_ID || '').trim();
  if (!folderId) return null;

  const q = `trashed = false and '${folderId}' in parents and name = '${DRIVE_DB_FILENAME}'`;
  const url = new URL('https://www.googleapis.com/drive/v3/files');
  url.searchParams.set('q', q);
  url.searchParams.set('fields', 'files(id,name)');
  url.searchParams.set('pageSize', '5');
  url.searchParams.set('supportsAllDrives', 'true');
  url.searchParams.set('includeItemsFromAllDrives', 'true');

  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Drive search failed: ${res.status} ${text}`);
  }
  const data = (await res.json()) as { files?: Array<{ id: string }> };
  return data.files?.[0]?.id || null;
}

async function loadFromAppsScript(scriptUrl: string) {
  const url = new URL(scriptUrl);
  url.searchParams.set('action', 'load');
  const bridgeSecret = (process.env.GOOGLE_DRIVE_BRIDGE_SECRET || '').trim();
  if (bridgeSecret) {
    url.searchParams.set('secret', bridgeSecret);
  }

  const res = await fetch(url.toString(), {
    method: 'GET',
    redirect: 'follow',
  });
  if (!res.ok) {
    throw new Error(`Apps Script load failed: HTTP ${res.status}`);
  }
  const text = await res.text();
  let raw: Record<string, unknown> | null = null;
  try {
    raw = text ? (JSON.parse(text) as Record<string, unknown>) : null;
  } catch {
    throw new Error(`Apps Script load returned non-JSON response: ${text.slice(0, 160)}`);
  }
  if (raw && typeof raw === 'object' && raw.ok === false) {
    throw new Error(String(raw.error || 'Apps Script rejected load request'));
  }
  if (raw && typeof raw === 'object' && 'payload' in raw) {
    return raw.payload || null;
  }
  if (raw && typeof raw === 'object' && 'keys' in raw) {
    return raw;
  }
  return null;
}

async function saveToAppsScript(scriptUrl: string, payload: unknown) {
  const bridgeSecret = (process.env.GOOGLE_DRIVE_BRIDGE_SECRET || '').trim();
  const res = await fetch(scriptUrl, {
    method: 'POST',
    redirect: 'follow',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'save',
      secret: bridgeSecret || undefined,
      payload,
    }),
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Apps Script save failed: HTTP ${res.status} ${txt}`);
  }
  const text = await res.text();
  let raw: Record<string, unknown> | null = null;
  try {
    raw = text ? (JSON.parse(text) as Record<string, unknown>) : { ok: true };
  } catch {
    throw new Error(`Apps Script save returned non-JSON response: ${text.slice(0, 160)}`);
  }
  if (raw && typeof raw === 'object' && raw.ok === false) {
    throw new Error(String(raw.error || 'Apps Script rejected save request'));
  }
  return raw || { ok: true };
}

async function loadFromServiceAccount(creds: ServiceAccountCredentials) {
  const accessToken = await getServiceAccountAccessToken(creds);
  const fileId = await resolveServiceAccountFileId(accessToken);
  if (!fileId) return null;

  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}?alt=media&supportsAllDrives=true`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (res.status === 404) return null;
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Drive file read failed: ${res.status} ${txt}`);
  }
  const text = await res.text();
  if (!text.trim()) return null;
  return JSON.parse(text);
}

async function saveToServiceAccount(
  creds: ServiceAccountCredentials,
  payload: unknown
) {
  const accessToken = await getServiceAccountAccessToken(creds);
  const fileId = await resolveServiceAccountFileId(accessToken);
  const folderId = (process.env.GOOGLE_DRIVE_FOLDER_ID || '').trim();

  const metadata: Record<string, unknown> = {
    name: DRIVE_DB_FILENAME,
    mimeType: 'application/json',
  };
  if (!fileId && folderId) {
    metadata.parents = [folderId];
  }

  const form = new FormData();
  form.append(
    'metadata',
    new Blob([JSON.stringify(metadata)], { type: 'application/json' })
  );
  form.append(
    'file',
    new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
  );

  const endpoint = fileId
    ? `https://www.googleapis.com/upload/drive/v3/files/${encodeURIComponent(fileId)}?uploadType=multipart&supportsAllDrives=true`
    : `https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true`;

  const res = await fetch(endpoint, {
    method: fileId ? 'PATCH' : 'POST',
    headers: { Authorization: `Bearer ${accessToken}` },
    body: form,
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Drive file save failed: ${res.status} ${txt}`);
  }
  return res.json();
}

export interface NexsdaServerOptions {
  port?: number;
  host?: string;
  staticDir?: string;
  isProduction?: boolean;
  allowFallbackPort?: boolean;
  envPaths?: string[];
}

export interface StartedNexsdaServer {
  app: express.Express;
  server: http.Server;
  port: number;
  host: string;
  url: string;
}

export async function createNexsdaApp(
  options: Pick<NexsdaServerOptions, 'staticDir' | 'isProduction' | 'envPaths'> = {}
): Promise<express.Express> {
  if (Array.isArray(options.envPaths)) {
    for (const envFile of options.envPaths) {
      if (envFile && fs.existsSync(envFile)) {
        dotenv.config({ path: envFile, override: false });
      }
    }
  }

  const app = express();
  app.use(express.json({ limit: '25mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, app: 'NEXSDA ONE' });
  });

  app.post('/api/geotag-read', async (req, res) => {
    const apiKey = (process.env.GEMINI_API_KEY || '').trim();
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(503).json({
        ok: false,
        configured: false,
        error: 'Layanan pembacaan geotag AI belum dikonfigurasi pada server ini.',
      });
      return;
    }

    const rawBase64 = typeof req.body?.imageBase64 === 'string' ? req.body.imageBase64.trim() : '';
    const mimeType =
      typeof req.body?.mimeType === 'string' && /^image\/[a-zA-Z0-9.+-]+$/.test(req.body.mimeType)
        ? req.body.mimeType
        : 'image/jpeg';
    const fileName = typeof req.body?.fileName === 'string' ? req.body.fileName.slice(0, 180) : '';

    if (!rawBase64 || rawBase64.length > 16 * 1024 * 1024) {
      res.status(400).json({ ok: false, configured: true, error: 'Berkas gambar tidak valid atau terlalu besar.' });
      return;
    }

    const cleanBase64 = rawBase64.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, '');

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const promptText = [
        'Anda adalah pembaca watermark/stamp foto GPS & Timestamp universal untuk sistem BKSDA Jakarta (NEXSDA ONE).',
        'Baca HANYA overlay teks timestamp/geotag dari aplikasi kamera apa pun (Timestamp Camera, GPS Map Camera, Timemark, OpenCamera, TimePhoto, NoteCam, GeoCam, Solocator, atau template kustom — baik teks putih, teks berwarna/neon bergaris tepi, di sudut kanan bawah, kiri bawah, atas, maupun kartu peta).',
        'ABAIKAN teks latar belakang foto (papan tulis, spanduk, seragam, plang, atau kalender ruangan).',
        'Aturan konversi koordinat WAJIB:',
        '- Ubah semua format koordinat ke derajat desimal bertanda (signed decimal degrees).',
        '- Format koma Indonesia seperti "6,30806S 106,90555E" atau "6,1931S 106,8755E" -> latitude: -6.30806, longitude: 106.90555 (atau -6.1931, 106.8755).',
        '- Lintang Selatan (S / LS) HARUS bernilai negatif; Lintang Utara (N / LU) positif; Bujur Timur (E / BT) positif; Bujur Barat (W / BB) negatif.',
        '- Format DMS (6°18\'29"S 106°54\'20"E) atau DM (6°18.48\'S 106°54.33\'E) konversi ke desimal akurat.',
        '- ABAIKAN sudut arah kompas seperti "73° E", "240° SW", atau ketinggian "25m" — itu BUKAN koordinat GPS.',
        'Aturan tanggal & alamat:',
        '- Format tanggal dalam Bahasa Indonesia lengkap, contoh: "26 Februari 2026", "13 November 2026", "9 September 2026", "16 Maret 2026" (jika 16/03/26 berarti 16 Maret 2026).',
        '- Gabungkan baris alamat pada watermark menjadi satu string alamat rapi dipisahkan koma (tanpa mengulang tanggal/koordinat/arah kompas).',
        '- Tentukan resor jika wilayahnya termasuk salah satu dari 4 resor: "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", atau "Bekasi" (kosongkan "" jika tidak jelas atau di luar 4 wilayah tersebut).',
        fileName ? `Nama berkas foto (hanya referensi tambahan jika tanggal tidak ada di watermark): ${fileName}` : '',
      ]
        .filter(Boolean)
        .join('\n');

      const candidateModels = ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
      let response: Awaited<ReturnType<typeof ai.models.generateContent>> | null = null;
      let lastErr: unknown = null;

      for (let i = 0; i < candidateModels.length; i++) {
        const modelName = candidateModels[i];
        const isLast = i === candidateModels.length - 1;
        const perModelTimeoutMs = isLast ? 20000 : 10000;
        const attemptController = new AbortController();
        const attemptTimer = setTimeout(() => attemptController.abort(), perModelTimeoutMs);

        try {
          response = await ai.models.generateContent({
            model: modelName,
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType,
                    data: cleanBase64,
                  },
                },
                { text: promptText },
              ],
            },
            config: {
              abortSignal: attemptController.signal,
              thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  found: {
                    type: Type.BOOLEAN,
                    description: 'True jika ditemukan watermark timestamp/geotag berisi koordinat, tanggal, atau alamat.',
                  },
                  latitude: {
                    type: Type.NUMBER,
                    nullable: true,
                    description: 'Latitude desimal bertanda (S/LS negatif). Null jika tidak ditemukan.',
                  },
                  longitude: {
                    type: Type.NUMBER,
                    nullable: true,
                    description: 'Longitude desimal bertanda (E/BT positif, W/BB negatif). Null jika tidak ditemukan.',
                  },
                  tanggal: {
                    type: Type.STRING,
                    description: 'Tanggal dalam format Indonesia misal "26 Februari 2026", atau string kosong.',
                  },
                  waktu: {
                    type: Type.STRING,
                    description: 'Waktu misal "14:16:12" atau "15:27", atau string kosong.',
                  },
                  alamat: {
                    type: Type.STRING,
                    description: 'Alamat lengkap hasil pembacaan watermark dipisahkan koma, atau string kosong.',
                  },
                  resor: {
                    type: Type.STRING,
                    description: 'Salah satu dari "Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Bekasi", atau "".',
                  },
                  appTemplate: {
                    type: Type.STRING,
                    description: 'Nama/gaya template aplikasi timestamp yang terdeteksi.',
                  },
                },
                required: ['found', 'tanggal', 'waktu', 'alamat', 'resor', 'appTemplate'],
              },
            },
          });
          clearTimeout(attemptTimer);
          break;
        } catch (modelErr) {
          clearTimeout(attemptTimer);
          lastErr = modelErr;
          const msg = modelErr instanceof Error ? modelErr.message : String(modelErr);
          const isTransient =
            attemptController.signal.aborted ||
            /503|429|UNAVAILABLE|RESOURCE_EXHAUSTED|high demand|overloaded|abort|timeout/i.test(msg);
          if (!isTransient || isLast) throw modelErr;
        }
      }

      if (!response) {
        throw lastErr instanceof Error ? lastErr : new Error('Layanan pembacaan geotag sedang sibuk.');
      }

      const parsed = JSON.parse((response.text || '{}').trim()) as {
        found?: boolean;
        latitude?: number | null;
        longitude?: number | null;
        tanggal?: string;
        waktu?: string;
        alamat?: string;
        resor?: string;
        appTemplate?: string;
      };

      let lat = typeof parsed.latitude === 'number' && Number.isFinite(parsed.latitude) ? parsed.latitude : null;
      let lng = typeof parsed.longitude === 'number' && Number.isFinite(parsed.longitude) ? parsed.longitude : null;

      if (lat !== null && (lat < -90 || lat > 90)) lat = null;
      if (lng !== null && (lng < -180 || lng > 180)) lng = null;

      const allowedResors = new Set(['Jakarta Pusat', 'Jakarta Selatan', 'Jakarta Timur', 'Bekasi']);
      const resor = typeof parsed.resor === 'string' && allowedResors.has(parsed.resor.trim())
        ? parsed.resor.trim()
        : '';

      // Pengaman tanda lintang selatan untuk wilayah Jabodetabek jika terbalik positif
      if (lat !== null && lng !== null && lat > 5 && lat < 7.5 && lng > 106 && lng < 108) {
        lat = -lat;
      }

      res.json({
        ok: true,
        configured: true,
        found: Boolean(parsed.found || lat !== null || (parsed.alamat && parsed.alamat.trim())),
        lat,
        lng,
        tanggal: typeof parsed.tanggal === 'string' ? parsed.tanggal.trim() : '',
        waktu: typeof parsed.waktu === 'string' ? parsed.waktu.trim() : '',
        alamat: typeof parsed.alamat === 'string' ? parsed.alamat.trim() : '',
        resor,
        appTemplate: typeof parsed.appTemplate === 'string' ? parsed.appTemplate.trim() : 'Watermark Geotag',
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Gagal membaca foto geotag.';
      console.error('[POST /api/geotag-read]', message);
      res.status(502).json({
        ok: false,
        configured: true,
        error: message,
      });
    }
  });

  app.get('/api/connectivity', async (_req, res) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
    const probeUrls = [
      'https://www.gstatic.com/generate_204',
      'https://clients3.google.com/generate_204',
    ];
    for (const url of probeUrls) {
      try {
        const probeRes = await fetch(url, {
          method: 'HEAD',
          signal: AbortSignal.timeout(2500),
        });
        if (probeRes.ok || probeRes.status === 204) {
          res.json({ online: true });
          return;
        }
      } catch {
        // Coba endpoint cadangan berikutnya
      }
    }
    res.json({ online: false });
  });

  app.get('/api/auth/status', (req, res) => {
    const token = extractEditToken(req);
    res.json({ unlocked: verifyEditSessionToken(token) });
  });

  app.post('/api/auth/unlock', (req, res) => {
    const submitted = typeof req.body?.code === 'string' ? req.body.code.trim() : '';
    if (!submitted || !safeCompareText(submitted, getEditAccessCode())) {
      res.status(401).json({
        ok: false,
        error: 'Kode edit salah. Akses tetap dalam mode baca data saja.',
      });
      return;
    }
    const token = createEditSessionToken();
    res.json({ ok: true, token });
  });

  app.get('/api/drive-db', async (_req, res) => {
    const { scriptUrl, saCreds } = resolveDriveBackend();

    if (!scriptUrl && !saCreds) {
      res.json({
        configured: false,
        targetDriveEmail: 'nexsdaone@gmail.com',
        payload: null,
      });
      return;
    }

    try {
      const payload = scriptUrl
        ? await loadFromAppsScript(scriptUrl)
        : await loadFromServiceAccount(saCreds!);

      res.json({
        configured: true,
        targetDriveEmail: 'nexsdaone@gmail.com',
        payload: payload || null,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Drive load error';
      console.error('[GET /api/drive-db]', message);
      res.status(502).json({
        configured: true,
        error: message,
        payload: null,
      });
    }
  });

  app.post('/api/drive-db', async (req, res) => {
    if (!verifyEditSessionToken(extractEditToken(req))) {
      res.status(401).json({
        configured: true,
        saved: false,
        error: 'Mode Baca Saja: Login edit diperlukan untuk menyimpan perubahan.',
      });
      return;
    }

    const { scriptUrl, saCreds } = resolveDriveBackend();

    if (!scriptUrl && !saCreds) {
      res.json({
        configured: false,
        saved: false,
      });
      return;
    }

    const payload = req.body;
    if (!payload || typeof payload !== 'object' || !payload.keys) {
      res.status(400).json({ error: 'Invalid backup payload' });
      return;
    }

    try {
      if (scriptUrl) {
        await saveToAppsScript(scriptUrl, payload);
      } else {
        await saveToServiceAccount(saCreds!, payload);
      }
      res.json({
        configured: true,
        saved: true,
        targetDriveEmail: 'nexsdaone@gmail.com',
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Drive save error';
      console.error('[POST /api/drive-db]', message);
      res.status(502).json({
        configured: true,
        saved: false,
        error: message,
      });
    }
  });

  const isProd =
    typeof options.isProduction === 'boolean'
      ? options.isProduction
      : process.env.NODE_ENV === 'production' || process.env.NEXSDA_DESKTOP_EMBEDDED === '1';

  const resolvedStaticDir = options.staticDir || path.join(CURRENT_DIR, 'dist');

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(resolvedStaticDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(resolvedStaticDir, 'index.html'));
    });
  }

  return app;
}

function listenOnPort(
  app: express.Express,
  port: number,
  host: string
): Promise<{ server: http.Server; port: number }> {
  return new Promise((resolve, reject) => {
    const server = http.createServer(app);
    const onError = (err: NodeJS.ErrnoException) => {
      server.removeListener('listening', onListening);
      reject(err);
    };
    const onListening = () => {
      server.removeListener('error', onError);
      const addr = server.address();
      const actualPort = typeof addr === 'object' && addr ? addr.port : port;
      resolve({ server, port: actualPort });
    };
    server.once('error', onError);
    server.once('listening', onListening);
    server.listen(port, host);
  });
}

export async function startNexsdaServer(
  options: NexsdaServerOptions = {}
): Promise<StartedNexsdaServer> {
  const app = await createNexsdaApp(options);
  const host = options.host || '0.0.0.0';
  const requestedPort = typeof options.port === 'number' ? options.port : PORT;

  let started: { server: http.Server; port: number };
  try {
    started = await listenOnPort(app, requestedPort, host);
  } catch (err) {
    const code = (err as NodeJS.ErrnoException | undefined)?.code;
    if (options.allowFallbackPort && code === 'EADDRINUSE' && requestedPort !== 0) {
      started = await listenOnPort(app, 0, host);
    } else {
      throw err;
    }
  }

  const displayHost = host === '0.0.0.0' ? 'localhost' : host;
  const url = `http://${displayHost}:${started.port}`;
  console.log(`NEXSDA ONE server running on http://${host}:${started.port}`);
  return {
    app,
    server: started.server,
    port: started.port,
    host,
    url,
  };
}

if (process.env.NEXSDA_DESKTOP_EMBEDDED !== '1') {
  startNexsdaServer().catch((err) => {
    console.error('Failed to start NEXSDA ONE server:', err);
    process.exit(1);
  });
}
