import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const androidDir = path.join(rootDir, 'android');
const releaseDir = path.join(rootDir, 'release');
const capConfigPath = path.join(rootDir, 'capacitor.config.json');

const isWin = process.platform === 'win32';
const npmCmd = isWin ? 'npm.cmd' : 'npm';
const npxCmd = isWin ? 'npx.cmd' : 'npx';

const pkg = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8'));
const appVersion = pkg.version || '1.0.0';
const appId = 'id.go.menlhk.bksdajakarta.nexsdaone';

const args = process.argv.slice(2);
const isRelease = args.includes('--release');
const syncOnly = args.includes('--sync-only');
const openStudio = args.includes('--open');
const serverArg = args.find((a) => a.startsWith('--server=') || a.startsWith('--url='));

function loadDotEnvValue(key) {
  if (process.env[key] && String(process.env[key]).trim()) {
    return String(process.env[key]).trim();
  }
  const envPath = path.join(rootDir, '.env');
  if (!fs.existsSync(envPath)) return '';
  const content = fs.readFileSync(envPath, 'utf8');
  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const k = trimmed.slice(0, eq).trim();
    if (k === key) {
      return trimmed
        .slice(eq + 1)
        .trim()
        .replace(/^["']|["']$/g, '');
    }
  }
  return '';
}

const customServerUrl = serverArg
  ? serverArg.split('=').slice(1).join('=').trim()
  : loadDotEnvValue('NEXSDA_ANDROID_SERVER_URL');

function runStep(cmd, cmdArgs, label, options = {}) {
  const cwd = options.cwd || rootDir;
  const useShell = options.useShell ?? isWin;
  console.log(`\n==> ${label}...`);
  const result = spawnSync(cmd, cmdArgs, {
    cwd,
    stdio: 'inherit',
    shell: useShell,
    env: options.env || process.env,
  });
  if (result.error) {
    console.error(result.error);
    process.exit(1);
  }
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

function hasPackage(pkgName) {
  return fs.existsSync(path.join(rootDir, 'node_modules', ...pkgName.split('/'), 'package.json'));
}

function detectAndroidSdkDir() {
  const candidates = [
    process.env.ANDROID_HOME,
    process.env.ANDROID_SDK_ROOT,
    isWin && process.env.LOCALAPPDATA
      ? path.join(process.env.LOCALAPPDATA, 'Android', 'Sdk')
      : '',
    path.join(os.homedir(), 'Android', 'Sdk'),
    path.join(os.homedir(), 'Library', 'Android', 'sdk'),
  ].filter(Boolean);

  for (const dir of candidates) {
    if (fs.existsSync(dir)) return dir;
  }
  return '';
}

function patchAndroidManifest() {
  const manifestPath = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
  if (!fs.existsSync(manifestPath)) return;

  let xml = fs.readFileSync(manifestPath, 'utf8');

  const permissions = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.ACCESS_FINE_LOCATION',
    'android.permission.ACCESS_COARSE_LOCATION',
    'android.permission.CAMERA',
    'android.permission.READ_MEDIA_IMAGES',
  ];

  for (const perm of permissions) {
    if (!xml.includes(perm)) {
      xml = xml.replace(
        '</manifest>',
        `    <uses-permission android:name="${perm}" />\n</manifest>`
      );
    }
  }

  if (!xml.includes('android.permission.WRITE_EXTERNAL_STORAGE')) {
    xml = xml.replace(
      '</manifest>',
      `    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />\n</manifest>`
    );
  }

  if (!xml.includes('android:usesCleartextTraffic')) {
    xml = xml.replace('<application', '<application android:usesCleartextTraffic="true"');
  }

  fs.writeFileSync(manifestPath, xml, 'utf8');
  console.log('   [OK] AndroidManifest.xml diperbarui (GPS, Kamera, Internet, Unduh Berkas).');
}

function patchMainActivity() {
  const javaDir = path.join(
    androidDir,
    'app',
    'src',
    'main',
    'java',
    ...appId.split('.')
  );
  const mainActivityPath = path.join(javaDir, 'MainActivity.java');
  fs.mkdirSync(javaDir, { recursive: true });

  const javaSource = `package ${appId};

import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.widget.Toast;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebChromeClient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
        if (this.bridge == null || this.bridge.getWebView() == null) {
            return;
        }
        final WebView webView = this.bridge.getWebView();
        webView.getSettings().setGeolocationEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AndroidDownloadBridge(), "AndroidFileDownloader");

        webView.setWebChromeClient(new BridgeWebChromeClient(this.bridge) {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                final String guessedName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                final String safeMime = (mimeType != null && !mimeType.isEmpty()) ? mimeType : "application/octet-stream";

                if (url != null && url.startsWith("data:")) {
                    saveBase64ToDownloads(url, guessedName, safeMime);
                    return;
                }

                if (url != null && url.startsWith("blob:")) {
                    String js = "(function(){"
                        + "var u=" + org.json.JSONObject.quote(url) + ";"
                        + "var defName=" + org.json.JSONObject.quote(guessedName) + ";"
                        + "var defMime=" + org.json.JSONObject.quote(safeMime) + ";"
                        + "var a=document.querySelector('a[href=\"'+u+'\"]');"
                        + "var fname=(a&&a.getAttribute('download'))||window.__nexsdaLastDownloadName||defName;"
                        + "fetch(u).then(function(r){return r.blob();}).then(function(b){"
                        + "  var fr=new FileReader();"
                        + "  fr.onloadend=function(){"
                        + "    if(window.AndroidFileDownloader){"
                        + "      window.AndroidFileDownloader.saveBase64File(fr.result, fname, b.type||defMime);"
                        + "    }"
                        + "  };"
                        + "  fr.readAsDataURL(b);"
                        + "}).catch(function(){});"
                        + "})();";
                    webView.evaluateJavascript(js, null);
                }
            }
        });
    }

    private void saveBase64ToDownloads(String dataUrl, String rawFileName, String mimeType) {
        try {
            if (dataUrl == null || !dataUrl.contains(",")) return;
            String base64Part = dataUrl.substring(dataUrl.indexOf(",") + 1);
            byte[] fileBytes = Base64.decode(base64Part, Base64.DEFAULT);

            String safeName = (rawFileName == null || rawFileName.trim().isEmpty())
                ? ("NEXSDA_ONE_" + System.currentTimeMillis() + ".bin")
                : rawFileName.replaceAll("[\\\\\\\\/:*?\\"<>|]", "_");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out != null) out.write(fileBytes);
                    }
                }
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                File outFile = new File(dir, safeName);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(fileBytes);
                }
            }

            runOnUiThread(() ->
                Toast.makeText(MainActivity.this, "Tersimpan di Download: " + safeName, Toast.LENGTH_LONG).show()
            );
        } catch (Exception e) {
            runOnUiThread(() ->
                Toast.makeText(MainActivity.this, "Gagal menyimpan berkas: " + e.getMessage(), Toast.LENGTH_LONG).show()
            );
        }
    }

    private class AndroidDownloadBridge {
        @JavascriptInterface
        public void saveBase64File(String dataUrl, String fileName, String mimeType) {
            saveBase64ToDownloads(dataUrl, fileName, mimeType);
        }
    }
}
`;

  fs.writeFileSync(mainActivityPath, javaSource, 'utf8');
  console.log('   [OK] MainActivity.java dikonfigurasi (GPS, Kamera, Unduh DOCX/XLSX/PDF).');
}

function applyAppIcon() {
  const iconSrc = path.join(rootDir, 'electron', 'icon.png');
  if (!fs.existsSync(iconSrc)) return;

  const resDir = path.join(androidDir, 'app', 'src', 'main', 'res');
  const mipmaps = [
    'mipmap-mdpi',
    'mipmap-hdpi',
    'mipmap-xhdpi',
    'mipmap-xxhdpi',
    'mipmap-xxxhdpi',
  ];

  for (const folder of mipmaps) {
    const dir = path.join(resDir, folder);
    if (!fs.existsSync(dir)) continue;
    for (const target of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png']) {
      fs.copyFileSync(iconSrc, path.join(dir, target));
    }
  }

  // Hapus adaptive XML default agar ikon PNG NEXSDA ONE tampil penuh tanpa terpotong
  const anydpiDir = path.join(resDir, 'mipmap-anydpi-v26');
  if (fs.existsSync(anydpiDir)) {
    for (const xmlFile of ['ic_launcher.xml', 'ic_launcher_round.xml']) {
      const p = path.join(anydpiDir, xmlFile);
      if (fs.existsSync(p)) fs.unlinkSync(p);
    }
  }
  console.log('   [OK] Ikon aplikasi NEXSDA ONE diterapkan ke seluruh resolusi Android.');
}

function pruneUnusedAndroidAssets() {
  const assetsDir = path.join(
    androidDir,
    'app',
    'src',
    'main',
    'assets',
    'public',
    'assets',
    'aistudio'
  );
  if (!fs.existsSync(assetsDir)) return;

  const entries = fs.readdirSync(assetsDir);
  for (const name of entries) {
    if (
      name.startsWith('Paste_') ||
      name.startsWith('SK_01_Penataan_ASN_2026_') ||
      name === 'image_0cf7ae45.png'
    ) {
      fs.rmSync(path.join(assetsDir, name), { force: true, recursive: true });
    }
  }
}

function patchVersionInfo() {
  const buildGradlePath = path.join(androidDir, 'app', 'build.gradle');
  if (!fs.existsSync(buildGradlePath)) return;
  let gradle = fs.readFileSync(buildGradlePath, 'utf8');
  gradle = gradle.replace(/versionName\s+"[^"]*"/, `versionName "${appVersion}"`);
  fs.writeFileSync(buildGradlePath, gradle, 'utf8');
}

// 1. Build frontend Vite ke dist/
runStep(npmCmd, ['run', 'build'], 'Membangun antarmuka web (dist/)', { useShell: isWin });

// 2. Pastikan paket Capacitor terpasang secara lokal
if (
  !hasPackage('@capacitor/core') ||
  !hasPackage('@capacitor/cli') ||
  !hasPackage('@capacitor/android')
) {
  runStep(
    npmCmd,
    [
      'install',
      '--no-save',
      '--legacy-peer-deps',
      '--no-audit',
      '--no-fund',
      '@capacitor/core',
      '@capacitor/cli',
      '@capacitor/android',
    ],
    'Memasang Capacitor Android untuk kompilasi .apk',
    { useShell: isWin }
  );
}

// 3. Jika user menentukan URL server online (--server=https://... atau NEXSDA_ANDROID_SERVER_URL),
//    suntikkan sementara ke capacitor.config.json saat sync, lalu kembalikan lagi setelahnya.
const originalCapConfigText = fs.readFileSync(capConfigPath, 'utf8');
if (customServerUrl) {
  console.log(`\n[INFO] Mode APK Online Server aktif: ${customServerUrl}`);
  const parsed = JSON.parse(originalCapConfigText);
  parsed.server = {
    ...(parsed.server || {}),
    url: customServerUrl,
    cleartext: customServerUrl.startsWith('http://'),
  };
  fs.writeFileSync(capConfigPath, JSON.stringify(parsed, null, 2) + '\n', 'utf8');
}

try {
  // 4. Buat folder android/ jika belum ada
  if (!fs.existsSync(androidDir)) {
    runStep(npxCmd, ['cap', 'add', 'android'], 'Membuat proyek Android (android/)');
  }

  // 5. Sinkronisasi aset web & konfigurasi ke proyek Android
  runStep(npxCmd, ['cap', 'sync', 'android'], 'Menyinkronkan aset NEXSDA ONE ke Android');
} finally {
  if (customServerUrl) {
    fs.writeFileSync(capConfigPath, originalCapConfigText, 'utf8');
  }
}

// 6. Konfigurasi Manifest, MainActivity (GPS/Kamera/Unduh), Ikon, dan Versi
console.log('\n==> Menerapkan konfigurasi native Android NEXSDA ONE...');
patchAndroidManifest();
patchMainActivity();
applyAppIcon();
pruneUnusedAndroidAssets();
patchVersionInfo();

if (openStudio) {
  runStep(npxCmd, ['cap', 'open', 'android'], 'Membuka proyek Android di Android Studio');
  process.exit(0);
}

if (syncOnly) {
  console.log('\n[OK] Sinkronisasi proyek Android selesai (folder: android/).');
  process.exit(0);
}

// 7. Pastikan Java & Android SDK tersedia sebelum menjalankan Gradle
const javaCheck = spawnSync('java', ['-version'], { stdio: 'ignore', shell: isWin });
if (javaCheck.error || javaCheck.status !== 0) {
  console.error('\n[ERROR] Java JDK (17 atau 21) belum terpasang atau belum ada di PATH.');
  console.error('Silakan pasang JDK 17/21 atau Android Studio, lalu jalankan kembali npm run build:apk.');
  console.error('Lihat panduan lengkap di berkas PANDUAN_BUILD_APK.md.\n');
  process.exit(1);
}

const sdkDir = detectAndroidSdkDir();
if (!sdkDir) {
  console.error('\n[ERROR] Android SDK tidak ditemukan.');
  console.error('Pasang Android Studio (atau Android Command-line Tools) dan set variabel ANDROID_HOME.');
  console.error('Atau jalankan: npm run android:open untuk build langsung lewat Android Studio.');
  console.error('Alternatif tanpa instalasi di laptop: gunakan GitHub Actions (.github/workflows/build-apk.yml).\n');
  process.exit(1);
}

const localPropsPath = path.join(androidDir, 'local.properties');
const escapedSdkDir = sdkDir.replace(/\\/g, '\\\\');
fs.writeFileSync(localPropsPath, `sdk.dir=${escapedSdkDir}\n`, 'utf8');
console.log(`   [OK] Android SDK terdeteksi: ${sdkDir}`);

// 8. Kompilasi APK menggunakan Gradle Wrapper
const gradlew = isWin ? 'gradlew.bat' : './gradlew';
const gradleTask = isRelease ? 'assembleRelease' : 'assembleDebug';
const gradleEnv = {
  ...process.env,
  ANDROID_HOME: sdkDir,
  ANDROID_SDK_ROOT: sdkDir,
};

if (!isWin) {
  try {
    fs.chmodSync(path.join(androidDir, 'gradlew'), 0o755);
  } catch {
    // Abaikan jika sudah executable
  }
}

runStep(gradlew, [gradleTask], `Mengompilasi Android APK (${gradleTask})`, {
  cwd: androidDir,
  useShell: isWin,
  env: gradleEnv,
});

// 9. Salin hasil APK ke folder release/ (sejajar dengan hasil .exe)
const apkSourceDir = path.join(
  androidDir,
  'app',
  'build',
  'outputs',
  'apk',
  isRelease ? 'release' : 'debug'
);
const apkCandidate = fs.existsSync(apkSourceDir)
  ? fs.readdirSync(apkSourceDir).find((f) => f.endsWith('.apk'))
  : null;

if (!apkCandidate) {
  console.error(`\n[ERROR] File .apk tidak ditemukan di ${apkSourceDir}`);
  process.exit(1);
}

fs.mkdirSync(releaseDir, { recursive: true });
const outFileName = isRelease
  ? `NEXSDA-ONE-${appVersion}-release-unsigned.apk`
  : `NEXSDA-ONE-${appVersion}.apk`;
const outPath = path.join(releaseDir, outFileName);
fs.copyFileSync(path.join(apkSourceDir, apkCandidate), outPath);

console.log('\n======================================================');
console.log(`SELESAI! Berkas Android APK NEXSDA ONE tersedia di:`);
console.log(`  release/${outFileName}`);
console.log('======================================================\n');
