import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const isWin = process.platform === 'win32';
const npmCmd = isWin ? 'npm.cmd' : 'npm';
const npxCmd = isWin ? 'npx.cmd' : 'npx';

function runStep(cmd, args, label, useShell = isWin) {
  console.log(`\n==> ${label}...`);
  const result = spawnSync(cmd, args, {
    cwd: rootDir,
    stdio: 'inherit',
    shell: useShell,
  });
  if (result.error) {
    console.error(result.error);
    process.exit(1);
  }
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

function hasPackage(pkgName) {
  return fs.existsSync(path.join(rootDir, 'node_modules', pkgName, 'package.json'));
}

const args = process.argv.slice(2);
const portableOnly = args.includes('--portable');
const installerOnly = args.includes('--installer');

// 1. Build frontend Vite ke dist/
runStep(npmCmd, ['run', 'build'], 'Membangun antarmuka web (dist/)', isWin);

// 2. Bundle backend Express ke dist-electron/server.cjs (shell: false agar aman untuk "Program Files")
runStep(
  process.execPath,
  [path.join(rootDir, 'scripts', 'bundle-desktop-server.mjs')],
  'Membundle server lokal desktop',
  false
);

// 3. Pastikan electron & electron-builder terpasang di laptop lokal
if (!hasPackage('electron') || !hasPackage('electron-builder')) {
  runStep(
    npmCmd,
    ['install', '--no-save', '--legacy-peer-deps', '--no-audit', '--no-fund', 'electron', 'electron-builder'],
    'Memasang Electron & Electron Builder untuk kompilasi .exe',
    isWin
  );
}

// 4. Jalankan electron-builder untuk Windows .exe
const builderArgs = ['electron-builder', '--win'];
if (portableOnly) {
  builderArgs.push('portable');
} else if (installerOnly) {
  builderArgs.push('nsis');
}
builderArgs.push('--x64', '--config', 'electron-builder.json');

runStep(npxCmd, builderArgs, 'Membuat berkas Windows .exe (folder release/)');

console.log('\n======================================================');
console.log('SELESAI! Berkas .exe NEXSDA ONE tersedia di folder: release/');
console.log('======================================================\n');
