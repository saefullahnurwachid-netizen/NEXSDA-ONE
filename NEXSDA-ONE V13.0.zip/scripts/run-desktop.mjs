import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const isWin = process.platform === 'win32';
const npmCmd = isWin ? 'npm.cmd' : 'npm';
const npxCmd = isWin ? 'npx.cmd' : 'npx';

function runStep(cmd, args, label, useShell = isWin) {
  console.log(`\n==> ${label}...`);
  const result = spawnSync(cmd, args, {
    cwd: rootDir,
    stdio: 'inherit',
    shell: useShell,
  });
  if (result.error) {
    console.error(result.error);
    process.exit(1);
  }
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

runStep(npmCmd, ['run', 'build'], 'Membangun antarmuka web (dist/)', isWin);
runStep(
  process.execPath,
  [path.join(rootDir, 'scripts', 'bundle-desktop-server.mjs')],
  'Membundle server lokal desktop',
  false
);

if (!fs.existsSync(path.join(rootDir, 'node_modules', 'electron', 'package.json'))) {
  runStep(
    npmCmd,
    ['install', '--no-save', '--legacy-peer-deps', '--no-audit', '--no-fund', 'electron'],
    'Memasang Electron untuk pratinjau desktop',
    isWin
  );
}

runStep(npxCmd, ['electron', '.'], 'Menjalankan NEXSDA ONE Desktop', isWin);
