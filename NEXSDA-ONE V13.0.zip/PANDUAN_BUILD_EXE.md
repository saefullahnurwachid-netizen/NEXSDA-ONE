# Panduan Membuat File `.exe` NEXSDA ONE di Laptop Windows

Proyek ini sudah dikonfigurasi dengan **Electron + Server Lokal Terintegrasi**, sehingga saat dijalankan sebagai `.exe` di laptop:
- Data tetap otomatis dimuat dan disimpan ke Google Drive **`nexsdaone@gmail.com`** (selama laptop terhubung internet).
- Proteksi **Mode Baca Saja** dan **Login Edit (`NexsdaONE@134`)** tetap aktif penuh di sisi server lokal.
- Tidak perlu menjalankan terminal atau browser terpisah.

---

## Prasyarat di Laptop Windows
1. Pasang **Node.js versi LTS (20 atau 22)** dari https://nodejs.org/ (cukup 1 kali).
2. Pastikan laptop terhubung internet saat proses build pertama kali (untuk mengunduh paket Electron).

---

## Cara Termudah (Klik 2x)
1. Ekstrak folder proyek ini ke laptop Windows (misal `D:\NEXSDA-ONE`).
2. Klik 2 kali berkas **`BUILD_EXE_WINDOWS.bat`**.
3. Tunggu hingga proses selesai. Folder **`release/`** akan terbuka otomatis berisi 2 berkas `.exe`:
   - **`NEXSDA-ONE-Portable-1.0.0.exe`** — Versi **Portable** (langsung klik 2x jalan tanpa instalasi).
   - **`NEXSDA-ONE-Setup-1.0.0.exe`** — Versi **Installer** (membuat shortcut di Desktop & Start Menu Windows).

---

## Cara Via Terminal (PowerShell / CMD)
```bash
npm install
npm run build:exe
```

Pilihan build khusus:
- Hanya buat versi **Portable `.exe`**:
  ```bash
  npm run build:exe:portable
  ```
- Hanya buat versi **Installer `.exe`**:
  ```bash
  npm run build:exe:installer
  ```
- Uji jalankan versi desktop langsung tanpa memaketkan `.exe`:
  ```bash
  npm run desktop:run
  ```

---

## Konfigurasi Opsional (`.env`)
Secara default, `.exe` langsung terhubung ke Google Drive **`nexsdaone@gmail.com`** dengan kode edit **`NexsdaONE@134`**.
Jika suatu saat ingin mengganti URL Apps Script atau kode edit tanpa rebuild `.exe`, cukup letakkan berkas `.env` di folder yang sama dengan `NEXSDA-ONE-Portable-1.0.0.exe` (atau folder instalasi) berisi:
```env
GOOGLE_DRIVE_APPS_SCRIPT_URL=https://script.google.com/macros/s/.../exec
NEXSDA_EDIT_CODE=NexsdaONE@134
```
