'use strict';

const path = require('node:path');
const fs = require('node:fs');
const { app, BrowserWindow, Menu, shell, dialog, session } = require('electron');

process.env.NEXSDA_DESKTOP_EMBEDDED = '1';

const PREFERRED_LOCAL_PORT = Number(process.env.NEXSDA_DESKTOP_PORT || 45134);

let mainWindow = null;
let startedServer = null;
let serverUrl = '';

const hasSingleInstanceLock = app.requestSingleInstanceLock();
if (!hasSingleInstanceLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

function getCandidateEnvPaths() {
  const candidates = [];
  if (process.env.PORTABLE_EXECUTABLE_DIR) {
    candidates.push(path.join(process.env.PORTABLE_EXECUTABLE_DIR, '.env'));
  }
  candidates.push(path.join(path.dirname(process.execPath), '.env'));
  candidates.push(path.join(app.getPath('userData'), '.env'));
  candidates.push(path.join(process.cwd(), '.env'));
  return [...new Set(candidates)];
}

async function bootEmbeddedServer() {
  const serverBundlePath = path.join(__dirname, '..', 'dist-electron', 'server.cjs');
  if (!fs.existsSync(serverBundlePath)) {
    throw new Error(
      `Berkas server desktop tidak ditemukan di:\n${serverBundlePath}\n\nJalankan "npm run desktop:bundle" terlebih dahulu.`
    );
  }

  const staticDir = path.join(__dirname, '..', 'dist');
  if (!fs.existsSync(path.join(staticDir, 'index.html'))) {
    throw new Error(
      `Folder hasil build "dist/" tidak ditemukan.\nJalankan "npm run build" terlebih dahulu.`
    );
  }

  const serverModule = require(serverBundlePath);
  const startFn = serverModule.startNexsdaServer || serverModule.default?.startNexsdaServer;
  if (typeof startFn !== 'function') {
    throw new Error('Fungsi startNexsdaServer tidak ditemukan di dist-electron/server.cjs');
  }

  startedServer = await startFn({
    host: '127.0.0.1',
    port: PREFERRED_LOCAL_PORT,
    allowFallbackPort: true,
    isProduction: true,
    staticDir,
    envPaths: getCandidateEnvPaths(),
  });
  serverUrl = startedServer.url;
  return startedServer;
}

function buildAppMenu() {
  const template = [
    {
      label: 'Aplikasi',
      submenu: [
        {
          label: 'Muat Ulang Data',
          accelerator: 'CmdOrCtrl+R',
          click: () => {
            if (mainWindow && !mainWindow.isDestroyed()) {
              mainWindow.webContents.reload();
            }
          },
        },
        {
          label: 'Cetak Halaman',
          accelerator: 'CmdOrCtrl+P',
          click: () => {
            if (mainWindow && !mainWindow.isDestroyed()) {
              mainWindow.webContents.print({ silent: false, printBackground: true });
            }
          },
        },
        { type: 'separator' },
        {
          label: 'Keluar',
          accelerator: 'Alt+F4',
          role: 'quit',
        },
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { label: 'Urungkan', role: 'undo' },
        { label: 'Ulangi', role: 'redo' },
        { type: 'separator' },
        { label: 'Potong', role: 'cut' },
        { label: 'Salin', role: 'copy' },
        { label: 'Tempel', role: 'paste' },
        { label: 'Pilih Semua', role: 'selectAll' },
      ],
    },
    {
      label: 'Tampilan',
      submenu: [
        { label: 'Perbesar', role: 'zoomIn' },
        { label: 'Perkecil', role: 'zoomOut' },
        { label: 'Ukuran Normal', role: 'resetZoom' },
        { type: 'separator' },
        { label: 'Layar Penuh', role: 'togglefullscreen' },
      ],
    },
    {
      label: 'Bantuan',
      submenu: [
        {
          label: 'Tentang NEXSDA ONE',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'Tentang NEXSDA ONE',
              message: 'NEXSDA ONE — Desktop Edition',
              detail:
                'Platform Terpadu Seksi KSDA Wilayah I BKSDA Jakarta.\nSinkronisasi otomatis Google Drive (nexsdaone@gmail.com) dengan proteksi kode edit.',
              buttons: ['Tutup'],
            });
          },
        },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

function createMainWindow() {
  const iconPath = path.join(__dirname, 'icon.png');
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 840,
    minWidth: 1024,
    minHeight: 680,
    title: 'NEXSDA ONE | Platform Terpadu Seksi KSDA Wilayah I BKSDA Jakarta',
    icon: fs.existsSync(iconPath) ? iconPath : undefined,
    backgroundColor: '#03070A',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.once('ready-to-show', () => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    mainWindow.maximize();
    mainWindow.show();
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    // Izinkan jendela cetak/pratinjau peta (window.open('', '_blank'))
    if (!url || url === 'about:blank' || url.startsWith(serverUrl)) {
      return {
        action: 'allow',
        overrideBrowserWindowOptions: {
          width: 1120,
          height: 820,
          icon: fs.existsSync(iconPath) ? iconPath : undefined,
          autoHideMenuBar: true,
          webPreferences: {
            contextIsolation: true,
            nodeIntegration: false,
          },
        },
      };
    }

    if (url.startsWith('http://') || url.startsWith('https://')) {
      shell.openExternal(url);
    }
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  mainWindow.loadURL(serverUrl);
}

async function shutdownServer() {
  if (startedServer && startedServer.server) {
    const srv = startedServer.server;
    startedServer = null;
    await new Promise((resolve) => {
      srv.close(() => resolve());
      setTimeout(resolve, 1500);
    });
  }
}

app.whenReady().then(async () => {
  try {
    session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
      const allowed = ['geolocation', 'media', 'clipboard-read', 'clipboard-sanitized-write'];
      callback(allowed.includes(permission));
    });

    buildAppMenu();
    await bootEmbeddedServer();
    createMainWindow();

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0 && serverUrl) {
        createMainWindow();
      }
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    dialog.showErrorBox('Gagal Menjalankan NEXSDA ONE', msg);
    app.quit();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  void shutdownServer();
});
