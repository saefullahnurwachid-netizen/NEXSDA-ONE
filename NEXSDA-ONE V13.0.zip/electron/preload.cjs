'use strict';

const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('nexsdaDesktop', {
  isDesktop: true,
  platform: process.platform,
});
