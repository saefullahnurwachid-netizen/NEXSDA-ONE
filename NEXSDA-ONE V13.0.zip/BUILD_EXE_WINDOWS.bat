@echo off
chcp 65001 >nul
title Builder EXE - NEXSDA ONE BKSDA Jakarta

echo ============================================================
echo   NEXSDA ONE - Pembuat Aplikasi Desktop Windows (.EXE)
echo ============================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Node.js belum terpasang di laptop ini.
  echo Silakan unduh dan pasang Node.js LTS dari https://nodejs.org/
  echo Setelah selesai, jalankan kembali berkas ini.
  pause
  exit /b 1
)

if not exist "node_modules\.bin\vite.cmd" (
  echo [1/2] Memasang dependensi proyek pertama kali...
  call npm install --no-audit --no-fund
  if %errorlevel% neq 0 (
    echo [INFO] Mencoba ulang pemasangan dependensi dengan --legacy-peer-deps...
    call npm install --legacy-peer-deps --no-audit --no-fund
    if %errorlevel% neq 0 (
      echo [ERROR] Gagal menjalankan npm install.
      pause
      exit /b 1
    )
  )
)

echo [2/2] Memproses build aplikasi Windows (.exe)...
call npm run build:exe
if %errorlevel% neq 0 (
  echo [ERROR] Build .exe gagal. Periksa pesan error di atas.
  pause
  exit /b 1
)

echo.
echo ============================================================
echo   BERHASIL! File .exe ada di dalam folder "release".
echo ============================================================
if exist "release" start "" "release"
pause
