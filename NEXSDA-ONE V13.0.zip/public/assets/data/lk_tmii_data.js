window.LK_TMII_DATA = {
  "kategori": [
    {
      "namaKategori": "I. Dilindungi Undang-Undang",
      "slug": "dilindungi",
      "taksa": [
        {
          "namaTaksa": "A. MAMALIA",
          "slug": "mamalia",
          "satwa": []
        },
        {
          "namaTaksa": "B. AVES",
          "slug": "aves",
          "satwa": []
        },
        {
          "namaTaksa": "C. REPTILIA",
          "slug": "reptilia",
          "satwa": []
        },
        {
          "namaTaksa": "D. CRUSTACEA",
          "slug": "crustacea",
          "satwa": []
        }
      ]
    },
    {
      "namaKategori": "II. Tidak Dilindungi Undang-Undang",
      "slug": "tidak_dilindungi",
      "taksa": [
        {
          "namaTaksa": "A. Mamalia",
          "slug": "mamalia",
          "satwa": []
        },
        {
          "namaTaksa": "B. Aves",
          "slug": "aves",
          "satwa": []
        },
        {
          "namaTaksa": "D. Amphibi",
          "slug": "amphibi",
          "satwa": []
        },
        {
          "namaTaksa": "E. Reptil",
          "slug": "reptil",
          "satwa": []
        }
      ]
    }
  ]
};
