// Data Resmi Lampiran Keputusan Kepala Balai KSDA Jakarta Nomor 01 Tahun 2026 (Tanggal 5 Januari 2026)
// Penataan dan Penempatan Pegawai Aparatur Sipil Negara (ASN) Lingkup Balai KSDA Jakarta (127 Personil)
window.DEFAULT_SK01_2026_ASN = [
  // KANTOR BALAI (4)
  {
    nama: "Adam Mustofa, S.H",
    nip: "197311301999031002",
    gol: "Pembina (IV/a)",
    jabatan: "Polisi Kehutanan Ahli Madya",
    unit: "Kantor Balai KSDA Jakarta - Ketua Satgas Pengawasan TSL dan Kawasan Konservasi, Penegakan Hukum/PPNS"
  },
  {
    nama: "Darma Osra, S.Pi",
    nip: "197210201999031002",
    gol: "Pembina Tk. I (IV/b)",
    jabatan: "Polisi Kehutanan Ahli Madya",
    unit: "Kantor Balai KSDA Jakarta - Koordinator Polisi Kehutanan"
  },
  {
    nama: "Nani Rahayu, S.Hut., M.Si",
    nip: "197806232005012005",
    gol: "Pembina Tk. I (IV/b)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Madya",
    unit: "Kantor Balai KSDA Jakarta - Koordinator PEH; Koordinator Data dan Informasi"
  },
  {
    nama: "drh. Windarti, M.Si.",
    nip: "197306171998032002",
    gol: "Pembina (IV/a)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Madya",
    unit: "Kantor Balai KSDA Jakarta - Koordinator Pelayanan Pemanfaatan, Pengawetan dan Perizinan"
  },

  // SUB BAGIAN TATA USAHA (29)
  {
    nama: "Triyanto, S.A.P",
    nip: "198004102007011002",
    gol: "Penata Muda (III/a)",
    jabatan: "Penelaah Teknis Kebijakan",
    unit: "Sub Bagian Tata Usaha - Koordinator Umum, Perlengkapan, BMN, dan Keuangan"
  },
  {
    nama: "Nur Aini, S.E.",
    nip: "198509172009012002",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Penelaah Teknis Kebijakan",
    unit: "Sub Bagian Tata Usaha - PPSPM"
  },
  {
    nama: "Safari Permata Kusumah, S.E",
    nip: "198411222009011003",
    gol: "Penata (III/c)",
    jabatan: "Penelaah Teknis Kebijakan",
    unit: "Sub Bagian Tata Usaha - Pencatat PNBP dan Verifikator SPJ"
  },
  {
    nama: "Irvina Yulianti, S.Kom",
    nip: "198707292010122006",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Pranata Komputer Ahli Pertama",
    unit: "Sub Bagian Tata Usaha - Gaji dan PPABP"
  },
  {
    nama: "Fani Fitrian Yuliawati, A.Md",
    nip: "198707062010122006",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Sub Bagian Tata Usaha - Bendahara Pengeluaran"
  },
  {
    nama: "Nadia Devina Salsabilla, A.Md.A.B",
    nip: "200301232025062003",
    gol: "Pengatur (II/c)",
    jabatan: "Pranata Keuangan APBN Terampil",
    unit: "Sub Bagian Tata Usaha - Urusan Keuangan; Verifikator SPJ"
  },
  {
    nama: "Heny Rahayu, A.Md.A.B",
    nip: "200009262025062010",
    gol: "Pengatur (II/c)",
    jabatan: "Penata Laksana Barang Terampil",
    unit: "Sub Bagian Tata Usaha - Urusan Umum, Perlengkapan, dan BMN"
  },
  {
    nama: "Ridho Ramadhani, S.E.",
    nip: "199103202025211069",
    gol: "Golongan IX",
    jabatan: "Arsiparis Ahli Pertama",
    unit: "Sub Bagian Tata Usaha - Urusan Umum, Perlengkapan, dan BMN"
  },
  {
    nama: "Defita Oktaviane, S.E.",
    nip: "197410182025212013",
    gol: "Golongan IX",
    jabatan: "Penata Layanan Operasional",
    unit: "Sub Bagian Tata Usaha - Urusan Umum, Perlengkapan, dan BMN"
  },
  {
    nama: "Richard Marino Sirait, S.Pi., M.I.L",
    nip: "198204022009121007",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Penyuluh Kehutanan Ahli Muda",
    unit: "Sub Bagian Tata Usaha - Koordinator Perencanaan, Program dan Anggaran; Koordinator Penyuluh Kehutanan"
  },
  {
    nama: "Intan Paramitahasanah, S.E",
    nip: "199304192025062007",
    gol: "Penata Muda (III/a)",
    jabatan: "Analis Anggaran Ahli Pertama",
    unit: "Sub Bagian Tata Usaha - Urusan Perencanaan, Program dan Anggaran; Verifikator SPJ"
  },
  {
    nama: "Sri Rachmayanti, S.E",
    nip: "199605212023211010",
    gol: "Golongan IX",
    jabatan: "Perencana Ahli Pertama",
    unit: "Sub Bagian Tata Usaha - Urusan Perencanaan, Program dan Anggaran"
  },
  {
    nama: "Reza Ulfa Sanjaya, S.Akun",
    nip: "199207232024212031",
    gol: "Golongan IX",
    jabatan: "Perencana Ahli Pertama",
    unit: "Sub Bagian Tata Usaha - Urusan Perencanaan, Program dan Anggaran"
  },
  {
    nama: "Sugiharto",
    nip: "197006272006041001",
    gol: "Penata Muda (III/a)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Sub Bagian Tata Usaha - Urusan Pelayanan, Pemanfaatan dan Perizinan"
  },
  {
    nama: "Beni Diktus",
    nip: "197512302012121002",
    gol: "Pengatur Tk. I (II/d)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Sub Bagian Tata Usaha - Urusan Pelayanan, Pemanfaatan dan Perizinan"
  },
  {
    nama: "Amarantia Tasya Safitrah Gatot Lahay, A.Md.Kom",
    nip: "200012172025062006",
    gol: "Pengatur (II/c)",
    jabatan: "Pranata Komputer Terampil",
    unit: "Sub Bagian Tata Usaha - Urusan Pelayanan, Pemanfaatan dan Perizinan"
  },
  {
    nama: "Vika Triestyana, S.H., M.H.Li",
    nip: "198710292009122004",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Penelaah Teknis Kebijakan",
    unit: "Sub Bagian Tata Usaha - Koordinator Evaluasi, Pelaporan, dan Kehumasan"
  },
  {
    nama: "Elsa Nurlatifa, S.I.Kom",
    nip: "199602052025062010",
    gol: "Penata Muda (III/a)",
    jabatan: "Pranata Hubungan Masyarakat Ahli Pertama",
    unit: "Sub Bagian Tata Usaha - Urusan Publikasi dan Kehumasan"
  },
  {
    nama: "Mandra Herdiansyah, S.M",
    nip: "199512012025211045",
    gol: "Golongan IX",
    jabatan: "Penata Layanan Operasional",
    unit: "Sub Bagian Tata Usaha - Urusan Evaluasi dan Pelaporan"
  },
  {
    nama: "Sobari",
    nip: "197407152008121002",
    gol: "Penata Muda (III/a)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Sub Bagian Tata Usaha - Urusan Kepegawaian dan SDM"
  },
  {
    nama: "Supardiyono",
    nip: "197609102007011002",
    gol: "Penata Muda (III/a)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Sub Bagian Tata Usaha - Urusan Kepegawaian dan SDM"
  },
  {
    nama: "Rezha Darajat, A.Md",
    nip: "199712202024211019",
    gol: "Golongan VII",
    jabatan: "Arsiparis Terampil",
    unit: "Sub Bagian Tata Usaha - Umum dan Persuratan"
  },
  {
    nama: "Dina Arifa Syani",
    nip: "199404192025212065",
    gol: "Golongan V",
    jabatan: "Pengadministrasi Perkantoran",
    unit: "Sub Bagian Tata Usaha - Umum dan Persuratan"
  },
  {
    nama: "Weni Nuraeni",
    nip: "198705152025212066",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Sub Bagian Tata Usaha - Umum dan Perkantoran"
  },
  {
    nama: "Nasep",
    nip: "199206212025211042",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Sub Bagian Tata Usaha - Umum dan Perkantoran"
  },
  {
    nama: "Eman Sulaeman",
    nip: "197608032025211022",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Sub Bagian Tata Usaha - Umum dan Keamanan"
  },
  {
    nama: "Fajar Wahyudi",
    nip: "198902112025211068",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Sub Bagian Tata Usaha - Umum dan Keamanan"
  },
  {
    nama: "Iseran",
    nip: "197602092025211028",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Sub Bagian Tata Usaha - Umum dan Keamanan"
  },
  {
    nama: "Lusiono, S.H",
    nip: "197707072003121003",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "PPBJ Ahli Pertama",
    unit: "Sub Bagian Tata Usaha"
  },

  // SEKSI KONSERVASI WILAYAH I (4)
  {
    nama: "Julian Martoni",
    nip: "197407042012121004",
    gol: "Pengatur Tk. I (II/d)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Seksi KSDA Wilayah I - Kantor SKSDA Wilayah I"
  },
  {
    nama: "Daryanto",
    nip: "197407162006041010",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Seksi KSDA Wilayah I - Kantor SKSDA Wilayah I"
  },
  {
    nama: "Kusrini",
    nip: "197507132025212024",
    gol: "Golongan V",
    jabatan: "Pengadministrasi Perkantoran",
    unit: "Seksi KSDA Wilayah I - Kantor SKSDA Wilayah I"
  },
  {
    nama: "Kiki Suryadin",
    nip: "199402032025211053",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Seksi KSDA Wilayah I - Kantor SKSDA Wilayah I"
  },

  // Resor Jakarta Pusat (6)
  {
    nama: "Deni Rohendi",
    nip: "197204171998031004",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Pusat) - Kepala Resor"
  },
  {
    nama: "Dwi Yani Kusumaningrum, S.Hut",
    nip: "197303191999032002",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Muda",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Pusat) - Anggota; Penugasan ke Sub Bag TU-Urusan Pengawetan"
  },
  {
    nama: "Jubaedah, S.Hut",
    nip: "197812181999032001",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Pusat) - Anggota"
  },
  {
    nama: "Prion Sinurat",
    nip: "197506071999031004",
    gol: "Penata (III/c)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Pusat) - Anggota; Penugasan sebagai Anggota Tim Satgas Pengawasan TSL di Kantor Balai"
  },
  {
    nama: "Eveline Wahyuningtias Yusrina Seddi, S.Si",
    nip: "199903222025062007",
    gol: "Penata Muda (III/a)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Pertama",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Pusat) - Anggota"
  },
  {
    nama: "Nurwachid Saefullah",
    nip: "199812202025061006",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Penyuluh Kehutanan Pemula",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Pusat) - Anggota"
  },

  // Resor Jakarta Timur (6)
  {
    nama: "Deni Mulyana, S.Hut.",
    nip: "198307172007101001",
    gol: "Penata (III/c)",
    jabatan: "Polisi Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Timur) - Kepala Resor"
  },
  {
    nama: "Wisny Haryanti, S.Hut",
    nip: "197705082003122004",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Muda",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Timur) - Anggota; Penugasan ke Sub Bag TU-Urusan Pengawetan"
  },
  {
    nama: "Lis Widia Prasetiowati, A.Md",
    nip: "198610202009011005",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Polisi Kehutanan Mahir",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Timur) - Anggota; Penugasan ke Resor Bandara Soekarno-Hatta"
  },
  {
    nama: "Asep Wiganda",
    nip: "198101122000031001",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Pengendali Ekosistem Hutan Mahir",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Timur) - Anggota; Penugasan ke Sub Bag TU-Urusan Pemanfaatan"
  },
  {
    nama: "Iksan Heriyana, A.Md.",
    nip: "198906042014021003",
    gol: "Penata Muda (III/a)",
    jabatan: "Penyuluh Kehutanan Mahir",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Timur) - Anggota"
  },
  {
    nama: "Euis Rahmah Mar'sholihah, S.Hut",
    nip: "199704272025062011",
    gol: "Penata Muda (III/a)",
    jabatan: "Penyuluh Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Timur) - Anggota"
  },

  // Resor Jakarta Selatan (6)
  {
    nama: "Kusmedi",
    nip: "197106061998031003",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Selatan) - Kepala Resor"
  },
  {
    nama: "Toto Bumi Harto, S.H",
    nip: "197501312000031001",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Selatan) - Anggota"
  },
  {
    nama: "Cherly Nency, S.Si.",
    nip: "198009222009122001",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Pertama",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Selatan) - Anggota"
  },
  {
    nama: "Fadhila Asri Puspaningrum, A.Md",
    nip: "200002042025062010",
    gol: "Pengatur (II/c)",
    jabatan: "Penyuluh Kehutanan Terampil",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Selatan) - Anggota"
  },
  {
    nama: "Haris Swanda",
    nip: "199503102022031006",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Polisi Kehutanan Pemula",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Selatan) - Anggota"
  },
  {
    nama: "Putri Oktorina",
    nip: "199410242023212019",
    gol: "Golongan IX",
    jabatan: "Pengendali Ekosistem Hutan Ahli Pertama",
    unit: "Seksi KSDA Wilayah I (Resor Jakarta Selatan) - Anggota"
  },

  // Resor Bekasi (5)
  {
    nama: "Yustia Damayanthi",
    nip: "198312152005012002",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Pengendali Ekosistem Hutan Mahir",
    unit: "Seksi KSDA Wilayah I (Resor Bekasi) - Kepala Resor"
  },
  {
    nama: "R. Yayan Heryana",
    nip: "197007302008011007",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Polisi Kehutanan Mahir",
    unit: "Seksi KSDA Wilayah I (Resor Bekasi) - Anggota"
  },
  {
    nama: "Rahmat Hidayat, A.Md",
    nip: "198510172009011003",
    gol: "Penata Muda (III/a)",
    jabatan: "Polisi Kehutanan Mahir",
    unit: "Seksi KSDA Wilayah I (Resor Bekasi) - Anggota"
  },
  {
    nama: "Vina Nurul Agustin, S.Pt",
    nip: "200108042025062013",
    gol: "Penata Muda (III/a)",
    jabatan: "Penyuluh Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah I (Resor Bekasi) - Anggota"
  },
  {
    nama: "Synthia Amanda Sitinjak",
    nip: "200202042025062010",
    gol: "Penata Muda (III/a)",
    jabatan: "Penyuluh Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah I (Resor Bekasi) - Anggota"
  },

  // SEKSI KONSERVASI WILAYAH II (9)
  {
    nama: "drh. Shovia Hairani",
    nip: "199210042024212033",
    gol: "Golongan X",
    jabatan: "Medik Veteriner Ahli Pertama",
    unit: "Seksi KSDA Wilayah II - Dokter Hewan PPS-TA"
  },
  {
    nama: "Ismet Permana",
    nip: "198601172025211052",
    gol: "Golongan V",
    jabatan: "Pengadministrasi Perkantoran",
    unit: "Seksi KSDA Wilayah II - Perawat Satwa PPSTA"
  },
  {
    nama: "Okeu Sunandar",
    nip: "198710052025211091",
    gol: "Golongan V",
    jabatan: "Pengadministrasi Perkantoran",
    unit: "Seksi KSDA Wilayah II - Perawat Satwa PPSTA"
  },
  {
    nama: "Narwandi",
    nip: "198107152025211057",
    gol: "Golongan V",
    jabatan: "Pengadministrasi Perkantoran",
    unit: "Seksi KSDA Wilayah II - Perawat Satwa PPSTA"
  },
  {
    nama: "Nasum",
    nip: "198508182025211061",
    gol: "Golongan III",
    jabatan: "Pengelola Umum Operasional",
    unit: "Seksi KSDA Wilayah II - Perawat Satwa PPSTA"
  },
  {
    nama: "Asep Maulana",
    nip: "199611102025211068",
    gol: "Golongan V",
    jabatan: "Pengadministrasi Perkantoran",
    unit: "Seksi KSDA Wilayah II"
  },
  {
    nama: "Iskandar",
    nip: "199110182025211057",
    gol: "Golongan V",
    jabatan: "Pengadministrasi Perkantoran",
    unit: "Seksi KSDA Wilayah II"
  },
  {
    nama: "Rukaya",
    nip: "197901042025212013",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Seksi KSDA Wilayah II - Pramu Kantor"
  },
  {
    nama: "Rohadi",
    nip: "198501092025211035",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Seksi KSDA Wilayah II - Pengaman Kantor"
  },

  // Resor Jakarta Barat (8)
  {
    nama: "Wawan Gunawan",
    nip: "196802031997031004",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah II (Resor Jakarta Barat) - Kepala Resor"
  },
  {
    nama: "Abdul Kohar Joko Prayitno",
    nip: "197605061998031005",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah II (Resor Jakarta Barat) - Anggota"
  },
  {
    nama: "Ermawati, S.Hut",
    nip: "197906071999032001",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah II (Resor Jakarta Barat) - Anggota"
  },
  {
    nama: "Azizah Nur Rohmah, S.P",
    nip: "200204062025062007",
    gol: "Penata Muda (III/a)",
    jabatan: "Penyuluh Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah II (Resor Jakarta Barat) - Anggota"
  },
  {
    nama: "Rezky Putri Piawanza",
    nip: "200103022022032003",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Pengendali Ekosistem Hutan Pemula",
    unit: "Seksi KSDA Wilayah II (Resor Jakarta Barat) - Anggota"
  },
  {
    nama: "Bani Ismanto",
    nip: "197810042012121003",
    gol: "Pengatur (II/c)",
    jabatan: "Polisi Kehutanan Terampil",
    unit: "Seksi KSDA Wilayah II (Resor Jakarta Barat) - Anggota"
  },
  {
    nama: "Sindri Dwi Utari",
    nip: "199708052020122010",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Polisi Kehutanan Pemula",
    unit: "Seksi KSDA Wilayah II (Resor Jakarta Barat) - Anggota"
  },
  {
    nama: "Ahmad Nur Said, S.Hut",
    nip: "199110082024211015",
    gol: "Golongan IX",
    jabatan: "Pengendali Ekosistem Hutan Ahli Pertama",
    unit: "Seksi KSDA Wilayah II (Resor Jakarta Barat) - Anggota"
  },

  // Resor Tangerang (7)
  {
    nama: "Jemy Piter Karubun",
    nip: "198105192000031003",
    gol: "Penata (III/c)",
    jabatan: "Pengendali Ekosistem Hutan Penyelia",
    unit: "Seksi KSDA Wilayah II (Resor Tangerang) - Kepala Resor"
  },
  {
    nama: "Indu Juwita Wati, S.Hut",
    nip: "198111192008012013",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Penyuluh Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah II (Resor Tangerang) - Anggota"
  },
  {
    nama: "Bunaiyah, S.Hut",
    nip: "198011061999032001",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah II (Resor Tangerang) - Anggota"
  },
  {
    nama: "Heradz Gumilang, A.Md",
    nip: "198808182010121008",
    gol: "Penata (III/c)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah II (Resor Tangerang) - Anggota"
  },
  {
    nama: "Silvandrey Hot Gumanti Pasaribu, S.Pi",
    nip: "199207062019021001",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Pertama",
    unit: "Seksi KSDA Wilayah II (Resor Tangerang) - Anggota"
  },
  {
    nama: "Rizqi Rizmayani Putri, S.Pi",
    nip: "199406082025062007",
    gol: "Penata Muda (III/a)",
    jabatan: "Penyuluh Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah II (Resor Tangerang) - Anggota"
  },
  {
    nama: "Arnando Dia Sukma",
    nip: "199605212023211010",
    gol: "Golongan V",
    jabatan: "Pengendali Ekosistem Hutan Pemula",
    unit: "Seksi KSDA Wilayah II (Resor Tangerang) - Anggota"
  },

  // Resor Bandara Soetta (9)
  {
    nama: "Deny Dwi Kurniawan, S.H",
    nip: "198912072014021002",
    gol: "Penata (III/c)",
    jabatan: "Polisi Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Kepala Resor"
  },
  {
    nama: "Ahmad Suadi",
    nip: "196908241998031003",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Anggota"
  },
  {
    nama: "Asep Sarip Hidayat, S.H",
    nip: "197405252005011007",
    gol: "Penata (III/c)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Anggota"
  },
  {
    nama: "Tanton Sumartono",
    nip: "197012042008011001",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Polisi Kehutanan Mahir",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Anggota"
  },
  {
    nama: "Ferdi Yansyah, A.Md.",
    nip: "198501012010121006",
    gol: "Penata Muda (III/a)",
    jabatan: "Polisi Kehutanan Mahir",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Anggota"
  },
  {
    nama: "Isep Kristiadi",
    nip: "198005252001121004",
    gol: "Pengatur (II/c)",
    jabatan: "Pengendali Ekosistem Hutan Terampil",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Anggota"
  },
  {
    nama: "Edi Itlay",
    nip: "198905052010121004",
    gol: "Pengatur Muda Tk. I (II/b)",
    jabatan: "Polisi Kehutanan Terampil",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Anggota; Penugasan sebagai Anggota Tim Satgas Pengawasan TSL di Kantor Balai"
  },
  {
    nama: "Sherina Dwi Kartika",
    nip: "200008012025062016",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Polisi Kehutanan Pemula",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Anggota"
  },
  {
    nama: "Hasyim Hermana Putra, S.Hut",
    nip: "199110242024211013",
    gol: "Golongan IX",
    jabatan: "Pengendali Ekosistem Hutan Ahli Pertama",
    unit: "Seksi KSDA Wilayah II (Resor Bandara Soetta) - Anggota"
  },

  // KANTOR SEKSI KSDA WILAYAH III (5)
  {
    nama: "Rizki Prima, S.Hut",
    nip: "198503112009121001",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Penyuluh Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah III - Koordinator Penyuluh Kehutanan Seksi KSDAW III; Pemetaan/GIS"
  },
  {
    nama: "Indah Prabawati Utami, S.Si.,ME.",
    nip: "198802242014022005",
    gol: "Penata (III/c)",
    jabatan: "Penyuluh Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah III - Koordinator Data dan Informasi Konservasi Kawasan Seksi KSDAW III; Penugasan sebagai Koordinator Kepegawaian dan SDM pada Kantor Balai KSDA Jakarta"
  },
  {
    nama: "Nadiya Fasha Fawzi, S.Hut",
    nip: "199408082018012002",
    gol: "Penata (III/c)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Muda",
    unit: "Seksi KSDA Wilayah III - Koordinator Kerja Sama dan Penelitian di SKSDAW III"
  },
  {
    nama: "Dini Wahyu Sondag Ginting S, S.T",
    nip: "199109292018012001",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Polisi Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah III - Koordinator Perlindungan, Pengawetan dan Pemanfaatan; Pengelola DIPA Seksi KSDAW III dan Pelaporan"
  },
  {
    nama: "Ratifah",
    nip: "199001072025212057",
    gol: "Golongan V",
    jabatan: "Pengadministrasi Perkantoran",
    unit: "Seksi KSDA Wilayah III - Umum dan Kearsipan"
  },

  // Resor Jakarta Utara (7)
  {
    nama: "Wawan Ridwan, S.Hut",
    nip: "197604301999031002",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Polisi Kehutanan Ahli Muda",
    unit: "Seksi KSDA Wilayah III (Resor Jakarta Utara) - Kepala Resor (Penugasan dari SKSDA Wil. II)"
  },
  {
    nama: "Roni Abdulah, S.P.",
    nip: "198304232007101001",
    gol: "Penata Muda (III/a)",
    jabatan: "Polisi Kehutanan Mahir",
    unit: "Seksi KSDA Wilayah III (Resor Jakarta Utara) - Anggota"
  },
  {
    nama: "Dede Fauzi",
    nip: "197905261998031001",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Pengendali Ekosistem Hutan Mahir",
    unit: "Seksi KSDA Wilayah III (Resor Jakarta Utara) - Anggota"
  },
  {
    nama: "Rachmisanti Hutami, S.T",
    nip: "199507122025062006",
    gol: "Penata Muda (III/a)",
    jabatan: "Penyuluh Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah III (Resor Jakarta Utara) - Anggota"
  },
  {
    nama: "Rizki Abi Kurnia",
    nip: "199807142022031007",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Polisi Kehutanan Pemula",
    unit: "Seksi KSDA Wilayah III (Resor Jakarta Utara) - Pos Pelabuhan Tanjung Priok (Anggota)"
  },
  {
    nama: "Arfin Ghozali",
    nip: "200008122025061007",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Polisi Kehutanan Pemula",
    unit: "Seksi KSDA Wilayah III (Resor Jakarta Utara) - Pos Pelabuhan Tanjung Priok (Anggota)"
  },
  {
    nama: "Joshua Pamungkas Adinegoro",
    nip: "199604222024211018",
    gol: "Golongan V",
    jabatan: "Pengendali Ekosistem Hutan Pemula",
    unit: "Seksi KSDA Wilayah III (Resor Jakarta Utara) - Pos Pelabuhan Tanjung Priok (Anggota)"
  },

  // Resor Suaka Margasatwa Muara Angke dan Taman Wisata Alam Angke Kapuk (10)
  {
    nama: "Fahri Ikhlas, S.Hut",
    nip: "199602122019021001",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Penyuluh Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Kepala"
  },
  {
    nama: "Irwan Nuryadi, S.Si",
    nip: "198506252009121002",
    gol: "Penata Tk. I (III/d)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Muda",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },
  {
    nama: "Yusuf Muhammad, S.Hut.",
    nip: "199208312018011001",
    gol: "Penata Muda Tk. I (III/b)",
    jabatan: "Polisi Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },
  {
    nama: "Aripin",
    nip: "197806152008121002",
    gol: "Penata Muda (III/a)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },
  {
    nama: "Alvira Niryana Ravila, S.Si",
    nip: "199909192025062009",
    gol: "Penata Muda (III/a)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Pertama",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },
  {
    nama: "Layla Azizah Ditha Sari, A.Md",
    nip: "200006222025062011",
    gol: "Pengatur (II/c)",
    jabatan: "Penyuluh Kehutanan Terampil",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },
  {
    nama: "Meidilla Anggraini",
    nip: "200305042025062003",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Penyuluh Kehutanan Pemula",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },
  {
    nama: "Andrianto",
    nip: "200502042025061002",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Juru Mudi Kapal Kelas III",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },
  {
    nama: "Ujang Rohmat",
    nip: "197908252025211037",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },
  {
    nama: "Agus",
    nip: "198708202025211076",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Seksi KSDA Wilayah III (Resor SMMA dan TWAAK) - Anggota"
  },

  // Resor Suaka Margasatwa Pulau Rambut dan Cagar Alam Pulau Bokor (12)
  {
    nama: "Dede Dicky Permadi",
    nip: "198212312005011006",
    gol: "Penata (III/c)",
    jabatan: "Polisi Kehutanan Penyelia",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Kepala"
  },
  {
    nama: "Andri Achmad Faizal, A.Md.",
    nip: "199005102015021004",
    gol: "Pengatur Tk. I (II/d)",
    jabatan: "Polisi Kehutanan Terampil",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Budi Kusuma Wardana",
    nip: "198011202008121002",
    gol: "Pengatur Tk. I (II/d)",
    jabatan: "Polisi Kehutanan Terampil",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Warsa Jaya",
    nip: "197609122006041016",
    gol: "Penata Muda (III/a)",
    jabatan: "Pengolah Data dan Informasi",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Irma Kusuma Ningrum, S.Hut",
    nip: "200008092025062015",
    gol: "Penata Muda (III/a)",
    jabatan: "Pengendali Ekosistem Hutan Ahli Pertama",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Fransisca Sariuli Putri T. S.Pi",
    nip: "199804202025062011",
    gol: "Penata Muda (III/a)",
    jabatan: "Penyuluh Kehutanan Ahli Pertama",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Tri Wahyudi",
    nip: "200201222025061002",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Penyuluh Kehutanan Pemula",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Muhammad Yusuf Nurohman",
    nip: "200410142025061001",
    gol: "Pengatur Muda (II/a)",
    jabatan: "Juru Mudi Kapal Kelas III",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Marsul",
    nip: "199304222025211045",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Hendra Saputra",
    nip: "198005022025211057",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Chokih Kosasi",
    nip: "199601122025211047",
    gol: "Golongan V",
    jabatan: "Operator Layanan Operasional",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  },
  {
    nama: "Samsuli",
    nip: "197008102025211018",
    gol: "Golongan III",
    jabatan: "Pengelola Umum Operasional",
    unit: "Seksi KSDA Wilayah III (Resor SMPR dan CAPB) - Anggota"
  }
];
