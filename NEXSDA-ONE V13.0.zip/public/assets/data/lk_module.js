// lk_module.js - Modul Buku Stok & Register Satwa Koleksi Lembaga Konservasi (LK)
// Terbagi menjadi 2 kategori: Satwa Koleksi Dilindungi dan Satwa Koleksi Tidak Dilindungi
// Platform Terpadu Seksi KSDA Wilayah I BKSDA Jakarta

(function(window) {
  'use strict';

  // 1. Metadata Resmi Lembaga Konservasi
  const LK_METADATA = {
    id: "",
    namaLK: "Lembaga Konservasi",
    unit: "-",
    resor: "-",
    alamat: "-",
    koordinat: { lat: -6.1754, lng: 106.8272 },
    noSK: "-",
    izin: "Lembaga Konservasi",
    tglTerbit: "-",
    tglBerakhir: "-",
    periodeLaporan: "-",
    tglLaporan: "-",
    pdfUrl: "",
    penandatangan: {
      pelapor: {
        nama: "-",
        jabatan: "Pelapor",
        label: "Yang Melaporkan"
      },
      mengetahui: {
        nama: "-",
        jabatan: "Mengetahui",
        label: "Mengetahui"
      },
      menyetujui: {
        nama: "-",
        jabatan: "Menyetujui",
        label: "Menyetujui"
      }
    },
    beritaAcara: []
  };

  // Konstanta Kategori Status Perlindungan Satwa Koleksi LK
  const LK_STATUS_PERLINDUNGAN = [
    {
      slug: 'dilindungi',
      label: 'Satwa Koleksi Dilindungi',
      shortLabel: 'Dilindungi',
      namaKategori: 'I. Satwa Koleksi Dilindungi Undang-Undang',
      sectionTitle: 'BAGIAN I — SATWA KOLEKSI DILINDUNGI UNDANG-UNDANG',
      description: 'Satwa koleksi LK yang berstatus dilindungi peraturan perundang-undangan (P.106/KLHK).',
      badgeClass: 'bg-indigo-100 text-indigo-900 border-indigo-200',
      headerClass: 'bg-indigo-950 text-white border-indigo-900'
    },
    {
      slug: 'tidak_dilindungi',
      label: 'Satwa Koleksi Tidak Dilindungi',
      shortLabel: 'Tidak Dilindungi',
      namaKategori: 'II. Satwa Koleksi Tidak Dilindungi Undang-Undang',
      sectionTitle: 'BAGIAN II — SATWA KOLEKSI TIDAK DILINDUNGI UNDANG-UNDANG',
      description: 'Satwa koleksi LK yang berstatus tidak dilindungi (termasuk satwa eksotik & non-dilindungi).',
      badgeClass: 'bg-teal-100 text-teal-900 border-teal-200',
      headerClass: 'bg-teal-900 text-white border-teal-800'
    }
  ];

  // State Modul LK
  let currentLKData = null;
  let activeLKFilterPerlindungan = 'ALL'; // 'ALL', 'dilindungi', 'tidak_dilindungi'
  let activeLKFilterTaksa = 'ALL'; // 'ALL', 'mamalia', 'aves', 'reptilia', 'amphibi', 'crustacea'
  let activeLKOnlyMutations = false;
  let activeLKSearchQuery = '';
  let activeMutasiModalStatusFilter = 'ALL'; // Filter status perlindungan di modal mutasi LK

  // Semua stok LK dinormalisasi menjadi Satwa Koleksi (migrasi aman data lama)
  function normalizeJenisStok() {
    return 'koleksi';
  }

  function normalizePerlindunganSlug(val) {
    return val === 'tidak_dilindungi' ? 'tidak_dilindungi' : 'dilindungi';
  }

  function getPerlindunganMeta(slug) {
    const key = normalizePerlindunganSlug(slug);
    return LK_STATUS_PERLINDUNGAN.find(s => s.slug === key) || LK_STATUS_PERLINDUNGAN[0];
  }

  // Parser tanggal tangguh: mendukung format ISO (YYYY-MM-DD) maupun format kalender Indonesia (24 November 2026)
  function parseLKDate(rawVal) {
    if (!rawVal) return null;
    if (rawVal instanceof Date) return Number.isNaN(rawVal.getTime()) ? null : rawVal;
    const str = String(rawVal).trim();
    if (!str) return null;

    // 1. Format ISO YYYY-MM-DD
    const isoMatch = str.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (isoMatch) {
      const d = new Date(parseInt(isoMatch[1], 10), parseInt(isoMatch[2], 10) - 1, parseInt(isoMatch[3], 10));
      return Number.isNaN(d.getTime()) ? null : d;
    }

    // 2. Format DD/MM/YYYY atau DD-MM-YYYY
    const dmyMatch = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
    if (dmyMatch) {
      const d = new Date(parseInt(dmyMatch[3], 10), parseInt(dmyMatch[2], 10) - 1, parseInt(dmyMatch[1], 10));
      return Number.isNaN(d.getTime()) ? null : d;
    }

    // 3. Format Bahasa Indonesia: "24 November 2026" atau "24 Nov 2026"
    const monthMap = {
      januari: 0, jan: 0, februari: 1, feb: 1, maret: 2, mar: 2, april: 3, apr: 3,
      mei: 4, may: 4, juni: 5, jun: 5, juli: 6, jul: 6, agustus: 7, agt: 7, agu: 7, aug: 7,
      september: 8, sep: 8, sept: 8, oktober: 9, okt: 9, oct: 9, november: 10, nov: 10,
      desember: 11, des: 11, dec: 11
    };
    const indoMatch = str.toLowerCase().match(/(\d{1,2})\s+([a-z]+)\s+(\d{4})/);
    if (indoMatch && Object.prototype.hasOwnProperty.call(monthMap, indoMatch[2])) {
      const d = new Date(parseInt(indoMatch[3], 10), monthMap[indoMatch[2]], parseInt(indoMatch[1], 10));
      return Number.isNaN(d.getTime()) ? null : d;
    }

    const fallback = new Date(str);
    return Number.isNaN(fallback.getTime()) ? null : fallback;
  }

  function notifyLK(title, message) {
    if (typeof window.showToast === 'function') {
      window.showToast(title, message);
    }
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function ensureNormalizedLKData(raw) {
    if (!raw || !Array.isArray(raw.kategori)) return raw;
    raw.kategori.forEach(kat => {
      kat.slug = normalizePerlindunganSlug(kat.slug);
      if (!Array.isArray(kat.taksa)) kat.taksa = [];
      kat.taksa.forEach(tk => {
        if (!Array.isArray(tk.satwa)) tk.satwa = [];
        tk.satwa.forEach((item, idx) => {
          // Migrasi aman: semua stok LK menjadi Satwa Koleksi
          item.jenisStok = 'koleksi';
          if (!Array.isArray(item.awal) || item.awal.length < 4) {
            item.awal = [0, 0, 0, 0];
          }
          if (!Array.isArray(item.akhir) || item.akhir.length < 4) {
            item.akhir = [...item.awal];
          }
          if (!Array.isArray(item.mutasiLog)) {
            item.mutasiLog = [];
          }
          if (typeof item.no !== 'number') {
            item.no = idx + 1;
          }
        });
      });
    });

    // Pastikan kategori Dilindungi & Tidak Dilindungi selalu tersedia
    LK_STATUS_PERLINDUNGAN.forEach(meta => {
      if (!raw.kategori.some(k => k.slug === meta.slug)) {
        raw.kategori.push({
          namaKategori: meta.namaKategori,
          slug: meta.slug,
          taksa: []
        });
      }
    });

    return raw;
  }

  // 2. Inisialisasi Data
  function getLKData() {
    if (!currentLKData) {
      const stored = localStorage.getItem('BKSDA_LK_DATASET_V1');
      if (stored) {
        try {
          currentLKData = JSON.parse(stored);
        } catch (e) {
          console.warn('Gagal memuat LK data dari storage, menggunakan dataset default:', e);
          currentLKData = window.LK_TMII_DATA ? JSON.parse(JSON.stringify(window.LK_TMII_DATA)) : { kategori: [] };
        }
      } else if (window.LK_TMII_DATA) {
        currentLKData = JSON.parse(JSON.stringify(window.LK_TMII_DATA));
      } else {
        currentLKData = { kategori: [] };
      }
    }
    return ensureNormalizedLKData(currentLKData);
  }

  function reloadLKDataFromStorage() {
    currentLKData = null;
    return getLKData();
  }

  function saveLKData() {
    if (typeof window.isEditModeUnlocked === 'function' && !window.isEditModeUnlocked()) {
      return;
    }
    if (currentLKData) {
      ensureNormalizedLKData(currentLKData);
      localStorage.setItem('BKSDA_LK_DATASET_V1', JSON.stringify(currentLKData));
      if (typeof window.scheduleDriveAutoSave === 'function') {
        window.scheduleDriveAutoSave('Data Stok Satwa Koleksi LK (Dilindungi & Tidak Dilindungi)');
      }
    }
  }

  // 3. Perhitungan Statistik Ringkasan Satwa Koleksi LK (Dilindungi & Tidak Dilindungi + Total)
  function calculateLKStats(filterBulan = 'ALL', filterTahun = '2026') {
    const data = getLKData();
    if (!data || !data.kategori) return null;

    let totalSpesies = 0;
    let totalAwal = [0, 0, 0, 0];
    let totalAkhir = [0, 0, 0, 0];
    let totalTambah = 0;
    let totalKurang = 0;

    const dilindungiStats = { spesies: 0, awal: [0, 0, 0, 0], akhir: [0, 0, 0, 0], tambah: 0, kurang: 0 };
    const tidakDilindungiStats = { spesies: 0, awal: [0, 0, 0, 0], akhir: [0, 0, 0, 0], tambah: 0, kurang: 0 };

    const taksaSummary = {
      mamalia: { spesies: 0, ekor: 0 },
      aves: { spesies: 0, ekor: 0 },
      reptilia: { spesies: 0, ekor: 0 },
      amphibi: { spesies: 0, ekor: 0 },
      crustacea: { spesies: 0, ekor: 0 }
    };

    const targetYearInt = parseInt(filterTahun, 10);
    const targetMonthInt = filterBulan === 'ALL' ? null : parseInt(filterBulan, 10);

    data.kategori.forEach(kat => {
      const isDilindungi = kat.slug === 'dilindungi';
      const targetKat = isDilindungi ? dilindungiStats : tidakDilindungiStats;

      kat.taksa.forEach(tk => {
        const tSlug = tk.slug === 'reptil' ? 'reptilia' : tk.slug;

        tk.satwa.forEach(item => {
          item.jenisStok = 'koleksi';
          totalSpesies++;
          targetKat.spesies++;

          if (!Array.isArray(item.mutasiLog)) item.mutasiLog = [];

          // Saldo Awal sebelum periode terpilih
          const awal = [...item.awal];
          const filteredMutasi = [];

          item.mutasiLog.forEach(m => {
            const mDate = parseLKDate(m.tanggal);
            if (!mDate) return;
            const mBulan = mDate.getMonth() + 1;
            const mTahun = mDate.getFullYear();

            const isBefore =
              (mTahun < targetYearInt) ||
              (mTahun === targetYearInt && targetMonthInt !== null && mBulan < targetMonthInt);

            const isInPeriod =
              (mTahun === targetYearInt) &&
              (targetMonthInt === null || mBulan === targetMonthInt);

            if (isBefore) {
              const colIdx = m.kelamin === 'jantan' ? 0 : (m.kelamin === 'betina' ? 1 : 2);
              const qty = parseInt(m.jumlah, 10) || 0;
              if (String(m.tipe || '').startsWith('TAMBAH_')) {
                awal[colIdx] += qty;
                awal[3] += qty;
              } else {
                awal[colIdx] = Math.max(0, awal[colIdx] - qty);
                awal[3] = Math.max(0, awal[3] - qty);
              }
            } else if (isInPeriod) {
              filteredMutasi.push(m);
            }
          });

          const akhir = [...awal];
          let tambahBulan = 0;
          let kurangBulan = 0;

          filteredMutasi.forEach(m => {
            const colIdx = m.kelamin === 'jantan' ? 0 : (m.kelamin === 'betina' ? 1 : 2);
            const qty = parseInt(m.jumlah, 10) || 0;
            if (String(m.tipe || '').startsWith('TAMBAH_')) {
              akhir[colIdx] += qty;
              akhir[3] += qty;
              tambahBulan += qty;
            } else {
              akhir[colIdx] = Math.max(0, akhir[colIdx] - qty);
              akhir[3] = Math.max(0, akhir[3] - qty);
              kurangBulan += qty;
            }
          });

          if (taksaSummary[tSlug]) {
            taksaSummary[tSlug].spesies++;
            taksaSummary[tSlug].ekor += akhir[3];
          }

          for (let i = 0; i < 4; i++) {
            totalAwal[i] += awal[i];
            totalAkhir[i] += akhir[i];
            targetKat.awal[i] += awal[i];
            targetKat.akhir[i] += akhir[i];
          }

          totalTambah += tambahBulan;
          totalKurang += kurangBulan;
          targetKat.tambah += tambahBulan;
          targetKat.kurang += kurangBulan;

          // Nilai terhitung untuk rendering periode aktif
          item.tempAwal = awal;
          item.tempAkhir = akhir;
          item.tempMutasi = filteredMutasi;
        });
      });
    });

    const koleksiStats = {
      spesies: totalSpesies,
      awal: [...totalAwal],
      akhir: [...totalAkhir],
      tambah: totalTambah,
      kurang: totalKurang,
      dilindungi: dilindungiStats,
      tidakDilindungi: tidakDilindungiStats
    };

    return {
      totalSpesies,
      totalAwal,
      totalAkhir,
      totalTambah,
      totalKurang,
      dilindungiStats,
      tidakDilindungiStats,
      koleksiStats,
      taksaSummary
    };
  }

  function calculateTaksaSubtotal(satwaList) {
    const awal = [0, 0, 0, 0];
    const akhir = [0, 0, 0, 0];
    let tambah = 0;
    let kurang = 0;
    const tambahDetail = { lahir: 0, tukar: 0, titipan: 0, pinjam: 0, lain: 0 };
    const kurangDetail = { mati: 0, tukar: 0, dipinjamkan: 0, lepasliar: 0, lain: 0 };

    satwaList.forEach(item => {
      const a = item.tempAwal || item.awal || [0, 0, 0, 0];
      const k = item.tempAkhir || item.akhir || [0, 0, 0, 0];
      for (let i = 0; i < 4; i++) {
        awal[i] += a[i] || 0;
        akhir[i] += k[i] || 0;
      }

      if (Array.isArray(item.tempMutasi) && item.tempMutasi.length > 0) {
        item.tempMutasi.forEach(m => {
          const qty = parseInt(m.jumlah, 10) || 0;
          switch (m.tipe) {
            case 'TAMBAH_LAHIR': tambahDetail.lahir += qty; tambah += qty; break;
            case 'TAMBAH_TUKAR': tambahDetail.tukar += qty; tambah += qty; break;
            case 'TAMBAH_TITIPAN': tambahDetail.titipan += qty; tambah += qty; break;
            case 'TAMBAH_PINJAM': tambahDetail.pinjam += qty; tambah += qty; break;
            case 'TAMBAH_LAINNYA': tambahDetail.lain += qty; tambah += qty; break;
            case 'KURANG_MATI': kurangDetail.mati += qty; kurang += qty; break;
            case 'KURANG_TUKAR': kurangDetail.tukar += qty; kurang += qty; break;
            case 'KURANG_DIPINJAMKAN': kurangDetail.dipinjamkan += qty; kurang += qty; break;
            case 'KURANG_LEPASLIAR': kurangDetail.lepasliar += qty; kurang += qty; break;
            case 'KURANG_LAINNYA': kurangDetail.lain += qty; kurang += qty; break;
            default:
              if (String(m.tipe || '').startsWith('TAMBAH_')) { tambahDetail.lain += qty; tambah += qty; }
              else { kurangDetail.lain += qty; kurang += qty; }
          }
        });
      }
    });

    return { awal, akhir, tambah, kurang, tambahDetail, kurangDetail };
  }

  function getFilteredTaksaForKategori(data, katSlug) {
    const filteredTaksa = [];
    const matchingKats = (data.kategori || []).filter(k => normalizePerlindunganSlug(k.slug) === katSlug);

    matchingKats.forEach(kat => {
      (kat.taksa || []).forEach(tk => {
        const tSlug = tk.slug === 'reptil' ? 'reptilia' : tk.slug;
        if (activeLKFilterTaksa !== 'ALL' && tSlug !== activeLKFilterTaksa) {
          return;
        }

        const filteredSatwa = (tk.satwa || []).filter(item => {
          if (activeLKOnlyMutations) {
            const hasPeriodMutasi = Array.isArray(item.tempMutasi) && item.tempMutasi.length > 0;
            if (!hasPeriodMutasi) return false;
          }

          if (activeLKSearchQuery.trim()) {
            const query = activeLKSearchQuery.toLowerCase();
            const matchIndo = (item.namaIndo || '').toLowerCase().includes(query);
            const matchLatin = (item.namaLatin || '').toLowerCase().includes(query);
            const matchBA = (item.ba || '').toLowerCase().includes(query);
            const matchMutBA = (item.tempMutasi || []).some(m => (m.noBA || '').toLowerCase().includes(query));
            if (!matchIndo && !matchLatin && !matchBA && !matchMutBA) return false;
          }

          return true;
        });

        if (filteredSatwa.length > 0) {
          filteredTaksa.push({
            ...tk,
            satwa: filteredSatwa
          });
        }
      });
    });

    return filteredTaksa;
  }

  function updateLKSidebarBadge(stats) {
    const badgeSidebar = document.getElementById('badgeLKCount');
    if (badgeSidebar && stats) {
      badgeSidebar.textContent = `${stats.totalAkhir[3].toLocaleString('id-ID')} Satwa`;
    }
    const countLKSatwaTotal = document.getElementById('stokCountLKSatwaTotal');
    if (countLKSatwaTotal && stats) {
      countLKSatwaTotal.textContent = stats.totalAkhir[3].toLocaleString('id-ID');
    }
  }

  // 4. Render Modul Utama Lembaga Konservasi (jika tab standalone view-stok-lk tersedia)
  function renderLKSatwaView() {
    const stats = calculateLKStats();
    if (!stats) return;
    updateLKSidebarBadge(stats);

    const container = document.getElementById('view-stok-lk');
    if (!container) return;

    container.innerHTML = `
      <div class="space-y-4">
        <div class="bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 shadow-lg flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div class="space-y-1.5">
            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10.5px] font-bold tracking-wider uppercase">
              <i data-lucide="trees" class="w-3.5 h-3.5"></i> Lembaga Konservasi (LK)
            </span>
            <h2 class="text-xl sm:text-2xl font-black text-white">${escapeHtml(LK_METADATA.namaLK)}</h2>
            <p class="text-xs text-slate-300 max-w-3xl">Buku stok &amp; register <b>Satwa Koleksi</b> Lembaga Konservasi terbagi menjadi <b>Dilindungi</b> dan <b>Tidak Dilindungi</b>.</p>
          </div>
          <div class="flex flex-wrap gap-2 shrink-0">
            <button type="button" onclick="window.LKSatwaModule.openModalTambahSatwaBaru('dilindungi')" class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition">
              <i data-lucide="plus" class="w-4 h-4"></i> Input Koleksi Dilindungi
            </button>
            <button type="button" onclick="window.LKSatwaModule.openModalTambahSatwaBaru('tidak_dilindungi')" class="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition">
              <i data-lucide="plus" class="w-4 h-4"></i> Input Koleksi Tidak Dilindungi
            </button>
            <button type="button" onclick="window.LKSatwaModule.openModalTambahMutasiLK()" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition">
              <i data-lucide="plus-circle" class="w-4 h-4"></i> Catat Mutasi LK
            </button>
          </div>
        </div>
        ${renderLKSatwaStockTableHtml({ namaPerusahaan: LK_METADATA.namaLK }, 'ALL', '2026')}
      </div>
    `;

    if (window.lucide) lucide.createIcons();
  }

  // 5. Filter & Search Handlers
  function refreshLKViews() {
    if (typeof window.renderStokModuleView === 'function') {
      try { window.renderStokModuleView(); } catch (e) {}
    }
    renderLKSatwaView();
  }

  function setFilterPerlindungan(slug) {
    activeLKFilterPerlindungan = (slug === 'dilindungi' || slug === 'tidak_dilindungi') ? slug : 'ALL';
    refreshLKViews();
  }

  // Alias kompatibilitas mundur
  function setFilterJenisStok(val) {
    if (val === 'dilindungi' || val === 'tidak_dilindungi') {
      setFilterPerlindungan(val);
    } else {
      setFilterPerlindungan('ALL');
    }
  }

  function setFilterTaksa(slug) {
    activeLKFilterTaksa = slug;
    refreshLKViews();
  }

  function toggleOnlyMutations(isChecked) {
    activeLKOnlyMutations = !!isChecked;
    refreshLKViews();
  }

  function handleSearch(query) {
    activeLKSearchQuery = query || '';
    refreshLKViews();
  }

  // 6. Navigation ke Buku Stok LK di Modul Perusahaan
  function goToLKStokTab() {
    if (typeof window.filterStokByScheme === 'function') {
      window.filterStokByScheme('Lembaga Konservasi');
    } else if (typeof window.switchTab === 'function') {
      window.switchTab('stok');
    }
  }

  // 8. Modal Detail Berita Acara
  function openModalBADetail(baNumber) {
    const ba = LK_METADATA.beritaAcara.find(b => b.nomor === baNumber) || {
      nomor: baNumber,
      tanggal: "Tahun 2026",
      instansi: "BKSDA Jakarta",
      perihal: "Dokumen Berita Acara Mutasi Satwa LK",
      spesies: [],
      catatan: "Dokumen sah terdaftar dalam arsip penatausahaan TSL Seksi Konservasi Wilayah I BKSDA Jakarta."
    };

    let modal = document.getElementById('modalBADetailLK');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'modalBADetailLK';
      modal.className = 'fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden';
      modal.innerHTML = `
        <div class="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200">
          <div class="bg-gradient-to-r from-indigo-900 to-slate-900 text-white p-5 flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
                <i data-lucide="file-check-2" class="w-5 h-5"></i>
              </div>
              <div>
                <span class="text-[10px] font-mono text-indigo-300 uppercase tracking-wider block">Detail Berita Acara</span>
                <h4 id="baModalNumber" class="font-bold text-sm"></h4>
              </div>
            </div>
            <button onclick="window.LKSatwaModule.closeModalBADetail()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition">
              <i data-lucide="x" class="w-4 h-4"></i>
            </button>
          </div>
          <div id="baModalBody" class="p-6 space-y-4 text-xs"></div>
          <div class="bg-slate-50 p-4 px-6 border-t border-slate-200 flex justify-end">
            <button onclick="window.LKSatwaModule.closeModalBADetail()" class="px-5 py-2 bg-slate-800 text-white rounded-xl text-xs font-semibold hover:bg-slate-900 transition">Tutup</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
    }

    document.getElementById('baModalNumber').textContent = ba.nomor;
    const body = document.getElementById('baModalBody');
    body.innerHTML = `
      <div class="space-y-1">
        <p class="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Perihal Dokumen:</p>
        <p class="font-bold text-slate-900 text-sm">${escapeHtml(ba.perihal)}</p>
      </div>

      <div class="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 font-mono text-[11px]">
        <div>
          <span class="text-slate-400 block text-[9.5px]">Tanggal Penetapan:</span>
          <span class="font-bold text-slate-800">${escapeHtml(ba.tanggal)}</span>
        </div>
        <div>
          <span class="text-slate-400 block text-[9.5px]">Instansi / Pihak:</span>
          <span class="font-bold text-slate-800">${escapeHtml(ba.instansi)}</span>
        </div>
      </div>

      <div class="space-y-2">
        <p class="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Daftar Spesimen / Satwa Terlibat:</p>
        <div class="space-y-1.5 max-h-48 overflow-y-auto">
          ${ba.spesies.length ? ba.spesies.map(sp => `
            <div class="p-2.5 rounded-lg border border-slate-200 bg-white flex items-center justify-between">
              <div>
                <span class="font-bold text-slate-900 block">${escapeHtml(sp.nama)}</span>
                <span class="text-[10px] text-slate-500">${escapeHtml(sp.kelamin)} • Status: ${escapeHtml(sp.status)}</span>
              </div>
              <span class="px-2 py-1 rounded font-bold font-mono text-xs ${sp.mutasi.includes('Penambahan') ? 'bg-emerald-100 text-emerald-900' : 'bg-rose-100 text-rose-900'}">
                ${sp.qty} ekor
              </span>
            </div>
          `).join('') : '<p class="text-slate-400 italic">Data rincian spesimen dapat dilihat pada lembar BAP terkait.</p>'}
        </div>
      </div>

      <div class="space-y-1 p-3 bg-indigo-50/60 rounded-xl border border-indigo-100">
        <p class="text-indigo-900 font-bold text-[10px] uppercase">Catatan / Ringkasan BAP:</p>
        <p class="text-indigo-950 leading-relaxed">${escapeHtml(ba.catatan)}</p>
      </div>
    `;

    modal.classList.remove('hidden');
    if (window.lucide) lucide.createIcons();
  }

  function closeModalBADetail() {
    const modal = document.getElementById('modalBADetailLK');
    if (modal) modal.classList.add('hidden');
  }

  // 9. Cetak Format Resmi BKSDA (Satwa Koleksi Dilindungi & Tidak Dilindungi)
  function printLaporanResmiLK() {
    const data = getLKData();
    const stats = calculateLKStats();
    if (!data || !stats) return;

    const buildPrintSectionRows = (statusMeta) => {
      const isDilindungi = statusMeta.slug === 'dilindungi';
      const bucket = isDilindungi ? stats.dilindungiStats : stats.tidakDilindungiStats;
      let html = `
        <tr><td colspan="22" style="background:${isDilindungi ? '#e0e7ff' : '#ccfbf1'}; font-weight:bold; font-size:8.5pt; padding:5px 6px;">${statusMeta.sectionTitle} (${bucket.spesies} Jenis • ${bucket.akhir[3]} Ekor)</td></tr>
      `;
      let hasAny = false;

      const matchingKats = (data.kategori || []).filter(k => normalizePerlindunganSlug(k.slug) === statusMeta.slug);
      matchingKats.forEach(kat => {
        const taksaWithItems = (kat.taksa || []).filter(tk => Array.isArray(tk.satwa) && tk.satwa.length > 0);
        if (taksaWithItems.length === 0) return;
        hasAny = true;

        taksaWithItems.forEach(tk => {
          const sub = calculateTaksaSubtotal(tk.satwa);
          html += `<tr><td colspan="22" class="sub-hdr">${escapeHtml(tk.namaTaksa)}</td></tr>`;

          tk.satwa.forEach((item, idx) => {
            const a = item.tempAwal || item.awal;
            const k = item.tempAkhir || item.akhir;
            const getT = (tp) => (item.tempMutasi || []).filter(m => m.tipe === tp).reduce((s, m) => s + (parseInt(m.jumlah, 10) || 0), 0);

            html += `
              <tr>
                <td class="text-center">${idx + 1}</td>
                <td>${escapeHtml(item.namaIndo)}</td>
                <td><i>${escapeHtml(item.namaLatin)}</i></td>
                <td class="text-center">${a[0]}</td>
                <td class="text-center">${a[1]}</td>
                <td class="text-center">${a[2]}</td>
                <td class="text-center font-bold">${a[3]}</td>
                <td class="text-center">${getT('TAMBAH_LAHIR') || '-'}</td>
                <td class="text-center">${getT('TAMBAH_TUKAR') || '-'}</td>
                <td class="text-center font-bold">${getT('TAMBAH_TITIPAN') || '-'}</td>
                <td class="text-center">${getT('TAMBAH_PINJAM') || '-'}</td>
                <td class="text-center">${getT('TAMBAH_LAINNYA') || '-'}</td>
                <td class="text-center font-bold">${getT('KURANG_MATI') || '-'}</td>
                <td class="text-center">${getT('KURANG_TUKAR') || '-'}</td>
                <td class="text-center">${getT('KURANG_DIPINJAMKAN') || '-'}</td>
                <td class="text-center">${getT('KURANG_LEPASLIAR') || '-'}</td>
                <td class="text-center">${getT('KURANG_LAINNYA') || '-'}</td>
                <td class="text-center">${k[0]}</td>
                <td class="text-center">${k[1]}</td>
                <td class="text-center">${k[2]}</td>
                <td class="text-center font-bold">${k[3]}</td>
                <td style="font-size:6.5pt;">${escapeHtml(item.ba || '-')}</td>
              </tr>
            `;
          });

          html += `
            <tr style="background:#f5f5f5; font-weight:bold;">
              <td colspan="3" class="text-right">Subtotal ${escapeHtml(tk.namaTaksa)}:</td>
              <td class="text-center">${sub.awal[0]}</td>
              <td class="text-center">${sub.awal[1]}</td>
              <td class="text-center">${sub.awal[2]}</td>
              <td class="text-center">${sub.awal[3]}</td>
              <td class="text-center">${sub.tambahDetail.lahir || '-'}</td>
              <td class="text-center">${sub.tambahDetail.tukar || '-'}</td>
              <td class="text-center">${sub.tambahDetail.titipan || '-'}</td>
              <td class="text-center">${sub.tambahDetail.pinjam || '-'}</td>
              <td class="text-center">${sub.tambahDetail.lain || '-'}</td>
              <td class="text-center">${sub.kurangDetail.mati || '-'}</td>
              <td class="text-center">${sub.kurangDetail.tukar || '-'}</td>
              <td class="text-center">${sub.kurangDetail.dipinjamkan || '-'}</td>
              <td class="text-center">${sub.kurangDetail.lepasliar || '-'}</td>
              <td class="text-center">${sub.kurangDetail.lain || '-'}</td>
              <td class="text-center">${sub.akhir[0]}</td>
              <td class="text-center">${sub.akhir[1]}</td>
              <td class="text-center">${sub.akhir[2]}</td>
              <td class="text-center">${sub.akhir[3]}</td>
              <td></td>
            </tr>
          `;
        });
      });

      if (!hasAny) {
        html += `<tr><td colspan="22" class="text-center" style="color:#666; font-style:italic; padding:8px;">Belum ada data ${statusMeta.label}.</td></tr>`;
      } else {
        html += `
          <tr style="background:#e5e7eb; font-weight:bold;">
            <td colspan="3" class="text-right">SUBTOTAL ${statusMeta.label.toUpperCase()}:</td>
            <td class="text-center">${bucket.awal[0]}</td>
            <td class="text-center">${bucket.awal[1]}</td>
            <td class="text-center">${bucket.awal[2]}</td>
            <td class="text-center">${bucket.awal[3]}</td>
            <td colspan="5" class="text-center">+${bucket.tambah}</td>
            <td colspan="5" class="text-center">-${bucket.kurang}</td>
            <td class="text-center">${bucket.akhir[0]}</td>
            <td class="text-center">${bucket.akhir[1]}</td>
            <td class="text-center">${bucket.akhir[2]}</td>
            <td class="text-center">${bucket.akhir[3]}</td>
            <td>${bucket.akhir[3].toLocaleString('id-ID')} Ekor</td>
          </tr>
        `;
      }
      return html;
    };

    const printHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Laporan Stok Satwa Koleksi LK (Dilindungi &amp; Tidak Dilindungi)</title>
        <style>
          @page { size: landscape; margin: 10mm; }
          body { font-family: Arial, sans-serif; font-size: 8pt; color: #000; margin: 0; padding: 10px; }
          h2, h3, h4 { margin: 2px 0; text-align: center; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 7.5pt; }
          th, td { border: 1px solid #000; padding: 3px 4px; }
          th { background-color: #f0f0f0; text-align: center; }
          .cat-hdr { background-color: #e5e5e5; font-weight: bold; text-align: left; }
          .sub-hdr { background-color: #f9f9f9; font-weight: bold; text-align: left; }
          .text-center { text-align: center; }
          .text-right { text-align: right; }
          .font-bold { font-weight: bold; }
        </style>
      </head>
      <body>
        <h3>LAPORAN STOK SATWA KOLEKSI LEMBAGA KONSERVASI</h3>
        <h2>${escapeHtml(LK_METADATA.namaLK || 'LEMBAGA KONSERVASI (LK)')}</h2>
        <h4>${escapeHtml(LK_METADATA.periodeLaporan || 'TAHUN 2026')} — Dilindungi &amp; Tidak Dilindungi</h4>
        <p style="text-align:center; font-size: 8pt; margin: 4px 0 12px;">Wilayah Kerja: Seksi Konservasi Wilayah I BKSDA Jakarta</p>

        <table>
          <thead>
            <tr>
              <th rowspan="3">No</th>
              <th colspan="2">Jenis Satwa</th>
              <th colspan="4">Jumlah Awal (Ekor)</th>
              <th colspan="10">Perkembangan Jumlah Satwa</th>
              <th colspan="4">Jumlah Akhir s/d Saat Ini (Ekor)</th>
              <th rowspan="3">Keterangan (No. dan Tgl BA)</th>
            </tr>
            <tr>
              <th rowspan="2">Nama Indonesia</th>
              <th rowspan="2">Nama Spesies</th>
              <th rowspan="2">J</th>
              <th rowspan="2">B</th>
              <th rowspan="2">?</th>
              <th rowspan="2">Σ</th>
              <th colspan="5">Penambahan</th>
              <th colspan="5">Pengurangan</th>
              <th rowspan="2">J</th>
              <th rowspan="2">B</th>
              <th rowspan="2">?</th>
              <th rowspan="2">Σ</th>
            </tr>
            <tr>
              <th>Lahir</th>
              <th>Tukar</th>
              <th>Titipan</th>
              <th>Pinjam</th>
              <th>Lain</th>
              <th>Mati</th>
              <th>Tukar</th>
              <th>Pinjam</th>
              <th>Lepas</th>
              <th>Lain</th>
            </tr>
          </thead>
          <tbody>
            ${buildPrintSectionRows(LK_STATUS_PERLINDUNGAN[0])}
            ${buildPrintSectionRows(LK_STATUS_PERLINDUNGAN[1])}
          </tbody>
          <tfoot>
            <tr style="background:#ddd; font-weight:bold; font-size:8pt;">
              <td colspan="3" class="text-right">TOTAL KESELURUHAN SATWA KOLEKSI LK (DILINDUNGI + TIDAK DILINDUNGI):</td>
              <td class="text-center">${stats.totalAwal[0]}</td>
              <td class="text-center">${stats.totalAwal[1]}</td>
              <td class="text-center">${stats.totalAwal[2]}</td>
              <td class="text-center">${stats.totalAwal[3]}</td>
              <td colspan="5" class="text-center">+${stats.totalTambah}</td>
              <td colspan="5" class="text-center">-${stats.totalKurang}</td>
              <td class="text-center">${stats.totalAkhir[0]}</td>
              <td class="text-center">${stats.totalAkhir[1]}</td>
              <td class="text-center">${stats.totalAkhir[2]}</td>
              <td class="text-center">${stats.totalAkhir[3]}</td>
              <td>${stats.totalAkhir[3].toLocaleString('id-ID')} Ekor</td>
            </tr>
          </tfoot>
        </table>
      </body>
      </html>
    `;

    const printFrame = document.createElement('iframe');
    printFrame.style.position = 'fixed';
    printFrame.style.right = '0';
    printFrame.style.bottom = '0';
    printFrame.style.width = '0';
    printFrame.style.height = '0';
    printFrame.style.border = '0';
    document.body.appendChild(printFrame);
    printFrame.contentWindow.document.open();
    printFrame.contentWindow.document.write(printHtml);
    printFrame.contentWindow.document.close();
    setTimeout(() => {
      printFrame.contentWindow.focus();
      printFrame.contentWindow.print();
      setTimeout(() => printFrame.remove(), 1500);
    }, 350);
  }

  // Helper mengisi dropdown satwa koleksi pada modal mutasi LK (difilter Dilindungi / Tidak Dilindungi)
  function populateMutasiLKSpeciesSelect(statusFilter = 'ALL', preselectKey = '') {
    const select = document.getElementById('lkInputSpesiesSelect');
    if (!select) return;
    const data = getLKData();
    select.innerHTML = '';

    const statusList = statusFilter === 'ALL'
      ? LK_STATUS_PERLINDUNGAN
      : LK_STATUS_PERLINDUNGAN.filter(s => s.slug === statusFilter);

    let totalOptions = 0;

    statusList.forEach(sMeta => {
      if (!data || !data.kategori) return;
      data.kategori
        .filter(kat => normalizePerlindunganSlug(kat.slug) === sMeta.slug)
        .forEach(kat => {
          (kat.taksa || []).forEach(tk => {
            const matching = tk.satwa || [];
            if (matching.length === 0) return;

            const group = document.createElement('optgroup');
            group.label = `[${sMeta.label}] ${tk.namaTaksa}`;
            matching.forEach(item => {
              const opt = document.createElement('option');
              const val = `${kat.slug}|${tk.slug}|${item.no}`;
              opt.value = val;
              const saldo = item.tempAkhir ? item.tempAkhir[3] : (item.akhir ? item.akhir[3] : 0);
              opt.textContent = `[${sMeta.shortLabel}] ${item.namaIndo} (${item.namaLatin}) — Saldo: ${saldo} ekor`;
              if (preselectKey && preselectKey === val) {
                opt.selected = true;
              }
              group.appendChild(opt);
              totalOptions++;
            });
            select.appendChild(group);
          });
        });
    });

    if (totalOptions === 0) {
      const emptyOpt = document.createElement('option');
      emptyOpt.value = '';
      emptyOpt.textContent = statusFilter === 'ALL'
        ? '-- Belum ada Satwa Koleksi LK terdaftar. Silakan Input Satwa Koleksi terlebih dahulu --'
        : `-- Belum ada ${getPerlindunganMeta(statusFilter).label} terdaftar --`;
      select.appendChild(emptyOpt);
    }
  }

  function handleMutasiStatusFilterChange(val) {
    activeMutasiModalStatusFilter = (val === 'dilindungi' || val === 'tidak_dilindungi') ? val : 'ALL';
    populateMutasiLKSpeciesSelect(activeMutasiModalStatusFilter, '');
  }

  // Alias kompatibilitas mundur
  function handleMutasiJenisFilterChange(val) {
    handleMutasiStatusFilterChange(val);
  }

  // 10. Modal Tambah Mutasi Satwa Koleksi LK
  function openModalTambahMutasiLK(preselectKey = '') {
    if (typeof window.requireEditAccess === 'function' && !window.requireEditAccess(() => openModalTambahMutasiLK(preselectKey), 'Catat Mutasi Satwa Koleksi LK')) {
      return;
    }
    let modal = document.getElementById('modalTambahMutasiLK');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'modalTambahMutasiLK';
      modal.className = 'fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden';
      modal.innerHTML = `
        <div class="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200">
          <div class="bg-gradient-to-r from-emerald-900 to-teal-900 text-white p-5 flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center">
                <i data-lucide="plus-circle" class="w-5 h-5"></i>
              </div>
              <div>
                <h4 class="font-bold text-sm">Catat Mutasi Satwa Koleksi LK</h4>
                <p class="text-[11px] text-emerald-200">Mutasi Satwa Koleksi Dilindungi &amp; Tidak Dilindungi</p>
              </div>
            </div>
            <button type="button" onclick="window.LKSatwaModule.closeModalTambahMutasiLK()" class="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition">
              <i data-lucide="x" class="w-4 h-4"></i>
            </button>
          </div>
          <form id="formTambahMutasiLK" onsubmit="window.LKSatwaModule.handleSaveMutasiLK(event)" class="p-6 space-y-4 text-xs">
            <div>
              <label class="block font-semibold mb-1 text-slate-700">Filter Status Perlindungan Satwa Koleksi</label>
              <select id="lkMutasiStatusFilter" onchange="window.LKSatwaModule.handleMutasiStatusFilterChange(this.value)" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-semibold text-slate-800">
                <option value="ALL">Semua Satwa Koleksi (Dilindungi &amp; Tidak Dilindungi)</option>
                <option value="dilindungi">Satwa Koleksi Dilindungi</option>
                <option value="tidak_dilindungi">Satwa Koleksi Tidak Dilindungi</option>
              </select>
            </div>

            <div>
              <label class="block font-semibold mb-1 text-slate-700">Pilih Satwa Koleksi LK *</label>
              <select id="lkInputSpesiesSelect" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-semibold text-slate-800">
                <!-- Diisi otomatis -->
              </select>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold mb-1 text-slate-700">Jenis Mutasi *</label>
                <select id="lkInputTipeMutasi" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                  <option value="TAMBAH_LAHIR">Penambahan - Lahir</option>
                  <option value="TAMBAH_TUKAR">Penambahan - Tukar/Hibah</option>
                  <option value="TAMBAH_TITIPAN">Penambahan - Titipan BKSDA</option>
                  <option value="TAMBAH_PINJAM">Penambahan - Pinjam</option>
                  <option value="TAMBAH_LAINNYA">Penambahan - Lainnya</option>
                  <option value="KURANG_MATI">Pengurangan - Mati</option>
                  <option value="KURANG_TUKAR">Pengurangan - Tukar/Hibah</option>
                  <option value="KURANG_DIPINJAMKAN">Pengurangan - Dipinjamkan</option>
                  <option value="KURANG_LEPASLIAR">Pengurangan - Lepasliar</option>
                  <option value="KURANG_LAINNYA">Pengurangan - Lainnya</option>
                </select>
              </div>

              <div>
                <label class="block font-semibold mb-1 text-slate-700">Jenis Kelamin *</label>
                <select id="lkInputKelamin" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
                  <option value="unsexed">Belum Diketahui / Unsexed (?)</option>
                  <option value="jantan">Jantan (J)</option>
                  <option value="betina">Betina (B)</option>
                </select>
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-semibold mb-1 text-slate-700">Jumlah Spesimen (Ekor) *</label>
                <input type="number" id="lkInputJumlah" min="1" value="1" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono font-bold">
              </div>

              <div>
                <label class="block font-semibold mb-1 text-slate-700">Tanggal Kegiatan *</label>
                <input type="text" id="lkInputTanggal" required placeholder="Pilih tanggal dari kalender..." autocomplete="off" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500">
              </div>
            </div>

            <div>
              <label class="block font-semibold mb-1 text-slate-700">Nomor Berita Acara (BA) / Dokumen Dasar *</label>
              <input type="text" id="lkInputNomorBA" required placeholder="Contoh: BA.225/K.13/TU/KSA.03.01/B/08/2026" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono">
            </div>

            <div>
              <label class="block font-semibold mb-1 text-slate-700">Keterangan / Kronologi Mutasi</label>
              <textarea id="lkInputKeterangan" rows="2" placeholder="Catatan kondisi kesehatan, hasil autopsi, sumber perolehan..." class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500"></textarea>
            </div>

            <div class="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
              <button type="button" onclick="window.LKSatwaModule.closeModalTambahMutasiLK()" class="px-4 py-2 border border-slate-300 rounded-xl text-slate-600 hover:bg-slate-50 font-medium">Batal</button>
              <button type="submit" class="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl font-bold transition shadow-sm">Simpan Mutasi</button>
            </div>
          </form>
        </div>
      `;
      document.body.appendChild(modal);

      // Pasang kalender interaktif Indonesia pada input tanggal mutasi LK
      if (typeof window.attachNexsdaCalendarToInput === 'function') {
        window.attachNexsdaCalendarToInput({ id: 'lkInputTanggal', allowRange: false, allowClear: false, compact: false });
      }
    }

    const form = document.getElementById('formTambahMutasiLK');
    if (form) form.reset();

    // Tentukan filter awal status perlindungan
    let initialFilter = activeLKFilterPerlindungan;
    if (preselectKey) {
      const [katSlug] = String(preselectKey).split('|');
      if (katSlug === 'dilindungi' || katSlug === 'tidak_dilindungi') {
        initialFilter = katSlug;
      }
    }
    activeMutasiModalStatusFilter = initialFilter || 'ALL';
    const filterSel = document.getElementById('lkMutasiStatusFilter');
    if (filterSel) filterSel.value = activeMutasiModalStatusFilter;

    populateMutasiLKSpeciesSelect(activeMutasiModalStatusFilter, preselectKey);

    const tglInput = document.getElementById('lkInputTanggal');
    if (tglInput) {
      tglInput.value = typeof window.formatDateObjToIndo === 'function'
        ? window.formatDateObjToIndo(new Date())
        : new Date().toISOString().split('T')[0];
    }
    modal.classList.remove('hidden');
    if (window.lucide) lucide.createIcons();
  }

  function closeModalTambahMutasiLK() {
    const modal = document.getElementById('modalTambahMutasiLK');
    if (modal) modal.classList.add('hidden');
  }

  function handleSaveMutasiLK(event) {
    event.preventDefault();
    if (typeof window.requireEditAccess === 'function' && !window.requireEditAccess(null, 'Simpan Mutasi Satwa Koleksi LK')) {
      return;
    }
    const selectVal = document.getElementById('lkInputSpesiesSelect').value;
    if (!selectVal) {
      notifyLK('Peringatan', 'Silakan pilih Satwa Koleksi LK terlebih dahulu (atau tambahkan satwa baru).');
      return;
    }
    const [katSlug, tkSlug, itemNoStr] = selectVal.split('|');
    const itemNo = parseInt(itemNoStr, 10);
    const tipeMutasi = document.getElementById('lkInputTipeMutasi').value;
    const kelamin = document.getElementById('lkInputKelamin').value;
    const jumlah = parseInt(document.getElementById('lkInputJumlah').value, 10) || 1;
    const noBA = document.getElementById('lkInputNomorBA').value.trim();

    const data = getLKData();
    const targetKat = data.kategori.find(k => k.slug === katSlug);
    const targetTk = targetKat?.taksa.find(t => t.slug === tkSlug);
    const targetSatwa = targetTk?.satwa.find(s => s.no === itemNo);

    if (!targetSatwa) {
      notifyLK('Error', 'Data Satwa Koleksi LK tidak ditemukan.');
      return;
    }

    const rawTanggal = document.getElementById('lkInputTanggal').value.trim();
    const parsedTgl = parseLKDate(rawTanggal);
    const tanggal = parsedTgl
      ? `${parsedTgl.getFullYear()}-${String(parsedTgl.getMonth() + 1).padStart(2, '0')}-${String(parsedTgl.getDate()).padStart(2, '0')}`
      : rawTanggal;
    const keterangan = document.getElementById('lkInputKeterangan').value.trim();

    if (!Array.isArray(targetSatwa.mutasiLog)) targetSatwa.mutasiLog = [];

    targetSatwa.mutasiLog.push({
      tanggal,
      tipe: tipeMutasi,
      kelamin,
      jumlah,
      noBA,
      keterangan
    });

    // Sinkronkan saldo akhir kumulatif untuk pratinjau cepat
    const colIdx = kelamin === 'jantan' ? 0 : (kelamin === 'betina' ? 1 : 2);
    if (!Array.isArray(targetSatwa.akhir) || targetSatwa.akhir.length < 4) {
      targetSatwa.akhir = [...(targetSatwa.awal || [0, 0, 0, 0])];
    }
    if (tipeMutasi.startsWith('TAMBAH_')) {
      targetSatwa.akhir[colIdx] += jumlah;
      targetSatwa.akhir[3] += jumlah;
    } else {
      targetSatwa.akhir[colIdx] = Math.max(0, targetSatwa.akhir[colIdx] - jumlah);
      targetSatwa.akhir[3] = Math.max(0, targetSatwa.akhir[3] - jumlah);
    }
    targetSatwa.jenisStok = 'koleksi';
    if (noBA) targetSatwa.ba = noBA;

    saveLKData();
    closeModalTambahMutasiLK();
    refreshLKViews();

    const statusLabel = getPerlindunganMeta(katSlug).label;
    notifyLK('Mutasi LK Disimpan', `Mutasi ${statusLabel} (${targetSatwa.namaIndo}) berhasil disimpan.`);
  }

  // Helper highlight kartu pilihan Satwa Koleksi Dilindungi / Tidak Dilindungi di Modal Input Satwa Baru
  function updateNewSatwaStatusCards(selectedStatus) {
    const isTidak = selectedStatus === 'tidak_dilindungi';
    const cardDilindungi = document.getElementById('newSatwaCardDilindungi');
    const cardTidak = document.getElementById('newSatwaCardTidakDilindungi');
    const radioDilindungi = document.getElementById('newSatwaStatusDilindungi');
    const radioTidak = document.getElementById('newSatwaStatusTidakDilindungi');

    if (radioDilindungi) radioDilindungi.checked = !isTidak;
    if (radioTidak) radioTidak.checked = isTidak;

    if (cardDilindungi && cardTidak) {
      if (isTidak) {
        cardDilindungi.className = 'flex items-start gap-2.5 p-3 rounded-2xl border-2 border-slate-200 bg-white cursor-pointer transition hover:border-indigo-400';
        cardTidak.className = 'flex items-start gap-2.5 p-3 rounded-2xl border-2 border-teal-600 bg-teal-50/70 cursor-pointer transition hover:border-teal-700';
      } else {
        cardDilindungi.className = 'flex items-start gap-2.5 p-3 rounded-2xl border-2 border-indigo-500 bg-indigo-50/70 cursor-pointer transition hover:border-indigo-600';
        cardTidak.className = 'flex items-start gap-2.5 p-3 rounded-2xl border-2 border-slate-200 bg-white cursor-pointer transition hover:border-teal-400';
      }
    }
  }

  // Alias kompatibilitas mundur
  function updateNewSatwaJenisCards(val) {
    updateNewSatwaStatusCards(val === 'tidak_dilindungi' ? 'tidak_dilindungi' : 'dilindungi');
  }

  // 11. Modal Input Satwa Koleksi Baru ke Database LK (Dilindungi / Tidak Dilindungi)
  function openModalTambahSatwaBaru(defaultStatus) {
    if (typeof window.requireEditAccess === 'function' && !window.requireEditAccess(() => openModalTambahSatwaBaru(defaultStatus), 'Input Satwa Koleksi LK')) {
      return;
    }
    let modal = document.getElementById('modalTambahSatwaBaruLK');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'modalTambahSatwaBaruLK';
      modal.className = 'fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden';
      modal.innerHTML = `
        <div class="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-200">
            <div class="flex items-center gap-2.5">
              <div class="w-9 h-9 rounded-xl bg-indigo-700 text-white flex items-center justify-center shadow-xs">
                <i data-lucide="plus-circle" class="w-5 h-5"></i>
              </div>
              <div>
                <h3 class="font-bold text-slate-900 text-base">Input Satwa Koleksi LK</h3>
                <p class="text-xs text-slate-500">Rekam Satwa Koleksi Dilindungi atau Tidak Dilindungi ke Buku Stok LK</p>
              </div>
            </div>
            <button type="button" onclick="window.LKSatwaModule.closeModalTambahSatwaBaru()" class="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition">
              <i data-lucide="x" class="w-4 h-4"></i>
            </button>
          </div>

          <form id="formTambahSatwaBaruLK" onsubmit="window.LKSatwaModule.handleSaveSatwaBaru(event)" class="space-y-3.5 text-xs">
            <!-- Pilihan Status Perlindungan Satwa Koleksi LK -->
            <div>
              <label class="block font-bold mb-1.5 text-slate-700">Status Perlindungan Satwa Koleksi *</label>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <label id="newSatwaCardDilindungi" class="flex items-start gap-2.5 p-3 rounded-2xl border-2 border-indigo-500 bg-indigo-50/70 cursor-pointer transition hover:border-indigo-600">
                  <input type="radio" id="newSatwaStatusDilindungi" name="newSatwaStatusPerlindungan" value="dilindungi" checked onchange="window.LKSatwaModule.updateNewSatwaStatusCards('dilindungi')" class="mt-0.5 accent-indigo-700 w-4 h-4 shrink-0">
                  <div>
                    <div class="font-bold text-indigo-950 text-xs">Koleksi Dilindungi</div>
                    <p class="text-[10.5px] text-slate-600 leading-snug mt-0.5">Satwa koleksi dilindungi undang-undang (P.106/KLHK).</p>
                  </div>
                </label>

                <label id="newSatwaCardTidakDilindungi" class="flex items-start gap-2.5 p-3 rounded-2xl border-2 border-slate-200 bg-white cursor-pointer transition hover:border-teal-400">
                  <input type="radio" id="newSatwaStatusTidakDilindungi" name="newSatwaStatusPerlindungan" value="tidak_dilindungi" onchange="window.LKSatwaModule.updateNewSatwaStatusCards('tidak_dilindungi')" class="mt-0.5 accent-teal-600 w-4 h-4 shrink-0">
                  <div>
                    <div class="font-bold text-teal-950 text-xs">Koleksi Tidak Dilindungi</div>
                    <p class="text-[10.5px] text-slate-600 leading-snug mt-0.5">Satwa koleksi tidak dilindungi UU &amp; satwa eksotik.</p>
                  </div>
                </label>
              </div>
            </div>

            <div>
              <label class="block font-semibold mb-1 text-slate-700">Taksa Satwa *</label>
              <select id="newSatwaTaksa" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-semibold">
                <option value="mamalia">Mamalia</option>
                <option value="aves">Aves</option>
                <option value="reptilia">Reptilia</option>
                <option value="amphibi">Amphibi</option>
                <option value="crustacea">Crustacea</option>
              </select>
            </div>

            <div>
              <label class="block font-semibold mb-1 text-slate-700">Nama Indonesia *</label>
              <input type="text" id="newSatwaNamaIndo" required placeholder="Contoh: Elang bondol, Kakatua jambul kuning..." class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium">
            </div>

            <div>
              <label class="block font-semibold mb-1 text-slate-700">Nama Spesies (Ilmiah/Latin) *</label>
              <input type="text" id="newSatwaNamaLatin" required placeholder="Contoh: Haliastur indus, Cacatua sulphurea..." class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-serif italic">
            </div>

            <div>
              <label class="block font-semibold mb-1 text-slate-700">Jumlah Saldo Awal (Ekor) *</label>
              <div class="grid grid-cols-3 gap-2">
                <div>
                  <span class="text-[10px] text-slate-500 block mb-0.5">Jantan (J):</span>
                  <input type="number" id="newSatwaJantan" min="0" value="0" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
                </div>
                <div>
                  <span class="text-[10px] text-slate-500 block mb-0.5">Betina (B):</span>
                  <input type="number" id="newSatwaBetina" min="0" value="0" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
                </div>
                <div>
                  <span class="text-[10px] text-slate-500 block mb-0.5">Unsexed (?):</span>
                  <input type="number" id="newSatwaUnsexed" min="0" value="1" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
                </div>
              </div>
            </div>

            <div>
              <label class="block font-semibold mb-1 text-slate-700">Nomor Berita Acara (BA) / Dokumen Dasar</label>
              <input type="text" id="newSatwaBA" placeholder="Contoh: BA.225/K.13/TU/KSA.03.01/B/08/2026" class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono">
            </div>

            <div class="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
              <button type="button" onclick="window.LKSatwaModule.closeModalTambahSatwaBaru()" class="px-4 py-2 border border-slate-300 rounded-xl text-slate-600 hover:bg-slate-50 font-medium">Batal</button>
              <button type="submit" class="px-5 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded-xl font-bold transition shadow-sm">Simpan ke Stok Koleksi LK</button>
            </div>
          </form>
        </div>
      `;
      document.body.appendChild(modal);
    }

    const form = document.getElementById('formTambahSatwaBaruLK');
    if (form) form.reset();

    const targetStatus = (defaultStatus === 'dilindungi' || defaultStatus === 'tidak_dilindungi')
      ? defaultStatus
      : (activeLKFilterPerlindungan === 'tidak_dilindungi' ? 'tidak_dilindungi' : 'dilindungi');
    updateNewSatwaStatusCards(targetStatus);

    modal.classList.remove('hidden');
    if (window.lucide) lucide.createIcons();
  }

  function closeModalTambahSatwaBaru() {
    const modal = document.getElementById('modalTambahSatwaBaruLK');
    if (modal) modal.classList.add('hidden');
  }

  function handleSaveSatwaBaru(event) {
    event.preventDefault();
    if (typeof window.requireEditAccess === 'function' && !window.requireEditAccess(null, 'Simpan Satwa Koleksi Baru LK')) {
      return;
    }
    const statusRadio = document.querySelector('input[name="newSatwaStatusPerlindungan"]:checked');
    const katSlug = normalizePerlindunganSlug(statusRadio ? statusRadio.value : 'dilindungi');
    const tkSlug = document.getElementById('newSatwaTaksa').value;
    const namaIndo = document.getElementById('newSatwaNamaIndo').value.trim();
    const namaLatin = document.getElementById('newSatwaNamaLatin').value.trim();
    const j = parseInt(document.getElementById('newSatwaJantan').value, 10) || 0;
    const b = parseInt(document.getElementById('newSatwaBetina').value, 10) || 0;
    const u = parseInt(document.getElementById('newSatwaUnsexed').value, 10) || 0;
    const sum = j + b + u;
    const ba = document.getElementById('newSatwaBA').value.trim();

    const data = getLKData();
    const statusMeta = getPerlindunganMeta(katSlug);
    let targetKat = data.kategori.find(k => k.slug === katSlug);
    if (!targetKat) {
      targetKat = {
        namaKategori: statusMeta.namaKategori,
        slug: katSlug,
        taksa: []
      };
      data.kategori.push(targetKat);
    }

    let targetTk = targetKat.taksa.find(t => t.slug === tkSlug || (tkSlug === 'reptilia' && t.slug === 'reptil'));
    if (!targetTk) {
      targetTk = {
        namaTaksa: tkSlug.toUpperCase(),
        slug: tkSlug,
        satwa: []
      };
      targetKat.taksa.push(targetTk);
    }

    const nextNo = targetTk.satwa.reduce((maxNo, s) => Math.max(maxNo, parseInt(s.no, 10) || 0), 0) + 1;
    targetTk.satwa.push({
      no: nextNo,
      jenisStok: 'koleksi',
      namaIndo: namaIndo,
      namaLatin: namaLatin,
      awal: [j, b, u, sum],
      tambah: {},
      kurang: {},
      akhir: [j, b, u, sum],
      mutasiLog: [],
      ba: ba
    });

    saveLKData();
    closeModalTambahSatwaBaru();
    refreshLKViews();

    notifyLK('Satwa Koleksi Tersimpan', `${namaIndo} berhasil disimpan ke ${statusMeta.label}.`);
  }

  // 12. Modal Edit Data Baris Satwa Koleksi LK (Termasuk Pilihan Pindah Dilindungi <-> Tidak Dilindungi)
  function openModalEditSatwaRow(katSlug, tkSlug, itemNo) {
    if (typeof window.requireEditAccess === 'function' && !window.requireEditAccess(() => openModalEditSatwaRow(katSlug, tkSlug, itemNo), 'Edit Data Satwa Koleksi LK')) {
      return;
    }
    const data = getLKData();
    const targetKat = data.kategori.find(k => k.slug === katSlug);
    const targetTk = targetKat?.taksa.find(t => t.slug === tkSlug || (tkSlug === 'reptil' && t.slug === 'reptilia') || (tkSlug === 'reptilia' && t.slug === 'reptil'));
    const satwa = targetTk?.satwa.find(s => s.no === itemNo);
    if (!satwa) return;

    const currentStatus = normalizePerlindunganSlug(katSlug);

    let modal = document.getElementById('modalEditSatwaRowLK');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'modalEditSatwaRowLK';
      modal.className = 'fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden';
      document.body.appendChild(modal);
    }

    modal.innerHTML = `
      <div class="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] overflow-y-auto p-6 shadow-2xl border border-slate-200 space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-200">
          <div class="flex items-center gap-2.5">
            <div class="w-9 h-9 rounded-xl bg-emerald-700 text-white flex items-center justify-center">
              <i data-lucide="edit-3" class="w-5 h-5"></i>
            </div>
            <div>
              <h3 class="font-bold text-slate-900 text-base">Edit Data Satwa Koleksi LK</h3>
              <p class="text-xs text-slate-500 font-serif italic">${escapeHtml(satwa.namaIndo)} (${escapeHtml(satwa.namaLatin)})</p>
            </div>
          </div>
          <button type="button" onclick="window.LKSatwaModule.closeModalEditSatwaRow()" class="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition">
            <i data-lucide="x" class="w-4 h-4"></i>
          </button>
        </div>

        <form onsubmit="window.LKSatwaModule.handleSaveEditSatwaRow(event, '${escapeHtml(katSlug)}', '${escapeHtml(tkSlug)}', ${itemNo})" class="space-y-3.5 text-xs">
          <div>
            <label class="block font-semibold mb-1 text-slate-700">Status Perlindungan Satwa Koleksi *</label>
            <select id="editSatwaStatusPerlindungan" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-bold text-slate-800">
              <option value="dilindungi" ${currentStatus === 'dilindungi' ? 'selected' : ''}>Satwa Koleksi Dilindungi (UU)</option>
              <option value="tidak_dilindungi" ${currentStatus === 'tidak_dilindungi' ? 'selected' : ''}>Satwa Koleksi Tidak Dilindungi</option>
            </select>
          </div>

          <div>
            <label class="block font-semibold mb-1 text-slate-700">Nama Indonesia *</label>
            <input type="text" id="editSatwaNamaIndo" value="${escapeHtml(satwa.namaIndo)}" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-medium">
          </div>

          <div>
            <label class="block font-semibold mb-1 text-slate-700">Nama Spesies (Latin) *</label>
            <input type="text" id="editSatwaNamaLatin" value="${escapeHtml(satwa.namaLatin)}" required class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-serif italic">
          </div>

          <div>
            <label class="block font-semibold mb-1 text-slate-700">Saldo Awal (Ekor) *</label>
            <div class="grid grid-cols-3 gap-2">
              <div>
                <span class="text-[10px] text-slate-500 block mb-0.5">Jantan:</span>
                <input type="number" id="editSatwaAwalJ" min="0" value="${satwa.awal[0]}" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
              </div>
              <div>
                <span class="text-[10px] text-slate-500 block mb-0.5">Betina:</span>
                <input type="number" id="editSatwaAwalB" min="0" value="${satwa.awal[1]}" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
              </div>
              <div>
                <span class="text-[10px] text-slate-500 block mb-0.5">Unsexed (?):</span>
                <input type="number" id="editSatwaAwalU" min="0" value="${satwa.awal[2]}" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
              </div>
            </div>
          </div>

          <div>
            <label class="block font-semibold mb-1 text-slate-700">Saldo Akhir (Ekor) *</label>
            <div class="grid grid-cols-3 gap-2">
              <div>
                <span class="text-[10px] text-slate-500 block mb-0.5">Jantan:</span>
                <input type="number" id="editSatwaAkhirJ" min="0" value="${satwa.akhir[0]}" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
              </div>
              <div>
                <span class="text-[10px] text-slate-500 block mb-0.5">Betina:</span>
                <input type="number" id="editSatwaAkhirB" min="0" value="${satwa.akhir[1]}" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
              </div>
              <div>
                <span class="text-[10px] text-slate-500 block mb-0.5">Unsexed (?):</span>
                <input type="number" id="editSatwaAkhirU" min="0" value="${satwa.akhir[2]}" class="w-full px-2 py-1.5 text-center font-mono font-bold bg-slate-50 border border-slate-200 rounded-lg">
              </div>
            </div>
          </div>

          <div>
            <label class="block font-semibold mb-1 text-slate-700">Nomor &amp; Tanggal Berita Acara (BA)</label>
            <input type="text" id="editSatwaBA" value="${escapeHtml(satwa.ba || '')}" placeholder="BA.225/K.13/..." class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono">
          </div>

          <div class="pt-3 border-t border-slate-200 flex items-center justify-between gap-2">
            <button type="button" onclick="window.LKSatwaModule.deleteSatwaRowLK('${escapeHtml(katSlug)}', '${escapeHtml(tkSlug)}', ${itemNo})" class="px-3.5 py-2 border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-xl font-semibold transition flex items-center gap-1">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i> Hapus Baris
            </button>
            <div class="flex items-center gap-2">
              <button type="button" onclick="window.LKSatwaModule.closeModalEditSatwaRow()" class="px-4 py-2 border border-slate-300 rounded-xl text-slate-600 hover:bg-slate-50 font-medium">Batal</button>
              <button type="submit" class="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl font-bold transition shadow-sm">Simpan Perubahan</button>
            </div>
          </div>
        </form>
      </div>
    `;
    modal.classList.remove('hidden');
    if (window.lucide) lucide.createIcons();
  }

  function closeModalEditSatwaRow() {
    const modal = document.getElementById('modalEditSatwaRowLK');
    if (modal) modal.classList.add('hidden');
  }

  function handleSaveEditSatwaRow(event, katSlug, tkSlug, itemNo) {
    event.preventDefault();
    if (typeof window.requireEditAccess === 'function' && !window.requireEditAccess(null, 'Simpan Perubahan Data Satwa Koleksi LK')) {
      return;
    }
    const data = getLKData();
    const targetKat = data.kategori.find(k => k.slug === katSlug);
    const targetTk = targetKat?.taksa.find(t => t.slug === tkSlug || (tkSlug === 'reptil' && t.slug === 'reptilia') || (tkSlug === 'reptilia' && t.slug === 'reptil'));
    const satwaIdx = targetTk ? targetTk.satwa.findIndex(s => s.no === itemNo) : -1;
    if (satwaIdx < 0) return;
    const satwa = targetTk.satwa[satwaIdx];

    const newStatus = normalizePerlindunganSlug(document.getElementById('editSatwaStatusPerlindungan')?.value || katSlug);
    const namaIndo = document.getElementById('editSatwaNamaIndo').value.trim();
    const namaLatin = document.getElementById('editSatwaNamaLatin').value.trim();
    const aj = parseInt(document.getElementById('editSatwaAwalJ').value, 10) || 0;
    const ab = parseInt(document.getElementById('editSatwaAwalB').value, 10) || 0;
    const au = parseInt(document.getElementById('editSatwaAwalU').value, 10) || 0;
    const kj = parseInt(document.getElementById('editSatwaAkhirJ').value, 10) || 0;
    const kb = parseInt(document.getElementById('editSatwaAkhirB').value, 10) || 0;
    const ku = parseInt(document.getElementById('editSatwaAkhirU').value, 10) || 0;
    const ba = document.getElementById('editSatwaBA').value.trim();

    satwa.jenisStok = 'koleksi';
    satwa.namaIndo = namaIndo;
    satwa.namaLatin = namaLatin;
    satwa.awal = [aj, ab, au, aj + ab + au];
    satwa.akhir = [kj, kb, ku, kj + kb + ku];
    satwa.ba = ba;

    // Jika status perlindungan diubah (Dilindungi <-> Tidak Dilindungi), pindahkan baris dengan aman sambil mempertahankan riwayat mutasi
    if (newStatus !== normalizePerlindunganSlug(katSlug)) {
      targetTk.satwa.splice(satwaIdx, 1);
      const destMeta = getPerlindunganMeta(newStatus);
      let destKat = data.kategori.find(k => k.slug === newStatus);
      if (!destKat) {
        destKat = { namaKategori: destMeta.namaKategori, slug: newStatus, taksa: [] };
        data.kategori.push(destKat);
      }
      const normTkSlug = tkSlug === 'reptil' ? 'reptilia' : tkSlug;
      let destTk = destKat.taksa.find(t => t.slug === normTkSlug || (normTkSlug === 'reptilia' && t.slug === 'reptil'));
      if (!destTk) {
        destTk = { namaTaksa: targetTk.namaTaksa || normTkSlug.toUpperCase(), slug: normTkSlug, satwa: [] };
        destKat.taksa.push(destTk);
      }
      const nextNo = destTk.satwa.reduce((maxNo, s) => Math.max(maxNo, parseInt(s.no, 10) || 0), 0) + 1;
      satwa.no = nextNo;
      destTk.satwa.push(satwa);
    }

    saveLKData();
    closeModalEditSatwaRow();
    refreshLKViews();
    notifyLK('Perubahan Disimpan', `Data ${namaIndo} (${getPerlindunganMeta(newStatus).label}) berhasil diperbarui.`);
  }

  function deleteSatwaRowLK(katSlug, tkSlug, itemNo) {
    if (typeof window.requireEditAccess === 'function' && !window.requireEditAccess(() => deleteSatwaRowLK(katSlug, tkSlug, itemNo), 'Hapus Data Satwa Koleksi LK')) {
      return;
    }
    const data = getLKData();
    const targetKat = data.kategori.find(k => k.slug === katSlug);
    const targetTk = targetKat?.taksa.find(t => t.slug === tkSlug || (tkSlug === 'reptil' && t.slug === 'reptilia') || (tkSlug === 'reptilia' && t.slug === 'reptil'));
    if (!targetTk) return;
    const idx = targetTk.satwa.findIndex(s => s.no === itemNo);
    if (idx < 0) return;

    const removed = targetTk.satwa[idx];
    if (!confirm(`Hapus satwa "${removed.namaIndo}" dari stok ${getPerlindunganMeta(katSlug).label} LK?`)) {
      return;
    }
    targetTk.satwa.splice(idx, 1);
    saveLKData();
    closeModalEditSatwaRow();
    refreshLKViews();
    notifyLK('Data Dihapus', `Satwa Koleksi ${removed.namaIndo} telah dihapus dari stok LK.`);
  }

  // Helper membangun isi tbody untuk satu kategori Satwa Koleksi (Dilindungi atau Tidak Dilindungi)
  function buildLKSectionTableRows(data, stats, statusMeta) {
    const filteredTaksa = getFilteredTaksaForKategori(data, statusMeta.slug);
    const isDilindungi = statusMeta.slug === 'dilindungi';
    const bucket = isDilindungi ? stats.dilindungiStats : stats.tidakDilindungiStats;

    let html = `
      <tr class="${statusMeta.headerClass} font-black text-xs uppercase tracking-wider">
        <td colspan="23" class="py-2.5 px-3.5 border ${isDilindungi ? 'border-indigo-900' : 'border-teal-800'}">
          <div class="flex flex-wrap items-center justify-between gap-2">
            <div class="flex items-center gap-2">
              <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-black ${isDilindungi ? 'bg-indigo-400 text-indigo-950' : 'bg-teal-300 text-teal-950'}">${statusMeta.shortLabel.toUpperCase()}</span>
              <span>${statusMeta.sectionTitle}</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="font-mono text-[10.5px] bg-white/15 px-2.5 py-0.5 rounded-lg font-bold">
                ${bucket.spesies} Jenis • ${bucket.akhir[3].toLocaleString('id-ID')} Ekor
              </span>
              <button type="button" onclick="window.LKSatwaModule.openModalTambahSatwaBaru('${statusMeta.slug}')" class="px-2.5 py-1 rounded-lg text-[10px] font-bold ${isDilindungi ? 'bg-indigo-500 hover:bg-indigo-400 text-white' : 'bg-teal-500 hover:bg-teal-400 text-teal-950'} transition flex items-center gap-1">
                <i data-lucide="plus" class="w-3 h-3"></i> Tambah ${statusMeta.shortLabel}
              </button>
            </div>
          </div>
        </td>
      </tr>
    `;

    if (filteredTaksa.length === 0) {
      const emptyMsg = bucket.spesies === 0
        ? `Belum ada data <b>${statusMeta.label}</b> terdaftar. Klik tombol <b>"+ Tambah ${statusMeta.shortLabel}"</b> di kanan untuk menambahkan.`
        : `Tidak ada data <b>${statusMeta.label}</b> yang sesuai filter atau pencarian saat ini.`;

      html += `
        <tr class="bg-slate-50/70">
          <td colspan="23" class="py-6 px-4 text-center text-slate-500 text-xs border-b border-slate-200">
            ${emptyMsg}
          </td>
        </tr>
      `;
      return html;
    }

    let sectionAwal = [0, 0, 0, 0];
    let sectionAkhir = [0, 0, 0, 0];
    const sectionTambahDetail = { lahir: 0, tukar: 0, titipan: 0, pinjam: 0, lain: 0 };
    const sectionKurangDetail = { mati: 0, tukar: 0, dipinjamkan: 0, lepasliar: 0, lain: 0 };

    filteredTaksa.forEach(tk => {
      const tkSubtotal = calculateTaksaSubtotal(tk.satwa);
      for (let i = 0; i < 4; i++) {
        sectionAwal[i] += tkSubtotal.awal[i];
        sectionAkhir[i] += tkSubtotal.akhir[i];
      }
      Object.keys(sectionTambahDetail).forEach(k => { sectionTambahDetail[k] += tkSubtotal.tambahDetail[k]; });
      Object.keys(sectionKurangDetail).forEach(k => { sectionKurangDetail[k] += tkSubtotal.kurangDetail[k]; });

      html += `
        <tr class="bg-emerald-800 text-emerald-50 font-bold text-[11px] uppercase tracking-wide">
          <td colspan="23" class="py-1.5 px-3 border border-emerald-700">
            ${escapeHtml(tk.namaTaksa)} <span class="text-[10px] opacity-80 font-normal">(${tk.satwa.length} jenis • ${statusMeta.label}: ${tkSubtotal.akhir[3]} ekor)</span>
          </td>
        </tr>
      `;

      tk.satwa.forEach((item, rowIdx) => {
        const hasMutasi = item.tempMutasi && item.tempMutasi.length > 0;
        const rowBg = hasMutasi ? 'bg-amber-50/70 font-semibold' : 'hover:bg-slate-50';

        const getMutasiTotal = (tipe) => {
          return (item.tempMutasi || [])
            .filter(m => m.tipe === tipe)
            .reduce((sum, m) => sum + (parseInt(m.jumlah, 10) || 0), 0);
        };

        const tLahir = getMutasiTotal('TAMBAH_LAHIR');
        const tTukar = getMutasiTotal('TAMBAH_TUKAR');
        const tTitip = getMutasiTotal('TAMBAH_TITIPAN');
        const tPinjam = getMutasiTotal('TAMBAH_PINJAM');
        const tLain = getMutasiTotal('TAMBAH_LAINNYA');

        const kMati = getMutasiTotal('KURANG_MATI');
        const kTukar = getMutasiTotal('KURANG_TUKAR');
        const kDipinjamkan = getMutasiTotal('KURANG_DIPINJAMKAN');
        const kLepas = getMutasiTotal('KURANG_LEPASLIAR');
        const kLain = getMutasiTotal('KURANG_LAINNYA');

        const ba = item.tempMutasi && item.tempMutasi.length > 0
          ? item.tempMutasi[item.tempMutasi.length - 1].noBA
          : (item.ba || '-');
        const baEsc = escapeHtml(ba);
        const baCell = ba && ba !== '-'
          ? `<button type="button" onclick="window.LKSatwaModule.openModalBADetail('${baEsc.replace(/'/g, "\\'")}')" class="text-left text-[9.5px] font-mono text-indigo-700 hover:text-indigo-900 hover:underline leading-tight flex items-center gap-1 group">
               <i data-lucide="file-text" class="w-3 h-3 text-indigo-500 group-hover:scale-110 shrink-0"></i>
               <span>${baEsc}</span>
             </button>`
          : '<span class="text-slate-300">-</span>';

        const itemKey = `${statusMeta.slug}|${tk.slug}|${item.no}`;
        const tAwal = item.tempAwal || item.awal;
        const tAkhir = item.tempAkhir || item.akhir;

        html += `
          <tr class="${rowBg} border-b border-slate-200 text-[11px] transition">
            <td class="text-center font-bold text-slate-700 py-1.5 px-2 border-r border-slate-200">${rowIdx + 1}</td>
            <td class="font-medium text-slate-900 py-1.5 px-2.5 border-r border-slate-200 whitespace-nowrap">
              <div class="flex items-center gap-1.5">
                <span>${escapeHtml(item.namaIndo)}</span>
                <span class="text-[9px] px-1.5 py-0.5 rounded border font-bold ${statusMeta.badgeClass}">${statusMeta.shortLabel}</span>
              </div>
            </td>
            <td class="italic font-serif text-slate-600 py-1.5 px-2.5 border-r border-slate-200 whitespace-nowrap">${escapeHtml(item.namaLatin)}</td>

            <!-- Saldo Awal -->
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100 ${tAwal[0] ? 'font-bold text-slate-800' : 'text-slate-400'}">${tAwal[0]}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100 ${tAwal[1] ? 'font-bold text-slate-800' : 'text-slate-400'}">${tAwal[1]}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100 ${tAwal[2] ? 'font-bold text-slate-800' : 'text-slate-400'}">${tAwal[2]}</td>
            <td class="text-center font-mono py-1.5 px-1 font-bold bg-slate-50 border-r border-slate-300 ${tAwal[3] ? 'text-slate-900' : 'text-slate-400'}">${tAwal[3]}</td>

            <!-- Penambahan -->
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100">${tLahir > 0 ? `<span class="font-bold text-emerald-800 font-mono">+${tLahir}</span>` : '-'}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100">${tTukar > 0 ? `<span class="font-bold text-emerald-800 font-mono">+${tTukar}</span>` : '-'}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100">${tTitip > 0 ? `<span class="font-bold text-emerald-800 font-mono">+${tTitip}</span>` : '-'}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100">${tPinjam > 0 ? `<span class="font-bold text-emerald-800 font-mono">+${tPinjam}</span>` : '-'}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-300">${tLain > 0 ? `<span class="font-bold text-emerald-800 font-mono">+${tLain}</span>` : '-'}</td>

            <!-- Pengurangan -->
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100">${kMati > 0 ? `<span class="font-bold text-rose-800 font-mono">-${kMati}</span>` : '-'}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100">${kTukar > 0 ? `<span class="font-bold text-rose-800 font-mono">-${kTukar}</span>` : '-'}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100">${kDipinjamkan > 0 ? `<span class="font-bold text-rose-800 font-mono">-${kDipinjamkan}</span>` : '-'}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100">${kLepas > 0 ? `<span class="font-bold text-rose-800 font-mono">-${kLepas}</span>` : '-'}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-300">${kLain > 0 ? `<span class="font-bold text-rose-800 font-mono">-${kLain}</span>` : '-'}</td>

            <!-- Saldo Akhir -->
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100 ${tAkhir[0] ? 'font-bold text-slate-900' : 'text-slate-400'}">${tAkhir[0]}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100 ${tAkhir[1] ? 'font-bold text-slate-900' : 'text-slate-400'}">${tAkhir[1]}</td>
            <td class="text-center font-mono py-1.5 px-1 border-r border-slate-100 ${tAkhir[2] ? 'font-bold text-slate-900' : 'text-slate-400'}">${tAkhir[2]}</td>
            <td class="text-center font-mono py-1.5 px-1.5 font-black bg-emerald-50 text-emerald-950 border-r border-slate-300">${tAkhir[3]}</td>

            <td class="py-1.5 px-2.5 border-r border-slate-200">${baCell}</td>
            <td class="py-1.5 px-1 text-center whitespace-nowrap">
              <div class="inline-flex items-center gap-1">
                <button type="button" onclick="window.LKSatwaModule.openModalEditSatwaRow('${escapeHtml(statusMeta.slug)}', '${escapeHtml(tk.slug)}', ${item.no})" title="Edit / Ubah Status Perlindungan" class="p-1 text-slate-500 hover:text-indigo-700 hover:bg-indigo-50 rounded transition">
                  <i data-lucide="edit-3" class="w-3.5 h-3.5"></i>
                </button>
                <button type="button" onclick="window.LKSatwaModule.openModalTambahMutasiLK('${escapeHtml(itemKey)}')" title="Catat Mutasi Langsung Satwa Ini" class="p-1 text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50 rounded transition">
                  <i data-lucide="plus-circle" class="w-3.5 h-3.5"></i>
                </button>
              </div>
            </td>
          </tr>
        `;
      });

      // Subtotal Taksa
      html += `
        <tr class="bg-slate-100 font-bold text-[11px] text-slate-900 border-b border-slate-300">
          <td colspan="3" class="text-right py-1.5 px-3">Subtotal ${escapeHtml(tk.namaTaksa)}:</td>
          <td class="text-center font-mono py-1.5 px-1">${tkSubtotal.awal[0]}</td>
          <td class="text-center font-mono py-1.5 px-1">${tkSubtotal.awal[1]}</td>
          <td class="text-center font-mono py-1.5 px-1">${tkSubtotal.awal[2]}</td>
          <td class="text-center font-mono py-1.5 px-1 bg-slate-200/70">${tkSubtotal.awal[3]}</td>
          <td class="text-center font-mono py-1.5 px-1 text-emerald-800">${tkSubtotal.tambahDetail.lahir > 0 ? `+${tkSubtotal.tambahDetail.lahir}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-emerald-800">${tkSubtotal.tambahDetail.tukar > 0 ? `+${tkSubtotal.tambahDetail.tukar}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-emerald-800">${tkSubtotal.tambahDetail.titipan > 0 ? `+${tkSubtotal.tambahDetail.titipan}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-emerald-800">${tkSubtotal.tambahDetail.pinjam > 0 ? `+${tkSubtotal.tambahDetail.pinjam}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-emerald-800">${tkSubtotal.tambahDetail.lain > 0 ? `+${tkSubtotal.tambahDetail.lain}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-rose-800">${tkSubtotal.kurangDetail.mati > 0 ? `-${tkSubtotal.kurangDetail.mati}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-rose-800">${tkSubtotal.kurangDetail.tukar > 0 ? `-${tkSubtotal.kurangDetail.tukar}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-rose-800">${tkSubtotal.kurangDetail.dipinjamkan > 0 ? `-${tkSubtotal.kurangDetail.dipinjamkan}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-rose-800">${tkSubtotal.kurangDetail.lepasliar > 0 ? `-${tkSubtotal.kurangDetail.lepasliar}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1 text-rose-800">${tkSubtotal.kurangDetail.lain > 0 ? `-${tkSubtotal.kurangDetail.lain}` : '-'}</td>
          <td class="text-center font-mono py-1.5 px-1">${tkSubtotal.akhir[0]}</td>
          <td class="text-center font-mono py-1.5 px-1">${tkSubtotal.akhir[1]}</td>
          <td class="text-center font-mono py-1.5 px-1">${tkSubtotal.akhir[2]}</td>
          <td class="text-center font-mono py-1.5 px-1.5 bg-emerald-100 text-emerald-950 font-black">${tkSubtotal.akhir[3]}</td>
          <td colspan="2" class="py-1.5 px-2 text-[10px] text-slate-500 italic">Subtotal taksa</td>
        </tr>
      `;
    });

    // Subtotal Kategori Perlindungan (Dilindungi / Tidak Dilindungi)
    html += `
      <tr class="${isDilindungi ? 'bg-indigo-100/90 text-indigo-950 border-indigo-300' : 'bg-teal-100/90 text-teal-950 border-teal-300'} font-black text-[11px] border-b-2">
        <td colspan="3" class="text-right py-2 px-3">SUBTOTAL ${statusMeta.label.toUpperCase()}:</td>
        <td class="text-center font-mono py-2 px-1">${sectionAwal[0]}</td>
        <td class="text-center font-mono py-2 px-1">${sectionAwal[1]}</td>
        <td class="text-center font-mono py-2 px-1">${sectionAwal[2]}</td>
        <td class="text-center font-mono py-2 px-1 ${isDilindungi ? 'bg-indigo-200/70' : 'bg-teal-200/70'}">${sectionAwal[3]}</td>
        <td class="text-center font-mono py-2 px-1 text-emerald-900">${sectionTambahDetail.lahir > 0 ? `+${sectionTambahDetail.lahir}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-emerald-900">${sectionTambahDetail.tukar > 0 ? `+${sectionTambahDetail.tukar}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-emerald-900">${sectionTambahDetail.titipan > 0 ? `+${sectionTambahDetail.titipan}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-emerald-900">${sectionTambahDetail.pinjam > 0 ? `+${sectionTambahDetail.pinjam}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-emerald-900">${sectionTambahDetail.lain > 0 ? `+${sectionTambahDetail.lain}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-rose-900">${sectionKurangDetail.mati > 0 ? `-${sectionKurangDetail.mati}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-rose-900">${sectionKurangDetail.tukar > 0 ? `-${sectionKurangDetail.tukar}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-rose-900">${sectionKurangDetail.dipinjamkan > 0 ? `-${sectionKurangDetail.dipinjamkan}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-rose-900">${sectionKurangDetail.lepasliar > 0 ? `-${sectionKurangDetail.lepasliar}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1 text-rose-900">${sectionKurangDetail.lain > 0 ? `-${sectionKurangDetail.lain}` : '-'}</td>
        <td class="text-center font-mono py-2 px-1">${sectionAkhir[0]}</td>
        <td class="text-center font-mono py-2 px-1">${sectionAkhir[1]}</td>
        <td class="text-center font-mono py-2 px-1">${sectionAkhir[2]}</td>
        <td class="text-center font-mono py-2 px-1.5 ${isDilindungi ? 'bg-indigo-200 text-indigo-950' : 'bg-teal-200 text-teal-950'} font-black">${sectionAkhir[3]}</td>
        <td colspan="2" class="py-2 px-2 text-[10px] font-bold">${sectionAkhir[3].toLocaleString('id-ID')} Ekor ${statusMeta.label}</td>
      </tr>
    `;

    return html;
  }

  // 13. Generator Tabel Utama Lembaga Konservasi (Khusus Satwa Koleksi: Dilindungi & Tidak Dilindungi)
  function renderLKSatwaStockTableHtml(corp, bulan = '9', tahun = '2026') {
    const stats = calculateLKStats(bulan, tahun);
    if (!stats) return '';
    updateLKSidebarBadge(stats);

    const data = getLKData();

    const activeStatusList = activeLKFilterPerlindungan === 'ALL'
      ? LK_STATUS_PERLINDUNGAN
      : LK_STATUS_PERLINDUNGAN.filter(s => s.slug === activeLKFilterPerlindungan);

    let tableRowsHtml = '';
    activeStatusList.forEach(sMeta => {
      tableRowsHtml += buildLKSectionTableRows(data, stats, sMeta);
    });

    const namaLKUpper = (corp && corp.namaPerusahaan ? corp.namaPerusahaan : 'LK').toUpperCase();
    const footerStats = activeLKFilterPerlindungan === 'dilindungi'
      ? {
          label: `TOTAL SATWA KOLEKSI DILINDUNGI ${namaLKUpper}:`,
          awal: stats.dilindungiStats.awal,
          akhir: stats.dilindungiStats.akhir,
          tambah: stats.dilindungiStats.tambah,
          kurang: stats.dilindungiStats.kurang
        }
      : activeLKFilterPerlindungan === 'tidak_dilindungi'
      ? {
          label: `TOTAL SATWA KOLEKSI TIDAK DILINDUNGI ${namaLKUpper}:`,
          awal: stats.tidakDilindungiStats.awal,
          akhir: stats.tidakDilindungiStats.akhir,
          tambah: stats.tidakDilindungiStats.tambah,
          kurang: stats.tidakDilindungiStats.kurang
        }
      : {
          label: `TOTAL KESELURUHAN SATWA KOLEKSI LK (DILINDUNGI + TIDAK DILINDUNGI):`,
          awal: stats.totalAwal,
          akhir: stats.totalAkhir,
          tambah: stats.totalTambah,
          kurang: stats.totalKurang
        };

    return `
      <div class="space-y-4">
        <!-- Ringkasan & Switcher 2 Kategori Satwa Koleksi LK: Dilindungi vs Tidak Dilindungi -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
          <button type="button" onclick="window.LKSatwaModule.setFilterPerlindungan('ALL')" class="text-left p-4 rounded-2xl border-2 transition shadow-2xs ${activeLKFilterPerlindungan === 'ALL' ? 'border-emerald-600 bg-emerald-50/70' : 'border-slate-200 bg-white hover:border-emerald-300'}">
            <div class="flex items-center justify-between">
              <span class="text-[10px] font-bold uppercase tracking-wider text-emerald-800">Semua Satwa Koleksi LK</span>
              <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-900">${stats.totalSpesies} Jenis</span>
            </div>
            <div class="text-2xl font-black text-slate-900 mt-1">${stats.totalAkhir[3].toLocaleString('id-ID')} <span class="text-xs font-normal text-slate-500">ekor</span></div>
            <p class="text-[11px] text-slate-500 mt-0.5">Gabungan Koleksi Dilindungi &amp; Tidak Dilindungi</p>
          </button>

          <button type="button" onclick="window.LKSatwaModule.setFilterPerlindungan('dilindungi')" class="text-left p-4 rounded-2xl border-2 transition shadow-2xs ${activeLKFilterPerlindungan === 'dilindungi' ? 'border-indigo-600 bg-indigo-50/70' : 'border-slate-200 bg-white hover:border-indigo-300'}">
            <div class="flex items-center justify-between">
              <span class="text-[10px] font-bold uppercase tracking-wider text-indigo-800">1. Satwa Koleksi Dilindungi</span>
              <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg bg-indigo-100 text-indigo-900">${stats.dilindungiStats.spesies} Jenis</span>
            </div>
            <div class="text-2xl font-black text-indigo-950 mt-1">${stats.dilindungiStats.akhir[3].toLocaleString('id-ID')} <span class="text-xs font-normal text-indigo-600">ekor</span></div>
            <p class="text-[11px] text-indigo-700/80 mt-0.5">Satwa koleksi dilindungi undang-undang</p>
          </button>

          <button type="button" onclick="window.LKSatwaModule.setFilterPerlindungan('tidak_dilindungi')" class="text-left p-4 rounded-2xl border-2 transition shadow-2xs ${activeLKFilterPerlindungan === 'tidak_dilindungi' ? 'border-teal-600 bg-teal-50/70' : 'border-slate-200 bg-white hover:border-teal-300'}">
            <div class="flex items-center justify-between">
              <span class="text-[10px] font-bold uppercase tracking-wider text-teal-800">2. Satwa Koleksi Tidak Dilindungi</span>
              <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg bg-teal-100 text-teal-900">${stats.tidakDilindungiStats.spesies} Jenis</span>
            </div>
            <div class="text-2xl font-black text-teal-950 mt-1">${stats.tidakDilindungiStats.akhir[3].toLocaleString('id-ID')} <span class="text-xs font-normal text-teal-700">ekor</span></div>
            <p class="text-[11px] text-teal-800/80 mt-0.5">Satwa koleksi tidak dilindungi &amp; eksotik</p>
          </button>
        </div>

        <!-- Bar Kontrol Filter Khusus Stok Satwa Koleksi LK -->
        <div class="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2.5 text-xs">
          <div class="flex flex-wrap items-center gap-2">
            <div class="inline-flex items-center bg-white border border-slate-200 p-0.5 rounded-xl">
              <button type="button" onclick="window.LKSatwaModule.setFilterPerlindungan('ALL')" class="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition ${activeLKFilterPerlindungan === 'ALL' ? 'bg-emerald-800 text-white' : 'text-slate-600 hover:text-slate-900'}">Semua Koleksi</button>
              <button type="button" onclick="window.LKSatwaModule.setFilterPerlindungan('dilindungi')" class="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition ${activeLKFilterPerlindungan === 'dilindungi' ? 'bg-indigo-700 text-white' : 'text-slate-600 hover:text-slate-900'}">Dilindungi</button>
              <button type="button" onclick="window.LKSatwaModule.setFilterPerlindungan('tidak_dilindungi')" class="px-2.5 py-1 rounded-lg text-[11px] font-semibold transition ${activeLKFilterPerlindungan === 'tidak_dilindungi' ? 'bg-teal-700 text-white' : 'text-slate-600 hover:text-slate-900'}">Tidak Dilindungi</button>
            </div>

            <select onchange="window.LKSatwaModule.setFilterTaksa(this.value)" class="px-2.5 py-1.5 bg-white border border-slate-200 rounded-xl text-[11px] font-semibold text-slate-700 focus:ring-2 focus:ring-emerald-500">
              <option value="ALL" ${activeLKFilterTaksa === 'ALL' ? 'selected' : ''}>Semua Taksa</option>
              <option value="mamalia" ${activeLKFilterTaksa === 'mamalia' ? 'selected' : ''}>Mamalia</option>
              <option value="aves" ${activeLKFilterTaksa === 'aves' ? 'selected' : ''}>Aves</option>
              <option value="reptilia" ${activeLKFilterTaksa === 'reptilia' ? 'selected' : ''}>Reptilia</option>
              <option value="amphibi" ${activeLKFilterTaksa === 'amphibi' ? 'selected' : ''}>Amphibi</option>
              <option value="crustacea" ${activeLKFilterTaksa === 'crustacea' ? 'selected' : ''}>Crustacea</option>
            </select>

            <label class="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-700 cursor-pointer select-none px-2">
              <input type="checkbox" onchange="window.LKSatwaModule.toggleOnlyMutations(this.checked)" ${activeLKOnlyMutations ? 'checked' : ''} class="w-3.5 h-3.5 accent-emerald-700 rounded">
              <span>Hanya Bermutasi</span>
            </label>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <div class="relative">
              <i data-lucide="search" class="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"></i>
              <input type="text" value="${escapeHtml(activeLKSearchQuery)}" oninput="window.LKSatwaModule.handleSearch(this.value)" placeholder="Cari nama satwa / BA..." class="pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-xl text-[11px] w-44 sm:w-56 focus:outline-none focus:ring-2 focus:ring-emerald-500">
            </div>
            <button type="button" onclick="window.LKSatwaModule.printLaporanResmiLK()" class="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-xl text-[11px] font-semibold flex items-center gap-1 transition">
              <i data-lucide="printer" class="w-3.5 h-3.5"></i> Cetak LK
            </button>
          </div>
        </div>

        <!-- Tabel Register Satwa Koleksi Format Resmi BKSDA (23 Kolom) -->
        <div class="overflow-x-auto border-2 border-slate-300 rounded-xl bg-white shadow-2xs">
          <table class="w-full text-left border-collapse" style="font-size: 11px;">
            <thead class="bg-[#14532d] text-white text-[10px] font-bold border-b border-black">
              <tr>
                <th rowspan="3" class="border border-emerald-900 p-2 text-center w-10">No</th>
                <th colspan="2" class="border border-emerald-900 p-1 text-center">Jenis Satwa Koleksi</th>
                <th colspan="4" class="border border-emerald-900 p-1 text-center bg-emerald-900">Jumlah Awal (Ekor)</th>
                <th colspan="10" class="border border-emerald-900 p-1 text-center bg-[#15803d]">Perkembangan Jumlah Satwa</th>
                <th colspan="4" class="border border-emerald-900 p-1 text-center bg-emerald-950">Jumlah Akhir s/d Saat Ini</th>
                <th rowspan="3" class="border border-emerald-900 p-1 text-center min-w-[190px]">Keterangan (No. dan Tgl BA)</th>
                <th rowspan="3" class="border border-emerald-900 p-1 text-center w-14">Aksi Input</th>
              </tr>
              <tr>
                <th rowspan="2" class="border border-emerald-900 p-1 text-center min-w-[160px]">Nama Indonesia</th>
                <th rowspan="2" class="border border-emerald-900 p-1 text-center min-w-[140px]">Nama Spesies</th>
                <th rowspan="2" class="border border-emerald-900 p-0.5 text-center w-8">J</th>
                <th rowspan="2" class="border border-emerald-900 p-0.5 text-center w-8">B</th>
                <th rowspan="2" class="border border-emerald-900 p-0.5 text-center w-8">?</th>
                <th rowspan="2" class="border border-emerald-900 p-0.5 text-center w-10 bg-emerald-800">Σ</th>

                <th colspan="5" class="border border-emerald-900 p-0.5 text-center bg-emerald-700">Penambahan</th>
                <th colspan="5" class="border border-emerald-900 p-0.5 text-center bg-rose-800">Pengurangan</th>

                <th rowspan="2" class="border border-emerald-900 p-0.5 text-center w-8">J</th>
                <th rowspan="2" class="border border-emerald-900 p-0.5 text-center w-8">B</th>
                <th rowspan="2" class="border border-emerald-900 p-0.5 text-center w-8">?</th>
                <th rowspan="2" class="border border-emerald-900 p-0.5 text-center w-11 bg-emerald-900">Σ</th>
              </tr>
              <tr>
                <th class="border border-emerald-900 p-0.5 text-center w-8 bg-emerald-800/80">Lahir</th>
                <th class="border border-emerald-900 p-0.5 text-center w-14 bg-emerald-800/80">Tukar/Hibah</th>
                <th class="border border-emerald-900 p-0.5 text-center w-10 bg-emerald-800/80">Titipan</th>
                <th class="border border-emerald-900 p-0.5 text-center w-9 bg-emerald-800/80">Pinjam</th>
                <th class="border border-emerald-900 p-0.5 text-center w-9 bg-emerald-800/80">Lainnya</th>

                <th class="border border-emerald-900 p-0.5 text-center w-8 bg-rose-900/80">Mati</th>
                <th class="border border-emerald-900 p-0.5 text-center w-14 bg-rose-900/80">Tukar/Hibah</th>
                <th class="border border-emerald-900 p-0.5 text-center w-14 bg-rose-900/80">Dipinjamkan</th>
                <th class="border border-emerald-900 p-0.5 text-center w-11 bg-rose-900/80">Lepasliar</th>
                <th class="border border-emerald-900 p-0.5 text-center w-9 bg-rose-900/80">Lainnya</th>
              </tr>
            </thead>
            <tbody>
              ${tableRowsHtml}
            </tbody>
            <tfoot class="bg-slate-900 text-white font-black text-xs border-t-2 border-black">
              <tr>
                <td colspan="3" class="p-2.5 text-right font-black">${footerStats.label}</td>
                <td class="text-center font-mono p-1.5">${footerStats.awal[0]}</td>
                <td class="text-center font-mono p-1.5">${footerStats.awal[1]}</td>
                <td class="text-center font-mono p-1.5">${footerStats.awal[2]}</td>
                <td class="text-center font-mono p-1.5 bg-slate-800">${footerStats.awal[3]}</td>

                <td colspan="5" class="text-center font-mono p-1.5 text-emerald-400 font-bold">+${footerStats.tambah}</td>
                <td colspan="5" class="text-center font-mono p-1.5 text-rose-400 font-bold">-${footerStats.kurang}</td>

                <td class="text-center font-mono p-1.5">${footerStats.akhir[0]}</td>
                <td class="text-center font-mono p-1.5">${footerStats.akhir[1]}</td>
                <td class="text-center font-mono p-1.5">${footerStats.akhir[2]}</td>
                <td class="text-center font-mono p-1.5 bg-emerald-800 text-emerald-100 text-sm font-black">${footerStats.akhir[3]}</td>
                <td colspan="2" class="p-1.5 text-[10px] text-slate-300">${footerStats.akhir[3].toLocaleString('id-ID')} Ekor Satwa Koleksi</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    `;
  }

  // 14. Expose ke Window
  window.LKSatwaModule = {
    metadata: LK_METADATA,
    statusPerlindunganList: LK_STATUS_PERLINDUNGAN,
    normalizeJenisStok,
    normalizePerlindunganSlug,
    getLKData,
    reloadLKDataFromStorage,
    saveLKData,
    calculateLKStats,
    renderLKSatwaView,
    setFilterJenisStok,
    setFilterPerlindungan,
    setFilterTaksa,
    toggleOnlyMutations,
    handleSearch,
    goToLKStokTab,
    openModalBADetail,
    closeModalBADetail,
    printLaporanResmiLK,
    handleMutasiStatusFilterChange,
    handleMutasiJenisFilterChange,
    openModalTambahMutasiLK,
    closeModalTambahMutasiLK,
    handleSaveMutasiLK,
    updateNewSatwaStatusCards,
    updateNewSatwaJenisCards,
    openModalTambahSatwaBaru,
    closeModalTambahSatwaBaru,
    handleSaveSatwaBaru,
    openModalEditSatwaRow,
    closeModalEditSatwaRow,
    handleSaveEditSatwaRow,
    deleteSatwaRowLK,
    renderLKSatwaStockTableHtml
  };

})(window);
