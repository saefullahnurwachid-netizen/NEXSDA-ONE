# Panduan Membuat File `.apk` Android NEXSDA ONE

Selain aplikasi desktop Windows (`.exe`), proyek **NEXSDA ONE** kini dilengkapi pembangun **Android `.apk`** berbasis **Capacitor** sehingga dapat langsung dipasang di ponsel/tablet Android petugas lapangan:
- Menggunakan identitas aplikasi resmi `id.go.menlhk.bksdajakarta.nexsdaone` dan ikon **NEXSDA ONE**.
- Mendukung akses **GPS/Lokasi**, **Kamera**, **Peta GIS interaktif**, **Sistem Surat Tugas**, serta penyimpanan langsung file **`.docx`**, **`.xlsx`**, dan **`.pdf`** ke folder **Download** HP Android.
- Mendukung 2 mode:
  1. **Mode Mandiri (Default)** — Seluruh aset aplikasi dibundel di dalam `.apk` (cepat dan tetap terbuka saat offline).
  2. **Mode Terhubung Server Online** — Mengarahkan `.apk` ke URL server NEXSDA ONE aktif agar sinkronisasi Google Drive, login edit, dan pembaca geotag AI berjalan langsung dari HP.

---

## Cara 1: Build 1-Klik di Laptop Windows

### Prasyarat (cukup dipasang 1 kali)
1. **Node.js LTS (20 atau 22)** — https://nodejs.org/
2. **Android Studio** (sudah termasuk Android SDK & Java JDK) — https://developer.android.com/studio

### Langkah Build
1. Ekstrak folder proyek ini ke laptop Windows (misal `D:\NEXSDA-ONE`).
2. Klik 2 kali berkas **`BUILD_APK_ANDROID.bat`**.
3. Tunggu proses selesai. Folder **`release/`** akan terbuka otomatis berisi:
   - **`NEXSDA-ONE-1.0.0.apk`** — Langsung salin ke HP Android dan instal.

---

## Cara 2: Via Terminal (PowerShell / CMD / macOS / Linux)

- **Build APK siap instal (Mode Mandiri):**
  ```bash
  npm install
  npm run build:apk
  ```
- **Build APK yang langsung terhubung ke server online NEXSDA ONE:**
  ```bash
  npm run build:apk -- --server=https://URL-SERVER-NEXSDA-ANDA
  ```
  *(Atau isi `NEXSDA_ANDROID_SERVER_URL=https://...` di dalam berkas `.env` sebelum menjalankan `BUILD_APK_ANDROID.bat`.)*
- **Build APK Release (untuk Play Store / penandatanganan keystore):**
  ```bash
  npm run build:apk:release
  ```
- **Buka proyek Android langsung di Android Studio:**
  ```bash
  npm run android:open
  ```

---

## Cara 3: Build Otomatis di Cloud Tanpa Pasang Android Studio (GitHub Actions)

Jika laptop Anda belum terpasang Android Studio / Android SDK:
1. Unggah proyek ini ke repositori **GitHub**.
2. Buka tab **Actions** → pilih workflow **Build Android APK (NEXSDA ONE)** → klik **Run workflow**.
3. *(Opsional)* Isi kolom **Server URL** jika ingin APK terhubung ke URL server online Anda.
4. Setelah selesai (±3–5 menit), unduh artefak **`NEXSDA-ONE-APK`** yang berisi berkas **`NEXSDA-ONE-1.0.0.apk`**.
