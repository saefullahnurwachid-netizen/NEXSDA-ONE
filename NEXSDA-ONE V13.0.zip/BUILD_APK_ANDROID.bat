@echo off
chcp 65001 >nul
title Builder APK Android - NEXSDA ONE BKSDA Jakarta

echo ============================================================
echo   NEXSDA ONE - Pembuat Aplikasi Android (.APK)
echo ============================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Node.js belum terpasang di laptop ini.
  echo Silakan unduh dan pasang Node.js LTS dari https://nodejs.org/
  echo Setelah selesai, jalankan kembali berkas ini.
  pause
  exit /b 1
)

where java >nul 2>nul
if %errorlevel% neq 0 (
  echo [ERROR] Java JDK ^(17 atau 21^) belum terpasang di laptop ini.
  echo Silakan pasang JDK 17/21 atau Android Studio terlebih dahulu.
  echo Lihat langkah mudah di PANDUAN_BUILD_APK.md.
  pause
  exit /b 1
)

if not exist "node_modules\.bin\vite.cmd" (
  echo [1/2] Memasang dependensi proyek pertama kali...
  call npm install --no-audit --no-fund
  if %errorlevel% neq 0 (
    echo [INFO] Mencoba ulang pemasangan dependensi dengan --legacy-peer-deps...
    call npm install --legacy-peer-deps --no-audit --no-fund
    if %errorlevel% neq 0 (
      echo [ERROR] Gagal menjalankan npm install.
      pause
      exit /b 1
    )
  )
)

echo [2/2] Memproses build aplikasi Android (.apk)...
call npm run build:apk
if %errorlevel% neq 0 (
  echo [ERROR] Build .apk gagal. Periksa pesan error di atas atau lihat PANDUAN_BUILD_APK.md.
  pause
  exit /b 1
)

echo.
echo ============================================================
echo   BERHASIL! File .apk ada di dalam folder "release".
echo ============================================================
if exist "release" start "" "release"
pause
